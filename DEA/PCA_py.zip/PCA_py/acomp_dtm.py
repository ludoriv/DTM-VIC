#***----------------------------------------------------
#***  Here the source file: "acomp_dtm.py" and the data: Mini_Sem.txt,
#***  Mini_Sem_vsup, Mini_Sem_isup.txt are in a "mydirectory" folder
#***  directly in the root "c: /".
#***  To be adapted for each user, which will replace "mydirectory"
#***  by the path to his working folder.

#***----------------------------------------------------
#***  In the interface (IDLE ...),
#***  copy the following 4 lines one by one (without the "#")
#***----------------------------------------------------
# import os
# os.chdir("c:/mydirectory")
# import acomp_dtm
# from acomp_dtm import *
#***----------------------------------------------------
#*** Import statements for: numpy, pandas, matplotlib
#*** There is no need to copy these three lines: Automatic execution 
#*** through the previous importation of: acomp_dtm.py file
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#***-------------------------------------------------------------
#***  Successively copy the instructions following the �#� symbol.
#***  Comments (# ***) obviously do not need to be copied.
#***-------------------------------------------------------------
#***  SELECTION OF PATHS (for the 3 data files)
#***  "Mini_Sem" example: 3 paths for the Mini_Sem example (mini-semiometry)
# lane, lane_sup, lane_var_sup = 'Mini_Sem.txt', 'Mini_Sem_isup.txt', 'Mini_Sem_vsup.txt'
#***
#***  Example "Sem_300": 3 paths for the example Sem_300
# lane, lane_sup, lane_var_sup  = 'Sem300.txt', 'Sem300_isup.txt', 'Sem300_vsup.txt'
#***-------------------------------------------------------------
#*** CHOICE OF PARAMETERS
#***-------------------------------------------------------------
#*** SELECTION of a pair of axes for visualizations
#*** (for semiometry, axis 1 (size factor) is not taken into account)
#***-------------------------------------------------------------
# ax_h, ax_v = 2, 3 

#*** Supplementary NUMERICAL VARIABLES
# vsup_lim = 3 #(Mini_Sem) ou vsup_lim = 7 (Sem300)  
#*** vsup_lim first numerical Supplementary variables taken into account
#***
#*** Supplementary CATEGORICAL VARIABLE
# vsup_nom = 4 #(Mini_Sem) or vsup_nom = 12 (Sem300) 
#*** the Supplementary nominal var vsup_nom is selected
#***-------------------------------------------------------------
#*** PCA EXECUTION
#***-------------------------------------------------------------
#*** 1) ACP_base (): read basic data and computations
# X, c_indiv, c_var, vecp, moy, ecinv = ACP_base(lane)
# 
#*** 2) grafact() : factorial plane of active elements (indiv. + Variables)
# grafact (X, c_indiv, c_var, ax_h, ax_v )
#
#*** 3) ACP_isup() Supplementary individuals
# ACP_isup(X, c_indiv, lane_sup,moy, ecinv, vecp, ax_h, ax_v)
#
#*** 4) ACP_vsup() Supplementary numeric variables (from 1 -> vsup_lim)
# ACP_vsup(X, c_indiv, c_var, lane_var_sup,ax_h, ax_v, vsup_lim )
#
#*** 5) ACP_nom() Supplementary nominal variable (vsup_nom)
# ACP_nom(X, c_indiv, ax_h, ax_v, vsup_nom, lane_var_sup )
#
#*** End of the lines to copy in the interface
#
#***----------------------------------------------------------
#*** These 5 calls can be replaced by the single call of the function
#***  ACP ():
# ACP (lane, lane_sup, lane_var_sup, ax_h, ax_v, vsup_lim, vsup_nom)
#
#***  However we may want to represent other visualization planes,
#***  use other supplementary nominal variables,
#***  or select supplementary numerical variables ...
#***  the call by separate functions is more flexible.
#***------------------------------------------------------
#***  End of lines to copy in the interface
#***------------------------------------------------------
#***--------------- CODES FOR ALL CALLED FUNCTIONS
#***------------------------------------------------------
#*** Reminder: pd, np, plt are global variables for all 
#***  the functions of acomp_dtm.py
#***------------------------------------------------------
#*** Terminology: nominal <=> categorical
#***  supplementary <=> additional <=> illustrative
#***------------------------------------------------------
#*** Function ACP_base(): computations, eigenvalues, eigenvectors...
def ACP_base(lane):
#---
	X, c_indiv, c_var, pourcent, vecp, vp, moy, ecinv = ACP_calc(lane)
	n,p = X.shape
	grafacp_vp(pourcent, p)
#---
	ch ="ACP_file_" + lane    # name of created file
	g = open(ch, "w+")       
	print ("\n The coordinates are in the created file; " + ch)
	print("\n Eigenvalues\n")
	print(vp)
	print("\n") 
#---	
	g.write("\n Dataset\n")
	g.write(lane)
	g.write("\n")  
	g.write("\n Eigenvalues\n")
	g.write(str(vp))
	g.write("\n\n") 
	pd.set_option('display.max_rows', 10)
#---
	ligne = "Coordinates of variables"  
	print(ligne)
	print("\n")  
	print(pd.DataFrame({'ident':X.columns, 'c_var_1': c_var[:,0], 'c_var_2': c_var[:,1],'c_var_3': c_var[:,2],  }))
	g.write(ligne)
	g.write("\n\n") 
	info = "\n complete coord. and coord. of indiv. are in the created file: " + ch + "\n\n"
	print(info)
	pd.set_option('display.max_rows', n)
#---
	a = pd.DataFrame({'ident':X.columns, 'c_var_1': c_var[:,0], 'c_var_2': c_var[:,1],'c_var_3': c_var[:,2],  })
	sa = str(a)
	g.write(sa)
	g.write("\n\n")
	ligne = "Coordinates of individuals or observations" 
	g.write(ligne)
	g.write("\n\n")
#---
	aa = pd.DataFrame({'ident':X.index, 'c_indiv_1': c_indiv[:,0], 'c_indiv_2': c_indiv[:,1],'c_indiv_3': c_indiv[:,2],  })
	saa = str(aa)
	g.write(saa)
	g.close()
	pd.reset_option('display.max_rows')		
	return X, c_indiv, c_var, vecp, moy, ecinv
#----------------------------------------------------
#*** Function ACP_calc() : basic computations 
def ACP_calc(lane):
	X = pd.read_csv(lane)
	n,p = X.shape
	moy = np.mean(X)
	ec= np.std(X)
	ecinv = 1./ec
#--- StanX : standardized data
	StanX = np.zeros((n,p))
	for i in range(n):
		for j in range(p):
			StanX[i,j] = (X.iloc[i,j] -moy[j])*ecinv[j]
	C = np.dot(StanX.T, StanX)/n
	vp1, vecp1 = np.linalg.eigh(C)
	c_var = np.zeros((p,p))
	vecp  = np.zeros((p,p))
	vp    = np.zeros(p)
#---inversion of the order of eigen-elements -----
	for j in range(p):
		jj = p-j-1
		vp[j] = vp1[jj]
		vecp[:,j] = vecp1[:,jj]
		c_var[:,j]= vecp[:,j]*np.sqrt(vp[j])
#--- End of the inversion
	c_indiv = np.dot(StanX, vecp)
	trace = np.sum(vp)
	pourcent = vp/trace
	return X, c_indiv, c_var, pourcent, vecp, vp, moy, ecinv
#----------------------------------------------------
#*** Function grafacp_vp(): Eigenvalue graph
def grafacp_vp(pourcent, p):
	plt.plot(np.arange(1, p+1), pourcent)
	plt.title("Eigenvalues")
	plt.xlabel("Axes")
	plt.ylabel("Eigenvalues (as percentages of trace)")
	plt.show()
#----------------------------------------------------
#*** Function gracfact(): Graphics (plane (ax_h, ax_v) of active elements
def grafact ( X, c_indiv, c_var, ax_h, ax_v ):
	xx = ax_h
	yy = ax_v
	n,p = X.shape
#---
	graf_var (X, c_var, p, xx, yy)
	graf_ind (X, c_indiv,  n, xx, yy)
	return
#----------------------------------------------------
#*** Function graf_var(): Plots (plane (ax_h, ax_v)) of variables
def graf_var ( X, c_var, p, ax_h, ax_v):
	lax = 8
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (-1,1)
	axes.set_ylim(-1,1)
	FS = 8    # FS = fontsize
	for j in range(p):
		plt.annotate (X.columns[j],(c_var[j,ax_h - 1], c_var[j,ax_v - 1]), fontsize = FS)
	plt.plot([-1,1],[0,0], color = 'blue', linestyle = "-", linewidth = 1)
	plt.plot([0,0],[-1,1], color = 'blue', linestyle = "-", linewidth = 1)
	plt.title("Variables(correlations) Plane "+ str(ax_h)+ ", "+ str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	discor = plt.Circle( (0,0),1, color = 'green', fill = False)
	axes.add_artist(discor)
	plt.show()
#----------------------------------------------------
#*** Function  graf_ind() : Plots (plane (ax_h, ax_v)) of individuals
def graf_ind ( X, c_indiv, n, ax_h, ax_v):
#--- Frame (same units)
	xh = c_indiv[:,ax_h - 1]
	xv = c_indiv[:,ax_v - 1]
#--- a:  to widen the frame 
	a = 1
	FS = 8   # FS = fontsize
	lmin = min(min(xv), min(xh)) - a
	lmax = max(max(xv), max(xh)) + a
	lax = lmax - lmin
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin, lmax)
	for i in range(n):
		plt.annotate (X.index[i],(c_indiv[i,ax_h - 1], c_indiv[i,ax_v - 1]), fontsize = FS)
	plt.plot([lmin,lmax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[lmin,lmax], color = 'red', linestyle = "-",linewidth = 1)
	plt.title("Individuals (observations) Plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Function ACP_isup() : graphics of Supplementary individuals
def ACP_isup( X, c_indiv, lane_sup,moy, ecinv, vecp, ax_h, ax_v):
#--- Supplementary individual data
	df_isup, df_isup_norm, c_isup = isup(lane_sup, moy, ecinv, vecp)
#--- Supplementary individual displays
	graf_ind_sup (X, c_indiv, c_isup,  df_isup, ax_h, ax_v)
	return
#----------------------------------------------------
#*** Function isup(): Coordinates of supplementary individuals
def isup(lane_sup, moy, ecinv, vecp):
	df_isup = pd.read_csv(lane_sup)
	q,p = df_isup.shape
	df_isup_norm = np.zeros((q,p))
	for i in range(q):
		for j in range(p):
			df_isup_norm [i,j] = (df_isup.iloc[i,j] -moy[j])*ecinv[j]
	c_isup = np.dot(df_isup_norm, vecp)
	return df_isup, df_isup_norm, c_isup
#----------------------------------------------------
#*** Function graf_ind_sup() : Graphical display (plane (ax_h, ax_v) ) of suppl. indiv.
def graf_ind_sup (X, c_indiv, c_isup, df_isup, ax_h, ax_v):
#--- Frame (same units)
	xh = c_indiv[:,ax_h - 1]
	xv = c_indiv[:,ax_v - 1]
	xh_sup = c_isup[:,ax_h - 1]
	xv_sup = c_isup[:,ax_v - 1]
#--- a: to widen the frame 
	a = 1
	FS = 8  # FS = fontsize	
	lmin = min(min(xv), min(xh),min(xv_sup), min(xh_sup)) - a
	lmax = max(max(xv), max(xh), max(xv_sup), max(xh_sup)) + a
	lax = lmax - lmin
#---
	n = X.shape[0]           # number of active individuals
	fig, axes = plt.subplots(figsize = (2*lax,2*lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin,lmax)
	for i in range(n):       # active individuals
		plt.annotate (X.index[i],(c_indiv[i,ax_h - 1], c_indiv[i,ax_v - 1]), fontsize = FS)
	nsup = df_isup.shape[0]  # number of suppl. individuals 
	for i in range(nsup):    # suppl. individuals 
		plt.annotate (df_isup.index[i],(c_isup[i,ax_h - 1], c_isup[i,ax_v - 1]), color = 'b')
#--- drawing the axes
	plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
	# titles and tags
	plt.title("Active individuals + suppl. Plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Function ACP_vsup(): Supplementary numerical variable
def ACP_vsup(X, c_indiv, c_var,  lane_var_sup,ax_h, ax_v, vsup_lim ):
#--- Call Supplementary variables data
	df_vsup, df_vs_num, c_vsup = vsup(X, c_indiv, lane_var_sup, vsup_lim)
	if (vsup == 0):
		return
#--- Call Supplementary variables graphics
	graf_var_sup (X, c_var, df_vsup, df_vs_num, c_vsup, ax_h, ax_v)
#----------------------------------------------------
#*** Function vsup() : Supplementary variables data: 
def vsup(X, c_indiv, lane_var_sup, vsup_lim):
	n, p = X.shape
	df_vsup = pd.read_csv(lane_var_sup)
	qtot = df_vsup.shape[1] #  qtot = total number of suppl. variables
	if (vsup_lim > qtot):
		raise ValueError(" Error, vsup_lim too large !")
#---vsup_lim = The vsup_lim first vsup (numerical) are projected
	df_vs_num = df_vsup.iloc[:,:vsup_lim].values  
	q = df_vs_num.shape[1]  # number of numer. suppl. variables
	c_vsup = np.zeros((q,p))
	for j in range(p):
		for m in range(q):
			c_vsup[m,j] = np.corrcoef(df_vs_num[:,m], c_indiv[:,j])[0,1]
	print(c_vsup)
	return df_vsup, df_vs_num, c_vsup
#----------------------------------------------------
#*** Function graf_var_sup() : Graphics (plane (ax_h, ax_v)) of supplementary variables
def graf_var_sup (X, c_var, df_vsup, df_vs_num, c_vsup,  ax_h, ax_v):
	lax = 8
	q = df_vs_num.shape[1]  # number of suppl. variables
	p = X.shape[1]  # number of axes (= number of active variables)
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (-1,1)
	axes.set_ylim(-1,1)
	FS = 8  # FS = fontsize	
#--- active variables
	for j in range(p):
		plt.annotate (X.columns[j],(c_var[j,ax_h - 1], c_var[j,ax_v - 1]), fontsize = FS)
#--- suppl�mentary numerical variables	
	for j in range(q):
		plt.annotate (df_vsup.columns[j],(c_vsup[j,ax_h - 1], c_vsup[j,ax_v - 1]), color = 'g')
#---
	plt.plot([-1,1],[0,0], color = 'blue', linestyle = "-", linewidth = 1)
	plt.plot([0,0],[-1,1], color = 'blue', linestyle = "-", linewidth = 1)
	plt.title("Variables(correlations) Plane "+ str(ax_h)+ ", "+ str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	discor = plt.Circle( (0,0),1, color = 'green', fill = False)
	axes.add_artist(discor)
	plt.show()
#----------------------------------------------------
#*** Function ACP_nom() : Supplementary nominal variable data
def ACP_nom(X, c_indiv, ax_h, ax_v, vsup_nom, lane_var_sup ): 
#--- choice of supplementary nominal variable
	df_vsup = pd.read_csv(lane_var_sup)
	df_vs_nom = df_vsup.iloc[:,vsup_nom - 1]
#--- the nominal variable is the "vsup_nom" column of df_vsup
#--- Conversion of categories into colors
	col,b, nmod, dicmod = couleur (df_vs_nom)
# Individuals / Supplementary nominal variables display
	graf_ind_mod ( X, c_indiv, df_vs_nom, vsup_nom, ax_h, ax_v, col, b, nmod, dicmod)
	return 
#----------------------------------------------------
#*** Function graf_ind_mod() : Graphics (plane (ax_h, ax_v)) of a supplementary nominal variable 
def graf_ind_mod (X, c_indiv, df_vs_nom, vsup_nom, ax_h, ax_v, col, b, nmod, dicmod):
#--- Frame (same units)
	h,  v = ax_h - 1,  ax_v - 1
	xh = c_indiv[:,h]
	xv = c_indiv[:,v]
#---	a : to widen the frame
	FS = 8  # FS = fontsize
	a = 1
	lmin = min(min(xv), min(xh)) - a
	lmax = max(max(xv), max(xh)) + a
	lax = lmax - lmin
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin, lmax)
	n = X.shape[0]  # number of active individuals
#---
	a = list(df_vs_nom)
	for i in range(n):
		plt.annotate (a[i],(xh[i], xv[i]), color = col[i], fontsize = FS)
#---		
	xhnom = coord_nom(xh, b, nmod,n)
	xvnom = coord_nom(xv, b, nmod,n)
	for j in range(nmod):
		plt.annotate (dicmod[j],(xhnom[j], xvnom[j]), color = 'k', weight='bold', fontsize = FS +3)
#---
	plt.plot([lmin,lmax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[lmin,lmax], color = 'red', linestyle = "-",linewidth = 1)
	plt.title("Individuals + Categorical var. " + str(vsup_nom) + ", Plane (" + str(ax_h)+ ", "+  str(ax_v) + ")")
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
	return
#----------------------------------------------------
#*** Function numer(): numerical coding (consecutive integers) of categories
#*** (purpose: this digitization is intended to color the individuals 
#*** on the graphs according to their categories)
def numer (df_vs_nom): 
	categ = np.unique(df_vs_nom) # list of distinct categories
	nmod = len(categ)
	a = list(df_vs_nom)
	dic_mod = {}  # dictionary key = category (string), value = number
	for i in range (nmod):
		dic_mod[categ[i]] = i
	b = []
	for i in range(len(a)):
		b.append(dic_mod[a[i]]) # numer. coding of categories
	dicmod = {}
	for cle, val in list(dic_mod.items()):
		dicmod[val] = cle
	return b, nmod, dicmod
#----------------------------------------------------
#***  Function couleur(): Conversion of 6 first categories into colors	
def couleur (df_vs_nom):
	b, nmod, dicmod = numer(df_vs_nom)
	color7 = ['r','g','b','c','m','y','k']  #  k = black...
	col = []
	for i in range(len(b)):
		a = b[i]
		if(a > 6):
			a = 6 # categories beyond 7 are black
		col.append(color7[a])
	return col,b, nmod, dicmod
#------------------------------------------------------------------------
#*** Function coord_nom() : Coordinates of Suppl. categories
#*** (as average points of the individuals concerned)
def coord_nom(d,b, nmod,n):
#--- d = numerical vector, length = n (indiv. coordinates)
#--- nmod = number of categories
#--- b = numerical coding (1,2,...) of the categ. variable
	moy = np.zeros(nmod) # sum per categories
	eff = np.zeros(nmod) # frequency of category
	for i in range(n):
		eff[b[i]] +=  1
		moy[b[i]] += d[i]
	return moy/eff
#------------------------------------------------------------------------
#*** ACP () function. This function combines the 5 main function calls:
#*** ACP_base(), grafact(), ACP_isup(), ACP_vsup(), ACP_nom(). 
#-------------------------------------------------------------------------
def ACP (lane, lane_sup, lane_var_sup, ax_h, ax_v, vsup_lim, vsup_nom):
	X, c_indiv, c_var, vecp, moy, ecinv = ACP_base(lane)
	grafact (X, c_indiv, c_var, ax_h, ax_v )
	ACP_isup(X, c_indiv, lane_sup,moy, ecinv, vecp, ax_h, ax_v)
	ACP_vsup(X, c_indiv, c_var, lane_var_sup,ax_h, ax_v, vsup_lim )
	ACP_nom(X, c_indiv, ax_h, ax_v, vsup_nom, lane_var_sup )
	return
#-------------------------------------------------------------------------
