def main():
#    
    global paraliste
    global dossier_data
    from pathlib import Path
    paraliste = main_parameters()
    print ("\n  step 1 done  \n")
    print (paraliste)
    import TextPanorama
#------------
    TextPanorama.CA_AT_synthesis(*paraliste)
    print("\n  Execution completed \n  -------  \n")
    return

#********************
def main_parameters():
    import tkinter as tk
    from tkinter import ttk
    from tkinter import filedialog
    from tkinter import font
    import os
    import sys
    import importlib.util
    global paraliste
    global chemin_path, sentier_path, piste_path,  dossier_data
#    from multiprocessing import Process
    root = tk.Tk()
    root.title("Menu défilant avec Scrollbar")
    root.title("Interface for executing TextPanorama.py")
    root.geometry("550x800")
    
# ---- Creating canvas + scrollbar ----
    container = ttk.Frame(root)
    container.pack(fill="both", expand=True)
    
    canvas = tk.Canvas(container)
    canvas.pack(side="left", fill="both", expand=True)
    
    scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
    scrollbar.pack(side="right", fill="y")
    
    canvas.configure(yscrollcommand=scrollbar.set)
    
# ---- Frame  ----
    menu_frame = ttk.Frame(canvas)
    canvas.create_window((0, 0), window=menu_frame, anchor="nw")
    
# Function to adjust the scrollable zone
    def on_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))
    
    menu_frame.bind("<Configure>", on_configure)
    
# Global variables
    chemin_path = ""
    sentier_path = ""
    piste_path = ""
    dossier_data = None
#    
# ---- Glossary
#   "choisir" = Select
#   "ouili ouili" = Problem ! 
#------------------   
    def choisir_dossier():
        global dossier_data
        dossier_data = filedialog.askdirectory(title="Select the folder containing the data files")
        label_dossier.config(text=dossier_data)
    
#     "chemin" = Basic text corpus   
#------------------   
    def choisir_chemin():
        global chemin_path
        chemin_path = filedialog.askopenfilename(title="Choisir le chemin", initialdir=dossier_data)
        label_chemin.config(text=os.path.basename(chemin_path))
        if not chemin_path :
            print (" ouili ouili, chemin")
            return False

#     "sentier"  XL file of categories of texts    
#------------------   
    def choisir_sentier():
        global sentier_path
        sentier_path = filedialog.askopenfilename(title="Choisir le sentier", initialdir=dossier_data)
        label_sentier.config(text=os.path.basename(sentier_path))
        if not sentier_path :
            print (" ouili ouili, sentier")
            return False

#     "piste" = XL file of identifiers of categories    
#------------------   
    def choisir_piste():
        global piste_path
        piste_path = filedialog.askopenfilename(title="Choisir la piste", initialdir=dossier_data)
        label_piste.config(text=os.path.basename(piste_path))
        if not piste_path :
            print (" ouili ouili, piste")
            return False

#       "Run"            
    def lancer_programme():
        global paraliste
        wordbag = int(wordbag_var.get())
        anagreg = int(anagreg_var.get()) 
        freqmin = int(freqmin_var.get()) 
        nax = int(nax_var.get()) 
        nvt = int(nvt_var.get()) 
        Detail = int(Detail_var.get()) 
        seuil_vt = int(seuil_vt_var.get())
#
#
        paraliste = [dossier_data, chemin_path, sentier_path, piste_path, wordbag, anagreg, freqmin,  nax,   nvt,   Detail, seuil_vt]
        print  ("\n "   + "chemin =  " + chemin_path + "   \n" )
        print  ("\n "   + "sentier = " + sentier_path + "  \n" )
        print  ("\n "   + "piste =   " + piste_path + "  \n" )
        print   ("\n "   + "wordbag  =" + str(wordbag) + ",   anagreg = " + str(anagreg) + ",   freqmin = " +  str(freqmin) + "\n" )
        print   ("\n "   + "nax  =" + str(nax) + ",   nvt = " + str(nvt) + ",   Detail = " +  str(Detail) + "\n" )
        print   ("\n "   + "seuil_vt  =" + str(seuil_vt) + "\n" )

#        print (" wordbag, anagreg, freqmin,  nax,   nvt,   Detail, seuil_vt ")
#        print ( wordbag, "  ", anagreg,"  ", freqmin, "  ", nax, "  ", nvt, "  ", Detail, "  ", seuil_vt )
#        print( "\n   chemin_path     sentier_path     piste_path   \n")
#        print( "\n  ", chemin_path,  "  ",  sentier_path, "  ", piste_path, "  \n")
        if not chemin_path or not sentier_path or not piste_path:
            print("Files not yet selected")
            return
        root.destroy()
        return
        
#
#************************************
# Interface Tkinter
    
    style = ttk.Style()
    style.theme_use("clam")
    my_font = font.Font(family="Helvetica", size=10, weight="bold")
    
    style.configure(
        "My.TButton",
        font=my_font,
        background="#4CAF50",
        foreground="white",
        padding=6,
        relief="flat"
    )
#    
# Default values
#----------------    
    wordbag_var = tk.StringVar(value="1")
    anagreg_var = tk.StringVar(value="0")
    freqmin_var = tk.StringVar(value="9")
    nax_var = tk.StringVar(value="7")
    nvt_var = tk.StringVar(value="2")
    Detail_var = tk.StringVar(value="0")
    seuil_vt_var = tk.StringVar(value="2")
    
# --- Button : Selecting basic folder
    row = 0
    ttk.Button(menu_frame, text="1) Selection of folders", style = "My.TButton").grid(row=row, column=1, sticky="w", pady=5, padx=10)
    row += 1
    
    ttk.Button(menu_frame, text="Select folder", command=choisir_dossier).grid(row=row, column=1, pady=5)
    label_dossier = ttk.Label(menu_frame, text="(Folder not yet selected)")
    label_dossier.grid(row=row, column=2, sticky="w", padx = 10)
    
# --- Buttons : Selecting files ---
    row = 2
    ttk.Button(menu_frame, text="2) Select files", style = "My.TButton").grid(row=row, column=1, sticky="w", pady=5, padx=10)
    row += 1
    
    ttk.Button(menu_frame, text="Select basic_text", command=choisir_chemin).grid(row=row, column=1, pady=5)
    label_chemin = ttk.Label(menu_frame, text="(No basic text selected)")
    label_chemin.grid(row=row, column=2, sticky="w", padx = 10)
    
    row += 1
    
    ttk.Button(menu_frame, text="Select categories", command=choisir_sentier).grid(row=row, column=1, pady=5)
    label_sentier = ttk.Label(menu_frame, text="(Categories file not yet selected)")
    label_sentier.grid(row=row, column=2, sticky="w", padx = 10)
    row += 1
    
    ttk.Button(menu_frame, text="Select identifiers", command=choisir_piste).grid(row=row, column=1, pady=5)
    label_piste = ttk.Label(menu_frame, text="(Categories identifiers file not selected)")
    label_piste.grid(row=row, column=2, sticky="w", padx = 10)
    row += 1
#    
# --- Section: parameters ---
#    
    ttk.Button(menu_frame, text=" 3) Select parameters values", style = "My.TButton").grid(row=row, column=1, sticky="w", pady=5, padx=10)
    label_param = ttk.Label(menu_frame, text="(Default values)")
    label_param.grid(row=row, column=2, sticky="w")
#    
#   Meaning of parameters
#------------------------
    parametres = { "wordbag": "If wordbag = 1: Each raw text is replaced with a bag of words; if wordbag = 0: the analyses are performed on raw texts", "anagreg": "If anagreg = 1: Poems/texts are aggregated according to the categories described in category file; if anagreg = 0: Direct analysis of all poems/texts. ", "freqmin": "freqmin: Minimum frequency for kept words.", "nax": "nax: Maximum number of axes to keep in the initial correspondence analysis.", "nvt": "nvt: Number of kept characteristic words (criterion: test values)", "Detail": "Detail = 1: For anagreg = 0, detailed outputs (bootstrap replications, various visualizations); Detail = 0: basic outputs.", "seuil_vt": "seuil_vt: Significance threshold of the test-values (for selection of characteristic words)."}
    
    
#   List of variables
#--------------------
    variables = [wordbag_var, anagreg_var, freqmin_var, nax_var, nvt_var, Detail_var, seuil_vt_var]
    
#   Loop on parameters lines
#--------------------------
    row +=1
    for (param, explication), var in zip(parametres.items(), variables):
        ttk.Label(menu_frame, text=param).grid(row=row, column=1, padx=5, pady=5)
        ttk.Entry(menu_frame, textvariable=var).grid(row=row+1, column=1, padx=5, pady=5)
    
# New explanation column (column 3)
        lbl_explication = ttk.Label(menu_frame, text=explication, wraplength=300, justify="left")
        lbl_explication.grid(row=row, column=2, rowspan=2, sticky="w",padx=10)
#    
        row += 2  # 2 line
#
# --- Displaying the values ---
#    
    def afficher_valeurs():
        print("wordbag :", wordbag_var.get())
        print("anagreg :", anagreg_var.get())
        print("freqmin :", freqmin_var.get())
        print("nax :", nax_var.get())
        print("nvt :", nvt_var.get())
        print("Detail :", Detail_var.get())
        print("seuil_vt :", seuil_vt_var.get())
    
#   Final Buttons (Show, Execute)
#
    ttk.Button(menu_frame, text="(Show the parameter values)", command=afficher_valeurs).grid(row=row, column=1, pady=5)
    row+= 1
    ttk.Button(menu_frame, text="4) Execute", command=lancer_programme, style = "My.TButton").grid(row=row, column=1, sticky="w",padx=10, pady=10)
    
#----------------------------------
    def on_mousewheel(event):
        canvas.yview_scroll(int(-1*(event.delta/120)), "units")
#----------------------------------
    canvas.bind_all("<MouseWheel>", on_mousewheel) 
    
    root.mainloop()
    return paraliste
#-----------------------------------------
#  main() call...
#-----------------------------------------
main()
#-----------------------------------------

