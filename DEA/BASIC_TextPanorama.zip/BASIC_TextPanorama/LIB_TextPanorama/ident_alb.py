# Modif des idents, version 09 09 2024
#----------------------------------
# Appel : id_alb = identif_alb(piste)
# identification des albums par la colonne de "identif_alb.csv"  
# piste = "identif_alb.csv"
import pandas as pd; import numpy as np
def identif_alb (piste):
#---- nouveau 09 09 24 ---------- nouveaux idents pour les albums
    TAsup = pd.read_csv(piste, index_col = 0, encoding='ansi')
    p,q = TAsup.shape
#    catv = np.zeros(p)
    id_alb = np.empty(p, dtype = 'U20')  # ***** essai en cours
#
    lid_alb = len(id_alb)
    for i in range (p):
        id_alb[i] = TAsup.iloc[i,0]
#-----------------
    return (id_alb)