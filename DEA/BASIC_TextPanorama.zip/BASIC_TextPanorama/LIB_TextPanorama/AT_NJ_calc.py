#import os
#os.chdir("C:/Comm2024/JADT_2024/AT_2023/Py_3_12")
#import sys     (optional)
#import Test_NJ11
#from Test_NJ11 import *
#adj = AT_NJ11(p, disMatrix, ident)
#***************
import numpy as np
from pathlib import Path
#***************
def AT_NJ_calc(output_results, p, disMatrix, ident):          #new
#    p, disMatrix, ident = readFromFile()  #new
    adj = run_AT_NJ(disMatrix, p)   #new
    ch_edge = save_edge(output_results, adj)
    ch_gml = create_gml(output_results, ch_edge, ident)  #new
    return  ch_edge , ch_gml         #newnew
#----------------
def save_edge(output_results, adj):            # création de "edge.txt"
#****************************
    namefig = "edge"
    dossier = Path(output_results)       
    ch_edge = dossier / f"{namefig}.txt"
#----
    fe = open(ch_edge, "w")       
#-----------------------------------
#    fe = open('edge.txt', 'w')
    ii = 0
    for i, nodes in enumerate(adj):
        for d, w in nodes:
            if(i<d):
                fe.write(str(ii)+'   '+str(d)+'  '+'%0.3f' % w +'\n')
                ii = ii + 1
    fe.close()
    return ch_edge

            
#def printDistMatrix(distMatrix):
#    for d in distMatrix:
#        print(' '.join([str(i) for i in d]))
            
def printIdent(ident):   #new
    print(' '.join([str(a) for a in ident]))
    
def run_AT_NJ(disMatrix, p):
    D = np.array(disMatrix, dtype = float)
    clusters = [i for i in range(p)]
    adj = [[] for i in range(p)]
    if len(D) <= 1:
        return adj
    while True:
        if 2 == p:
            adj[len(adj)-1].append((len(adj)-2, D[0][1]))
            adj[len(adj)-2].append((len(adj)-1, D[0][1]))
            break
        totalDist = np.sum(D, axis = 0)
        D1 = (p-2) * D
        D1 = D1 - totalDist
        D1 = D1 - totalDist.reshape((p, 1))
        np.fill_diagonal(D1, 0.)
        #print(D1)
        index = np.argmin(D1)
        i = index // p
        j = index % p
        delta = (totalDist[i] - totalDist[j])/(p-2)
        li = (D[i, j]+delta)/2
        lj = (D[i, j]-delta)/2
        d_new = (D[i, :]+D[j, :]-D[i, j])/2
        D = np.insert(D, p, d_new, axis = 0)
        d_new = np.insert(d_new, p, 0., axis = 0)
        D = np.insert(D, p, d_new, axis = 1)
        D = np.delete(D, [i, j], 0)
        D = np.delete(D, [i, j], 1)
        #print(D)

        m = len(adj)
        adj.append([])
        adj[m].append((clusters[i], li))
        adj[clusters[i]].append((m, li))
        adj[m].append((clusters[j], lj))
        adj[clusters[j]].append((m, lj))
        if i < j:
            del clusters[j]
            del clusters[i]
        else:
            del clusters[i]
            del clusters[j]
        clusters.append(m)
        
        p -= 1
    
    return adj

#
def create_gml(output_results,ch_edge, ident):   #new
    g1 = open(ch_edge, 'r')
# here, creating h with output_results   **************
    namefig = 'graph_NJ'
    dossier = Path(output_results)       
    ch = dossier / f"{namefig}.gml"
    ch_gml = open(ch,'w')
#    g1 = open('edge.txt', 'r')   old
#    h = open('graph_NJ.gml','w')
#--------------------------------------
    name = ident
    ch_gml.write('graph\n [ \n'  + '  directed 0\n' + '  title "Graph_NJ"\n')
    lenname = len(name)
    for i in range(lenname):
        ch_gml.write('  node\n   [ \n   id  ' + str(i) + '\n   name "' + name[i]+'"\n   ]\n')
#     supplementary nodes,, beyond len(name)        
    aa = g1.readlines()
    ledges = len(aa)
    nodesup = ledges - lenname + 1
    for i in range(nodesup):
        iplus = i + lenname
        ch_gml.write('  node\n   [ \n   id  ' + str(iplus) + '\n   name "' + str(iplus + 1)+'"\n   ]\n')
    for j in range(ledges):
        source = aa[j].split()[0]
        target = aa[j].split()[1]
        length = aa[j].split()[2]
        ch_gml.write('  edge\n   [ \n   source ' + str(source) + '\n   target ' + str(target)+'\n   length ' + str(length)+'\n   ]\n')
    ch_gml.write(' ] \n')
    ch_gml.close()
    #**********************
    return  ch_gml  #new

