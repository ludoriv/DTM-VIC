#Drawing the tree with categories (Albums/Topics/poems)
# coord_album, nalbum, idalb issued from coordalbums in coord_alb.py
#coord_v : coordinates of vertices
# idalboot created by:  create_idalboot (below).
#------------------------------------------------------
import numpy as np ; import matplotlib.pyplot as plt
from pathlib import Path
#------------------------------------------------------
def Treecatalboot (output_results, categ, catv, id_v_topic, coord_v, fsize, coord_album_replic, nalbum, ntot, idalboot, nreplic):
#
#*****
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****
    ligne = "Tree album boot new started \n------------\n" ; print (ligne)
    lid_v_topic = len(id_v_topic)   # lid_v_topic = number of vertices
#
    p = len(catv)
# 
    for i in range(p,lid_v_topic):
        id_v_topic[i] = " "
    cv = np.asarray(coord_v)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
#
    xh_album = coord_album_replic[:,0]
    xv_album = coord_album_replic[:,1]
#
# reframings and dilatation of vertices and albums.
    exh= np.std(xh)  ; exv= np.std(xv)
    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#    
    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
    xh_album *= coefh_album ; xv_album *= coefv_album
# end of reframings and dilatation of words and albums.
#**************************
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/'edge.txt'
    g1 = open(ch, 'r')
    aa = g1.readlines()
    ledges = len(aa)
    so = np.zeros(ledges)   # source
    ta = np.zeros(ledges)   # target
    for j in range (ledges):
        so[j] = aa[j].split()[0]
        ta[j] = int(aa[j].split()[1]) # note the "int"
#--- a to widen the frame 
    a = 0.1
#-------
    FS_alb = 12    # Font size_Albums
    FS_replic = 8  # FontSize replication boot.
    FS_vert = 8    # FS =Fontsize vertices  
#-------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
    fig, axes = plt.subplots(figsize = (lax_h,lax_v))
#***** Window top left (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
#************************* 
    for j in range (ledges):
        ij = int(ta[j])
        i1h = xh[j]; i2h = xh[ij]; i1v = xv[j] ;i2v = xv[ij]
#        
        plt.plot ( [i1h, i2h], [i1v,i2v], color = 'crimson', linewidth = 1.1)
#------------------------------------------------------
    for i in range(lid_v_topic):       # vertices
        plt.annotate (id_v_topic[i],(xh[i], xv[i]), fontsize = FS_vert, color = 'black', weight = 'bold')
#---------- print albums
    for lc in range(nalbum):       # albums
#---------- outliers in the frame
        if(xh_album[lc] > lmaxh):
            xh_album[lc] = lmaxh - a
        if(xh_album[lc] < lminh):
            xh_album[lc] = lminh + a
        if(xv_album[lc] > lmaxv):
            xv_album[lc] = lmaxv -a
        if(xv_album[lc] < lminv):
            xv_album[lc] = lminv +a
#------------------------------------
        plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_alb, weight = 'bold', color = 'green')
        #
    if (nreplic == 1):
        for lc in range(nalbum, ntot):
            plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_replic, color = 'blue')
            Namefig = "Tree_3_Albums_and_Boot_Replicates_" + categ
            plt.title("AT with albums: saved as:" + Namefig + ".jpg")
    else:
        Namefig = "Tree_3_with_Albums_(topics, categories)" + categ
#  ---    
    plt.show()
#-------------------------------    
    dossier = Path(output_results)       
    fichier = dossier / f"{Namefig}.jpg"
    fig.savefig(fichier)
#-------------------------------
    return xh_album, xv_album
#
def Print_coord_albST(output_results, xh_album, xv_album, idalboot ):
# creating the file "Coord_Albums_bootS.txt" in folder "Results" 
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/"Coord_Albums_bootS.txt"
    g = open(ch, "w+")
    print ("\n The albums coordinates are in the created file: " + g.name)
    g.write("num ident x y \n")
    p = len(xh_album.tolist())
    for i in range(p):
        ah = str(xh_album[i])
        av = str(xv_album[i])
        g.write( str(i+1)+" " + str(idalboot[i]) + " " + ah[:6] + "   " + av[:6] + "\n" )
    g.close()
    return
#
#
def create_idalboot2(nalbum, nboot, piste):
# This function read the data file of category identifiers "piste.csv"
    import pandas as pd; import numpy as np
    piste = pd.read_csv(piste, index_col = 0, encoding='UTF-8')
    p= nalbum*(nboot +1) ; idalboot = np.empty(p, dtype = 'U20')
#
    idalboot_num = [0]*p
    istart = 0
    for i in range (nalbum):
        idalboot[i] = piste.iloc[i,0]
    for j in range(nboot):
        istart = nalbum*(j+1)
        ifin = istart + nalbum
        for i in range(istart, ifin):
            idalboot[i] = i +1 - istart
            idalboot_num[i] = i - istart
#-----------------
    return (idalboot, idalboot_num)