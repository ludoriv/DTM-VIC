# calcul des coordonnées des mots
import matplotlib.pyplot as plt
import numpy as np
#
def coor_mots(F, fi, coord_v):
    ff = fi.tolist()
    n = F.shape[1]
    nmot = len(fi)
    FI = np.zeros((nmot, n))
    for imot in range(nmot):
        for kt in range(n):
            FI[imot, kt] = F.iloc[imot,kt]/ff[imot]
#
    nax = 2
    coorm = np.zeros((nmot, nax))
    for imot in range(nmot):
        for jax in range(nax):
            for kt in range(n):
                coorm[imot,jax] += coord_v[kt][jax] * FI[imot,kt]
    return (coorm)
#-------------------------------------------------------
def graf_words ( F, coorm):
    nmot = F.shape[0]
    findex = F.index.tolist()
    xh = coorm[:,0] ; xv = coorm[:,1]
    lax = 8
    fig, axes = plt.subplots(figsize = (lax,lax))
#***** Caler la fenêtre en haut à gauche (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
#
    mi_x, ma_x = min(xh), max(xh)
    axes.set_xlim (mi_x,ma_x)
    mi_y, ma_y = min(xv), max(xv)
    axes.set_ylim (mi_y,ma_y)

    FS = 7   # FS = fontsize
    for i in range(nmot):
        plt.annotate (findex[i], (coorm[i,0], coorm[i,1]), fontsize = FS, color = 'b')
#        
    plt.plot([mi_x, ma_x],[0,0], color = 'blue', linestyle = "-",linewidth = 1)
    plt.plot([0,0],[mi_y, ma_y ], color = 'blue', linestyle = "-",linewidth = 1)
    plt.title("Words (rows) plane of the NJ tree ")
    plt.xlabel("axis 1")
    plt.ylabel("axis 2")
    plt.show()
    return