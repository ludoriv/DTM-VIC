from pathlib import Path
import Tree_cat as cat ; import numpy as np
def forest(output_results, catv, id_v_topic, p, coord_v):
    idnew = np.empty(p, dtype = 'U20')
    ncat = max(catv)  # ok
    print( "\n ncat = " + str(ncat) + "\n")
    fsize = 2
    for k in range(int(ncat)):
        print( "\n Tree number = " + str(k+1) + "\n")
        for i in range(p):
            if(int(catv[i]) == k+1):
                titre = id_v_topic[i]
                idnew[i] = titre
            else:
                idnew[i] = ""
        cat.Treecat(output_results, p, idnew, coord_v)
    return idnew