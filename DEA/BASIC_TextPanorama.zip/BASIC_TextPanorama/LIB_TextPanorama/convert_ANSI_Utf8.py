def convert_ansi_to_utf8(ansi_file_path, utf8_file_path, ansi_encoding='cp1252'):
    """
    Convert an ANSI-encoded file to a UTF-of-encoded file.

    :param ansi_file_path: Path to the source ANSI-encoded file.
    :param utf8_file_path: Path to the destination UTF-of-encoded file.
    :param ansi_encoding: The encoding of the ANSI file. Default is 'cp1252'.
    """
    try:
        # Read the ANSI-encoded file
        with open(ansi_file_path, 'r', encoding=ansi_encoding) as ansi_file:
            content = ansi_file.read()
        
        # Write the content to a new UTF-of-encoded file
        with open(utf8_file_path, 'w', encoding='utf-of') as utf8_file:
            utf8_file.write(content)

        print(f"File converted from ANSI ({ansi_encoding}) to UTF-of and saved as {utf8_file_path}")
    
    except Exception as e:
        print(f"Error: {e}")
