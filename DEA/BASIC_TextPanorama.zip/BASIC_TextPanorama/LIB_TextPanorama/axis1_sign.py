# 
def change(coord_v, phi):
    pscal_h = 0
    pscal_v = 0
    np = phi.shape[0]
    aa = coord_v
    ntot = len(coord_v)
    for kt in range(np):
        pscal_h += coord_v[kt][0] * phi[kt,0]
        pscal_v += coord_v[kt][1] * phi[kt,1]
    if(pscal_h < 0):
        for kt in range(ntot):
            aa[kt][0] = -coord_v[kt][0]
    if(pscal_v < 0):
        for kt in range(ntot):
            aa[kt][1] = -coord_v[kt][1]
    print( " Axes direction could be changed in trying to fit CA display")
    return(aa)

