#Tracé du plan des éléments terminaux de l'arbre, en suppl. : albums (recueils)
# coord_album, nalbum, idalb genérés par coordalbums dans coord_alb.py
#coord_v : coordonnées des points
import numpy as np ; import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull
from pathlib import Path
def SAT_catalb_hulls (output_results, catv, id_CA_topic, coord_v, fsize, coord_album, nalbum, idalb, categ, colors):
# The chain categ will be part of the title of the figures
#*****

    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****
    ligne = "CA album new started \n------------\n" ; print (ligne)
    lid_CA_topic = len(id_CA_topic)   # 
#
    p = len(catv)
#
    cv = np.asarray(coord_v)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
#
    xh_album = coord_album[:,0]
    xv_album = coord_album[:,1]
#
#**************************
# recadrages et dilatation des points et albums.
    exh= np.std(xh)  ; exv= np.std(xv)
    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#    
    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
    xh_album *= coefh_album ; xv_album *= coefv_album
# fin des recadrages et dilatation des mots et albums.
    FS_vert = 12 ; a = 0.1 # FS =Fontsize points    
    if (fsize == 1):
        FS_vert = 10  # FS =Fontsize points  
#-------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
    fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#*****-------------- Window top left (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****------------------------------------
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
    for i in range(len(catv)):       # points
        plt.annotate (id_CA_topic[i],(xh[i], xv[i]), fontsize = FS_vert, color = 'black')
    FS_alb = 14 
#---------- print albums
    for lc in range(nalbum):       # albums
#---------- outliers in the frame
        if(xh_album[lc] > lmaxh):
            xh_album[lc] = lmaxh - a
        if(xh_album[lc] < lminh):
            xh_album[lc] = lminh + a
        if(xv_album[lc] > lmaxv):
            xv_album[lc] = lmaxv -a
        if(xv_album[lc] < lminv):
            xv_album[lc] = lminv +a
#------------------------------------
        plt.annotate (idalb[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_alb, weight = 'bold', color = 'green')
    Namefig = "SA_Tree_ident_cat_and_albums_Convex_Hulls, " + categ
    plt.title("SA_Tree with new ident and album: saved as:" + Namefig + ".jpg")
#    
    nax = 2
    for ialbum in range (nalbum):
#        istart = (ialbum)*nboot
        eff = 0
        for nson in range(p):
            if(int(catv[nson])== ialbum + 1):
                eff+= 1
        points = np.zeros([eff, nax])	# pour chaque album
        index = -1
        for nson in range(p):
            if(int(catv[nson])== ialbum + 1):
                index = index + 1
                points[index, 0] = xh[nson]
                points[index, 1] = xv[nson]
#        print("\n  ialbum = " + str(ialbum +1) +" \n")
#        print(points)
#
        color = colors[ialbum]
#
    # Enveloppe convexe
        hull = ConvexHull(points)
        for simplex in hull.simplices:
            plt.plot(points[simplex, 0], points[simplex, 1], color=color)
#--- tracé des axes
    lax = 8
    plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
    plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
    # titles and tags
    ax_h = 1 ; ax_v = 2
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
    plt.title("Active rows + albums, plane "+str(ax_h)+", "+str(ax_v)+" saved as: " + Namefig)
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
    plt.show()
#-------------------------------    
    dossier = Path(output_results)
    fichier = dossier / f"{Namefig}.jpg"
    fig.savefig(fichier)
#-----------------------------------------------------
    return 
#

