#Tracé de l'arbre avec albums (recueils)
# coord_album, nalbum, idalb genérés par coordalbums dans coord_alb.py
#coord_v : coordonnées des vertices
# APPEL:
#xh_album, xv_album = CAcatalbootellipses (catv, nid, ident, coord_v, fsize, coord_album_replic, nalbum, nboot, idalboot, categ, nreplic, colors)
# Attention : nboot au lieu de ntot dans les parametres
# Attention: nalbum doit être < 32 (colors...)
# Attention, nouveau parametre : nid (= 1 : identif par ident)
from pathlib import Path
def CAcatalbootellipses (output_results, list_ellipse, catv, nid, ident, coord_v, fsize, coord_album_replic, nalbum, nboot, idalboot, categ, nreplic, colors):
    import numpy as np; import matplotlib.pyplot as plt;from sklearn.decomposition import PCA;from scipy.stats import chi2; import matplotlib.transforms as transforms ; from matplotlib.patches import Ellipse ;import ZoneEllipse as zone
#*****
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****
    ligne = "CA album boot ellipses started \n------------\n" ; print (ligne)
    lident = len(ident)   # lident = nombre de vertices
#
    p = len(catv)
#
    cv = np.asarray(coord_v)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
    xh_album = coord_album_replic[:,0]
    xv_album = coord_album_replic[:,1]
#
#**************************
# recadrages et dilatation des vertices et albums.
    exh= np.std(xh)  ; exv= np.std(xv)
    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#
    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
    xh_album *= coefh_album ; xv_album *= coefv_album
# fin des recadrages et dilatation des mots et albums.
#**************************
#--- a to widen the frame  = 0.1 le 22 05 2024
    a = 0.1
#-------
    FS_vert = 8   # FS =Fontsize vertices (weight = 'bold')  
    FS_alb = 10    # Font size_Albums
    FS_replic = 8  # FontSize replication boot.
#-------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
#-------------
    fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#***** Caler la fenêtre en haut à gauche (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
#------------------------------------------------------
    for i in range(lident):       # vertices
        plt.annotate (ident[i],(xh[i], xv[i]), fontsize = FS_vert, color = 'black', weight = 'bold')
#
#---------- print albums
    for lc in range(nalbum):       # albums
#---------- outliers in the frame
        if(xh_album[lc] > lmaxh):
            xh_album[lc] = lmaxh - a
        if(xh_album[lc] < lminh):
            xh_album[lc] = lminh + a
        if(xv_album[lc] > lmaxv):
            xv_album[lc] = lmaxv -a
        if(xv_album[lc] < lminv):
            xv_album[lc] = lminv +a
#------------------------------------
        plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_alb, weight = 'bold', color = 'green')
        #
    FS_Replicate = 8
    ntot = nalbum*(nboot + 1)
    if(nreplic == 1):
        for lc in range(nalbum, ntot):
            plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_replic, color = 'red')
#--------------------------------------------------------------
# Impression des ellipses
#--------------------------------------------------------------
    nax = 2
#--------------------------------------------------------------
    list_replic, nreplic, icat = zone.list_boot(output_results, nalbum, nboot)
#--------------------------------------------------------------
#
    for ialbum in range (nalbum):
        istart = (ialbum)*nboot
        points = np.zeros([nboot, nax])	# pour chaque album
        for i in range (nboot):
            for j in range (nax):
                points [i, j] = list_replic[i + istart,j]
        color = colors[ialbum]
#
        if(nid == 1):
            axes.scatter(points[:, 0], points[:, 1], s=10, alpha=0.3, color = color)
        if(ialbum in list_ellipse):
            zone.plot_confidence_ellipse2(points[:, 0], points[:, 1], axes,
                        n_std=2,
                        edgecolor='black',
#                        linewidth=1,
                        linewidth=2,
                        linestyle='-',
                        facecolor='lightblue',
                        alpha=0.3)
    axes.set_title("Ellipses de confiance à 95% autour de " + str(nalbum) + " nuages de réplications")
    axes.set_xlabel("X")
    axes.set_ylabel("Y")
#--- tracé des axes ***************************
    lax = 8
    plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
    plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
    # titles and tags
    ax_h = 1 ; ax_v = 2
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
#-------------------------------------------------
# ** ** ** ** ** modif provisoire du 21 09 2025 ci-dessous
    #axes.axis('equal')    
    Namefig = "CA_6_CA_albums_(topics_categories)_boot_Ellipses"+categ
    plt.title("Fig. saved as:" + Namefig + ".jpg")
#  ------------------ Fin de l'impression des ellipses    
    plt.show()
#    save_name = Namefig + ".jpg"
#-------------------------------    
    dossier = Path(output_results)       
    fichier = dossier / f"{Namefig}.jpg"
    fig.savefig(fichier)
#-------------------------------
#    fig.savefig(save_name)
    return xh_album, xv_album
#