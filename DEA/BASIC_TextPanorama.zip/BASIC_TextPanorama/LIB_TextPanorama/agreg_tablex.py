#----------- 
def agregtablex(ch_csv, output_results, sentier, piste):
    import pandas as pd ; import numpy as np
    from pathlib import Path
# 1. Lire les fichiers CSV
# old:     tablex = pd.read_csv("tablexfile.csv", index_col=0) ;sentier_n = pd.read_csv(sentier) ; piste_n = pd.read_csv(piste) 
#
#    tablex = pd.read_csv(ch_csv, index_col=0)
    print("**********")
    print(ch_csv)
    print("**********")
    sentier_n = pd.read_csv(sentier)
    piste_n = pd.read_csv(piste) 
    tablex = pd.read_csv(ch_csv, index_col=0,  encoding='ansi')
    X = tablex.to_numpy()
    Va = sentier_n.to_numpy()
    V = Va[:,1]
    W = V-1
    k = np.max(W)  + 1 
# 2. Initialisation du résultat
    Y = np.zeros((X.shape[0], k))
#
# 3. Agrégation
    for i in range(k):
        Y[:, i] = X[:, W == i].sum(axis=1)
#
    print(Y)
#---------------
    a = piste_n[' ident'].to_list()
    aa = (tablex.index).to_list()
    Y_df = pd.DataFrame(Y, index = aa, columns = a)
#--------------------------------
#   tablex_agreg_semicolon.csv is printed in DATA/Results (not read afterwards)
#   The separator "semicolon" concerns several European versions of XL
#   tablexfile_agreg.csv is printed in BASE (it will be read aftewards...)
    namefig = 'tablex_agreg_semicolon'
    dossier = Path(output_results)       
    ch_semicolon = dossier / f"{namefig}.csv"
#-------------------------------    
    namefig1 = 'tablexfile_agreg'
    ch_classic = dossier / f"{namefig1}.csv"
    Y_df.to_csv(ch_classic, sep = ',', index = True)
    Y_df.to_csv(ch_semicolon, sep = ';', index = True)
#  warning: (le fichier ne peut pas remplaces un fichier de même nom, si ouvert ailleurs..).
    return ch_classic