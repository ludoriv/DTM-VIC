import matplotlib.pyplot as plt ; import matplotlib.transforms as transforms ; from matplotlib.patches import Ellipse
import numpy as np
from pathlib import Path
#------------------------
def plot_confidence_ellipse2(x, y, ax, n_std=1.0, facecolor='none',
                            edgecolor='black', linewidth=1.5, linestyle='-',
                            **kwargs):
    if x.size != y.size:
        raise ValueError("x and y must have the same size")

    # Computation of means and of covariance matrix
    cov = np.cov(x, y)
    mean_x = np.mean(x)
    mean_y = np.mean(y)

    # SVD (Singular Values Decomposition)
    eigvals, eigvecs = np.linalg.eigh(cov)
    order = eigvals.argsort()[::-1]
    eigvals, eigvecs = eigvals[order], eigvecs[:, order]

    # Angle of rotation of the ellipse
    angle = np.degrees(np.arctan2(*eigvecs[:, 0][::-1]))

    # Width and Height of the ellipse (2 * n_std)
    width, height = 2 * n_std * np.sqrt(eigvals)

    # Creation of ellipse
    ellipse = Ellipse((mean_x, mean_y),
                      width=width, height=height,
                      angle=angle,
                      facecolor=facecolor,
                      edgecolor=edgecolor,
                      linewidth=linewidth,
                      linestyle=linestyle,
                      **kwargs)

    ax.add_patch(ellipse)
    return ellipse
#
def list_boot(output_results, nalbum, nboot):
#  Builds "list_replic" from "Coord_Albums_bootS.txt"
    import pandas as pd ; import numpy as np
#---------------------    
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/"Coord_Albums_bootS.txt"    
    df = pd.read_csv(ch, delim_whitespace=True)
    ntot = nalbum*(nboot + 1)
    nax = 2
    nreplic = nboot*nalbum
    icat = np.zeros(nreplic)
    list_replic = np.zeros([nreplic, nax])
    for i in range(nalbum, ntot):
        icat[i-nalbum] = df.iloc[i,1]
    for ialbum in range(1, nalbum + 1):
        points = selec_cloud(ialbum, nalbum, nboot, df, icat, nax)
        istart = (ialbum-1)*nboot
        for irep in range (nboot):
            list_replic [irep + istart, 0] = points[irep,0]
            list_replic [irep + istart, 1] = points[irep,1]
#    print(list_replic)  # possible control
    return list_replic, nreplic, icat 
#
def selec_cloud(ialbum, nalbum, nboot, df, icat, nax):
    import pandas as pd ; import numpy as np
    ideb = 0
    ntot = nalbum*(nboot + 1)
    points = np.zeros([nboot, nax])	# for each album
    for i in range(ntot - nalbum):
        if(int(icat[i]) == ialbum):
            points[ideb, 0] = df.iloc[i + nalbum, 2]
            points[ideb, 1] = df.iloc[i + nalbum, 3]
            ideb = ideb + 1
#
    return points
