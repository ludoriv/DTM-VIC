# Ploting the tree
#----------------------------------
#E identification of "sonnets" (poems, songs, texts) with the column 2 of: "sentier.csv" 
#F identification des sonnets par la seconde colonne de "sentier.csv" 
import igraph as ig; import matplotlib.pyplot as plt; import pandas as pd
from pathlib import Path
#----------------------------------
def Treebase (ch_gml, output_results, n):
#***** cadrage...
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****
    g = ig.load(ch_gml.name)
#F----------- modif pour supprimer les num des vertices internes
#F----------- pas possible de modifier g.vs["name"], d'où id_v:
    id_v = g.vs["name"]
    lid_v = len(id_v)
    for i in range(n,lid_v):
        id_v[i] = " "
#-----------------
    fig, ax = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#    fig, ax = plt.subplots(figsize=(12,8))
#F***** Caler la fenêtre en haut à gauche (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
    ig.plot(
    g,
    target=ax,
    layout="kamada_kawai", # print nodes in kamada_kawai layout
    vertex_size=2,
    vertex_color="black" ,
    vertex_frame_width=1.0,
    vertex_frame_color="black" ,
    vertex_label=None,
    edge_width=1,
    edge_color="crimson")
    layout = g.layout("kamada_kawai")
    for i, (x, y) in enumerate(layout):
        ax.text(
        x, y,
        str(id_v[i]),
        fontname="Arial",
        fontsize=10,
        fontweight="bold",
        ha="center",
        va="center"
        )
#    vertex_label= id_v,   #---  new 5 12 23
#    vertex_label_font="Calibri Bold",
#
#    vertex_label_size=8.0,
#    edge_width=1,
#    edge_color="crimson",
#    target_title = "T1_Tree_base.jpg"
#    )
#-----------------
    plt.title("Basic Additive Tree, saved as : Tree_1_Tree_base.jpg")
    plt.show()
    dossier = Path(output_results)
    namefig = 'Tree_1_Tree_base'   
    fichier = dossier / f"{namefig}.jpg"
    fig.savefig(fichier)

#
    layout2 = g.layout(layout = 'kamada_kawai')
    coord_v = layout2.coords
    return (id_v, coord_v)
