#Tracé de l'arbre avec albums (recueils)
# coord_album, nalbum, idalb genérés par coordalbums dans coord_alb.py
# idalboot généré par create_idalboot (ci-dessous).
#coord_v : coordonnées des vertices
# APPEL:
#xh_album, xv_album = CAcatalboot (output_results, catv, ident, coord_v, fsize, coord_album_replic, nalbum, ntot, idalboot)
from pathlib import Path
import numpy as np ; import matplotlib.pyplot as plt
def CAcatalboot (output_results, catv, ident, coord_v, fsize, coord_album_replic, nalbum, ntot, idalboot):
#
#*****
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****
    ligne = "CA album boot new started \n------------\n" ; print (ligne)
    lident = len(ident)   # lident = nombre de vertices
#
    p = len(catv)
#    titre = "Albums_(supplementary)"
#    for i in range(p,lident):   # 
#        ident[i] = " "
    cv = np.asarray(coord_v)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
#
    xh_album = coord_album_replic[:,0]
    xv_album = coord_album_replic[:,1]
#
#**************************
# recadrages et dilatation des vertices et albums.
    exh= np.std(xh)  ; exv= np.std(xv)
#    exh_mot= np.std(xh_mot)  ; exv_mot= np.std(xv_mot)
    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#    
#    coefh = exh/exh_mot ; coefv = exv/exv_mot
 #   xh_mot = xh_mot*coefh ; xv_mot = xv_mot*coefv
#
    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
    xh_album *= coefh_album ; xv_album *= coefv_album
# fin des recadrages et dilatation des mots et albums.
#**************************
#--- a to widen the frame  = 0.1 le 22 05 2024
    a = 0.1
#-------
    FS_vert = 8   # FS =Fontsize vertices   
    FS_alb = 12    # Font size_Albums
    FS_replic = 8  # FontSize replication boot.
#-------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
#-------------
    fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#***** Caler la fenêtre en haut à gauche (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#    fig, axes = plt.subplots(figsize = (lax_h,lax_v))
#    plt.subplots_adjust(left= 0.0)
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
#------------------------------------------------------
    for i in range(lident):       # vertices
        plt.annotate (ident[i],(xh[i], xv[i]), fontsize = FS_vert, weight = 'bold', color = 'black')
#
#---------- print albums
    for lc in range(nalbum):       # albums
#---------- outliers in the frame
        if(xh_album[lc] > lmaxh):
            xh_album[lc] = lmaxh - a
        if(xh_album[lc] < lminh):
            xh_album[lc] = lminh + a
        if(xv_album[lc] > lmaxv):
            xv_album[lc] = lmaxv -a
        if(xv_album[lc] < lminv):
            xv_album[lc] = lminv +a
#------------------------------------
        plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_alb, weight = 'bold', color = 'green')
        #
    for lc in range(nalbum, ntot):
        plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_replic, color = 'red')
    Namefig = "CA_5_albums(topics)_Boot_Replicates"
    plt.title("AT with albums(topics): saved as:" + Namefig)
#--- tracé des axes ***************************
    lax = 8
    plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
    plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
    # titles and tags
    ax_h = 1 ; ax_v = 2
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
#-------------------------------------------------
#  ---    
    plt.show()
#-------------------------------    
    dossier = Path(output_results)       
    fichier = dossier / f"{Namefig}.jpg"
    fig.savefig(fichier)
    #-------------------------------
    return xh_album, xv_album
#
#
#
def Print_coord_albS(output_results, xh_album, xv_album, idalboot ):
#
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/"Coord_Albums_bootS.txt"
#
    g = open(ch, "w+")
    print ("\n The albums coordinates are in the created file: " + g.name)
    g.write("num ident x y \n")
    p = len(xh_album.tolist())
    for i in range(p):
        ah = str(xh_album[i])
        av = str(xv_album[i])
        g.write( str(i+1)+" " + str(idalboot[i]) + " " + ah[:6] + "   " + av[:6] + "\n" )
    g.close()
    return

def Print_coord_albS_CA(output_results, xh_album, xv_album, idalboot ):
#    import numpy as np 
# creating the file "Coord_Albums_bootS.txt" in folder "Results" 
# creating the file (copy) "Coord_Albums_boot_CA.txt" in folder "Results" 
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/"Coord_Albums_bootS.txt"
    g = open(ch, "w+")
    ch_CA = input_dir_new/"Coord_Albums_boot_CA.txt"
    g_CA = open(ch_CA, "w+")
    print ("\n The albums coordinates are in the created file: " + g_CA.name)
    g.write("num ident x y \n")
    g_CA.write("num ident x y \n")
    p = len(xh_album.tolist())
    for i in range(p):
        ah = str(xh_album[i])
        av = str(xv_album[i])
        g.write( str(i+1)+" " + str(idalboot[i]) + " " + ah[:6] + "   " + av[:6] + "\n" )
        g_CA.write( str(i+1)+" " + str(idalboot[i]) + " " + ah[:6] + "   " + av[:6] + "\n" )
    g.close()
    g_CA.close()
    return