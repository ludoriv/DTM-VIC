# Modif des idents, version 21 09 2025
#----------------------------------
# identification des sonnets par la seconde colonne de "Sentier.csv"  
import pandas as pd; import numpy as np
def SupCat_CA (sentier):
#---- -------- nouveaux idents pour les sonnets
    TXsup = pd.read_csv(sentier, index_col = 0, encoding='UTF-8')
    p,q = TXsup.shape
    catv = np.zeros(p)
#    pnode = 2*p-2
    id_v_topic_CA = np.empty(p, dtype = 'U20')  # ***** essai en cours
#
#------ new 8 4 24 ----------
    for i in range (p):
        id_v_topic_CA[i] = TXsup.iloc[i,0]
        catv[i] = TXsup.iloc[i,0]
#-----------------
    return (id_v_topic_CA, catv)

