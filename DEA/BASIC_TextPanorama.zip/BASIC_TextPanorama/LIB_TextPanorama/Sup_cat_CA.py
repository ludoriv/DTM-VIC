# Modif of idents, version 21 09 2025
#----------------------------------
# identification of sonnets (texts) with second column of "Sentier.csv"  
import pandas as pd; import numpy as np
def SupCat_CA (sentier):
#---- -------- New idents for sonnets
    TXsup = pd.read_csv(sentier, index_col = 0, encoding='UTF-8')
    p,q = TXsup.shape
    catv = np.zeros(p)
    id_v_topic_CA = np.empty(p, dtype = 'U20')  
#
#------ 
    for i in range (p):
        id_v_topic_CA[i] = TXsup.iloc[i,0]
        catv[i] = TXsup.iloc[i,0]
#-----------------
    return (id_v_topic_CA, catv)

