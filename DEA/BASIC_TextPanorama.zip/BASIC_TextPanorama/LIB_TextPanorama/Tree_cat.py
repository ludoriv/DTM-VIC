# Drawing the tree with categories (or albums, topics) numbers as identifiers.
#
#coord_v : coordinates of vertices
import numpy as np ; import matplotlib.pyplot as plt
from pathlib import Path
def Treecat (output_results, p, id_v, coord_v):
#
    ligne = "Tree new started \n------------\n" ; print (ligne)
    lid_v = len(id_v)   # lid_v = number of vertices
#
    for i in range(p,lid_v):   # 
        id_v[i] = " "
    cv = np.asarray(coord_v)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
#**************************
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/'edge.txt'
#---------------------
    g1 = open(ch, 'r')
    aa = g1.readlines()
    ledges = len(aa)
    so = np.zeros(ledges)   # source
    ta = np.zeros(ledges)   # target
    for j in range (ledges):
        so[j] = aa[j].split()[0]
        ta[j] = int(aa[j].split()[1]) # note the "int"
#--- a to widen the frame 
    a = 0.01
#-------
    FS_vert = 10
#
#-------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
    fig, axes = plt.subplots(figsize = (lax_h,lax_v))
#***** Window top left (x=0, y = 0) *****
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****************************************
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
#************************* 
    for j in range (ledges):
        ij = int(ta[j])
        i1h = xh[j]; i2h = xh[ij]; i1v = xv[j] ;i2v = xv[ij]
#        
        plt.plot ( [i1h, i2h], [i1v,i2v], color = 'crimson', linewidth = 1.1)
#------------------------------------------------------
    for i in range(lid_v):       # vertices
        plt.annotate (id_v[i],(xh[i], xv[i]), fontsize = FS_vert, color = 'black', fontweight = 'bold')
    Namefig = "Tree_2_TreeBase_category_identifiers"
    plt.title("AT with new ident: saved as:" + Namefig + ".jpg")
#  ---    
    plt.show()
#-------------------------------    
    dossier = Path(output_results)       
    fichier = dossier / f"{Namefig}.jpg"
    fig.savefig(fichier)
#-------------------------------
    return