# Like Grafsimult, but with links with most characteristic words
import numpy as np ; import matplotlib.pyplot as plt
from pathlib import Path
#
def grafACcomplet5 (output_results, X, psi, phi, ax_h, ax_v, nvt, num_vt, nvs):
#*****
	import tkinter as tk
	root = tk.Tk()
	screen_width = root.winfo_screenwidth()
	screen_height = root.winfo_screenheight()
	root.destroy()
#*****
	n,p = X.shape
#--- Frame (same units)
	xh = psi[:,ax_h - 1]
	xv = psi[:,ax_v - 1]
	xh_var = phi[:,ax_h - 1]
	xv_var = phi[:,ax_v - 1]
#--- a to widen the frame 
	lax = 8
	a = 0.01
#------------------
	FS_ind = 8
	FS_var = 8
#------------------
	lminh = min(min(xh), min(xh_var)) - a
	lmaxh = max(max(xh), max(xh_var)) + a
	lminv = min(min(xv), min(xv_var)) - a
	lmaxv = max(max(xv), max(xv_var)) + a
#
	fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#***** Windows top left (x=0, y = 0)
	manager = plt.get_current_fig_manager()
	if hasattr(manager, 'window'):
		manager.window.wm_geometry("+0+0")
	axes.set_xlim (lminh,lmaxh)
	axes.set_ylim(lminv,lmaxv)
#-----------------------------------------------
#    nvt = number of kept test-values.
#   nvs[j] = number of words of test-values > seuil_vt for column j. 
#  num_vt[ivt,jp] for point jp, num_vt is the index of word in the ivt-th place in direction of decreasing valtests
# then the edge links word: im = num_vt[ivt,jp] to point jp.
#**************** 

	keptwords = np.zeros(n) # = 1 if the word is a char-word. = 0 else.
	for jp in range(p):
		aa = int(nvs[jp])   
		if(aa > 0):  
			for ivt in range(aa):  
				im = num_vt[ivt, jp]
				imi = int(im)
				keptwords[imi] = 1
				i1h =  xh_var[jp]
				i2h = xh[imi] 
				i1v = xv_var[jp] 
				i2v = xv[imi]
				plt.plot ( [i1h, i2h], [i1v,i2v], color = 'green', linewidth = 0.5)
	for i in range (n):
		if(keptwords[i] == 1):
			plt.annotate (X.index[i],(psi[i,ax_h - 1], psi[i,ax_v - 1]), fontsize = FS_ind, color = 'b')
#------------------------------------------------------
	for j in range(p):
		plt.annotate (X.columns[j],(phi[j,ax_h - 1], phi[j,ax_v - 1]), fontweight='bold', fontsize = FS_var, color ='black')
#--- Drawing axes
	plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
	# titles and tags
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	namefig = "CA_3_Plane ("+ str(ax_h)+", "+str(ax_v) + ")_with_char_words, basic_ident"    
	plt.title("Active rows + columns, plane "+str(ax_h)+", "+str(ax_v)+" saved as: " +namefig +".jpg")
	plt.show()
#-------------------------------    
	dossier = Path(output_results)          # ou Path("/chemin/vers/B")
	fichier = dossier / f"{namefig}.jpg"
	fig.savefig(fichier)
#-------------------------------
	return 
#---------------------------------------------------

