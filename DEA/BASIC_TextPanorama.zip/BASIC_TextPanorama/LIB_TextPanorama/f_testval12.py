import pandas as pd ; import numpy as np
from pathlib import Path
#--------------------------------
def Test_Val12(output_results, nvt, seuil_vt, lane):
#

    K = pd.read_csv(lane, index_col = 0, encoding='ansi')
#
    n,p = K.shape ; ki = np.sum(K, axis = 1) ; kj = np.sum(K, axis = 0); k = np.sum(kj)
    fi, fj = ki/k, kj/k ; F = K/k
    vtest = calc_testval(F, fi, fj, n, p, kj, k)
    num_vt = np.zeros((nvt,p))
    
    nvs = np.zeros(p)
    
#    seuil_vt    # Threshold for valtest
#--------------------------------
    namefig = "Test_values"

#-------------------------------    
    dossier = Path(output_results)       
    ch = dossier / f"{namefig}.txt"
#-------------------------------

    g = open(ch, "w+")
    for j in range(p):
        print  ("\n  " + str(j+1) +  K.columns[j].rjust(10)[:10] + "     vtest" +  "    within freq. global freq. \n" )
        g.write("\n\n  " + str(j+1) +  K.columns[j].rjust(10)[:10] + "     vtest" +  "    within freq. global freq. \n" )
        bb = np.argsort(-vtest[:,j])

        for i in range(nvt):
            ii = bb[i]
            
            if( vtest[ii, j ] > seuil_vt):
                nvs[j]+=1 
            
            pct = 100*fi.iloc[ii]
            pcj = 100*F.iloc[ii,j]/fj.iloc[j] 
            print(str(i+1) + "  " + K.index[ii].rjust(10)[:10] + "    %6.2f. "    %vtest[ii, j ] + "    %6.2f. " %pcj + "    %6.2f. " %pct)
            g.write("\n" + str(i+1) + "  " + K.index[ii].rjust(10)[:10] + "    %6.2f. "  %vtest[ii, j ]+ "    %6.2f. " %pcj + "    %6.2f. " %pct)
            num_vt[i,j] = ii
    g.close()
    return (num_vt, nvs)
#
def calc_testval(F, fi, fj, n, p, kj, k):
# 
    coef = np.zeros(p)
    for j in range(p):
        coef[j] = (k - kj.iloc[j])/(k - 1)
#
    vf = np.zeros((n,p))

    for i in range(n):
        for j in range(p):
            vf[i,j] = (1./k)*coef[j]*fj.iloc[j]*fi.iloc[i]*(1-fi.iloc[i])
#
    vtest = np.zeros((n,p))

    for i in range(n):
        for j in range(p):
            vtest[i,j] = (F.iloc[i,j] - fi.iloc[i]*fj.iloc[j])/np.sqrt(vf[i,j])
    return (vtest)

