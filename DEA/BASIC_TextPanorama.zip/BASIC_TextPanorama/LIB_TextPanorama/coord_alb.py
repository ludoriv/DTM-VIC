import pandas as pd; import numpy as np
#*************************************************
def coordalbums(catv, coord_v, naxtot):
#
	nalbum = int(max(catv))
	p = len(catv)
#
	nvert = len(coord_v)
#
	cv = np.asarray(coord_v)
	cv_cent = np.zeros((nvert,naxtot))
	coord_album = np.zeros((nalbum, naxtot))
	eff = np.zeros(nalbum)
#
	for k in range(naxtot): 
		cv_cent[:,k] = cv[:,k]  - np.mean (cv[:,k])
#
	for i in range(p):
		lcat = int(catv[i])-1
		eff[lcat] += 1
		for k in range(naxtot):
			coord_album[lcat, k] += cv_cent[i,k]
#
	for lc in range(nalbum):
		for k in range(naxtot):
			coord_album[lc,k] /= eff[lc]
#
	return coord_album, nalbum
