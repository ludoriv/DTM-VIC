# Modif des idents, version 21 04 2024
#----------------------------------
# identification des sonnets par la seconde colonne de "Sentier.csv"  
import pandas as pd; import numpy as np
def SupCat_AT (sentier):
#---- nouveau 12 4 24 ---------- nouveaux idents pour les sonnets
    TXsup = pd.read_csv(sentier, index_col = 0, encoding='ansi')
    p,q = TXsup.shape
    catv = np.zeros(p)
    pnode = 2*p-2
    id_v_topic_AT = np.empty(pnode, dtype = 'U20')  # ***** essai en cours
#
#----------- modif pour supprimer les num des vertices internes
#----------- pas possible de modifier g.vs["name"], d'où id_v_topic:
#    id_v_topic = id_v
    lid_v_topic_AT = len(id_v_topic_AT)
    for i in range(p,lid_v_topic_AT):
        id_v_topic_AT[i] = " "
#------ nouveau 8 4 24 ----------
    for i in range (p):
        id_v_topic_AT[i] = TXsup.iloc[i,0]
        catv[i] = TXsup.iloc[i,0]
#-----------------
    return (id_v_topic_AT, catv)

