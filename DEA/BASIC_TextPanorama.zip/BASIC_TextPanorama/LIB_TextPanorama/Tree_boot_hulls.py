#Tracé de l'arbre avec albums (recueils)
# coord_album, nalbum, idalb genérés par coordalbums dans coord_alb.py
#coord_v : coordinates of vertices
# APPEL:
#(import Tree_boot_hulls as TBH)
#xh_album, xv_album = TBH.Treecatalboothulls (output_results, catv, nid, id_v_topic, coord_v, fsize, coord_album_replic, nalbum, nboot, idalboot, categ, nreplic)
# Attention : nboot au lieu de ntot dans les parametres
# Attention : nouveau param : nid (nid = 1 , idents)
from pathlib import Path
def Treecatalboot_hulls (output_results, catv, nid, id_v_topic, coord_v, fsize, coord_album_replic_AT, nalbum, nboot, idalboot, idalboot_num, categ, nreplic, colors):
    import numpy as np; import matplotlib.pyplot as plt;from sklearn.decomposition import PCA;from scipy.stats import chi2; import matplotlib.transforms as transforms ; 
#    from matplotlib.patches import Ellipse ;
    import ZoneEllipse as zone; 
    from scipy.spatial import ConvexHull
#*****
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
    ligne = "Tree album boot new started \n------------\n" ; print (ligne)
    lid_v_topic = len(id_v_topic)   # lid_v_topic = nombre de vertices
#
    p = len(catv)
#    titre = "Albums_(supplementary)"
    for i in range(p,lid_v_topic):   # 
        id_v_topic[i] = " "
    cv = np.asarray(coord_v)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
#
    xh_album = coord_album_replic_AT[:,0]
    xv_album = coord_album_replic_AT[:,1]
#**************************
# recadrages et dilatation des vertices et albums.
#    exh= np.std(xh)  ; exv= np.std(xv)
#    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#    
#    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
#    xh_album *= coefh_album ; xv_album *= coefv_album
# fin des recadrages et dilatation des mots et albums.
#**************************
#
#************************** Existe dans CA_
# recadrages et dilatation des vertices et albums.
#    exh= np.std(xh)  ; exv= np.std(xv)
#    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#    
#    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
#    xh_album *= coefh_album ; xv_album *= coefv_album
# fin des recadrages et dilatation des albums.
#**************************
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/'edge.txt'
    g1 = open(ch, 'r')
    aa = g1.readlines()
    ledges = len(aa)
    so = np.zeros(ledges)   # source
    ta = np.zeros(ledges)   # target
    for j in range (ledges):
        so[j] = aa[j].split()[0]
        ta[j] = int(aa[j].split()[1]) # noter le "int"
#--- a to widen the frame  = 0.1 le 22 05 2024
    a = 0.1
#-------
    FS_vert = 8   # FS =Fontsize vertices   
    FS_alb = 12    # Font size_Albums
    FS_replic = 8  # FontSize replication boot.
#-------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
    fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#***** Caler la fenêtre en haut à gauche (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
#    plt.subplots_adjust(left= 0.0)
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
#************************* Arbre en rouge
    for j in range (ledges):
        ij = int(ta[j])
        i1h = xh[j]; i2h = xh[ij]; i1v = xv[j] ;i2v = xv[ij]
#        
        plt.plot ( [i1h, i2h], [i1v,i2v], color = 'black', linewidth = 1.1)
#------------------------------------------------------
#    if(nreplic == 1):
    for i in range(lid_v_topic):       # vertices
        plt.annotate (id_v_topic[i],(xh[i], xv[i]), fontsize = FS_vert, color = 'black')
#    FS_alb = 14
#---------- print albums
    for lc in range(nalbum):       # albums
#---------- outliers in the frame
        if(xh_album[lc] > lmaxh):
            xh_album[lc] = lmaxh - a
        if(xh_album[lc] < lminh):
            xh_album[lc] = lminh + a
        if(xv_album[lc] > lmaxv):
            xv_album[lc] = lmaxv -a
        if(xv_album[lc] < lminv):
            xv_album[lc] = lminv +a
#------------------------------------
        plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_alb, weight = 'bold', color = 'green')
        #
#    FS_Replic = 8
    ntot = nalbum*(nboot + 1)
    if(nreplic == 1):
        for lc in range(nalbum, ntot):
            color2 = colors[int(idalboot_num[lc])]  
            plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_replic, color = color2)
#--------------------------------------------------------------
# Impression des convex hulls
#--------------------------------------------------------------
    nax = 2
    list_replic, nreplic, icat = zone.list_boot(output_results, nalbum, nboot)
#
#    colors = ['red', 'green', 'blue','yellow', 'black', 'cyan','steelblue',
#    'pink','limegreen', 'khaki','orange', 'crimson', 'coral', 'silver', 'olive', 'navy' ]
#
    for ialbum in range (nalbum):
        istart = (ialbum)*nboot
        points = np.zeros([nboot, nax])	# pour chaque album
        for i in range (nboot):
            for j in range (nax):
                points [i, j] = list_replic[i + istart,j]
#        print("\n  ialbum = " + str(ialbum +1) +" \n")
#
        color = colors[ialbum]
#        zone.plot_confidence_ellipse(points, axes, edgecolor=color)
        if(nid == 1):
            axes.scatter(points[:, 0], points[:, 1], s=10, alpha=0.3, color = color)
#
    # Enveloppe convexe
        hull = ConvexHull(points)
        for simplex in hull.simplices:
            plt.plot(points[simplex, 0], points[simplex, 1], color=color)
    axes.set_title("Convex Hulls " + str(nalbum) + " clouds of replicates")
    axes.set_xlabel("X")
    axes.set_ylabel("Y")
#
    Namefig = "Tree_5_Boot_convex_hulls "+ categ
    plt.title("Fig saved as:" + Namefig + ".jpg")
#  ------------------ Fin de l'impression des ellipses    
    plt.show()
#-------------------------------    
    dossier = Path(output_results)       
    fichier = dossier / f"{Namefig}.jpg"
    fig.savefig(fichier)
#-------------------------------
    return 
#
