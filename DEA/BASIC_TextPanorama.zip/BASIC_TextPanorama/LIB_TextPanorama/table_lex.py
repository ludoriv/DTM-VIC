#----------------------------------------------------------------------------
#    tablex calls:     1) pre_textes (preprocessing text) thus: "pretexte" 
#                      2) lexic (words frequency)
#                      3) write_tablex (save and print the lexical table)
#----------------------------------------------------------------------------
from pathlib import Path
#----------------------------------------------------------------------------
def tablex(output_results, chemin,  seuil): # seuil = frequency threshold 
	idtex, texte = pre_textes(chemin)   # (preprocessing text)
	nt = len(idtex)      # nt: number of texts
	d = ' '.join(texte)  # liste of texts --> chain "d"
	e = d.split()        # chaine d --> list of words
	motot = lexic(e)     # motot = dictionary with frequencies
	motex = {}
	for mot in motot:
		motex[mot] = [0]*nt   # each word is a vector with nt components
#---------------
	for i in range(nt):   
		for mot in texte[i].split():
			motex[mot][i] += 1   # frequency of word "mot" in text "i"
#----------------
	ch_csv = write_tablex(output_results, motex,motot,idtex, seuil) # copy and print motex
	return ch_csv
#----------------------------------------------------------------------------

#----------------------------------------------------------------------------
def pre_textes (chemin):  # pre_textes returns idtex and texte
#-------- eliminating  separators, textechaine is a chain
	textechaine = blanc(chemin)
	textes = textechaine[4:].split("****") #  texts are split
	idtex = []    # list  of identifiers (titles) of texts
	texte = []    # texts without titles
#---------------- isolating et suppressing titles of texts
	for nt in range (len(textes)):    # for all texts...
		titre = textes[nt].split()[0] # title of text nt est isolated
		idtex.append(titre)           # list of text idtex
		long_titre = len(titre) + 1   # length of title 
		texte.append(textes[nt][long_titre:]) # texts without titles
#----------------
	print(idtex)        # printing titles (control)
	return  idtex,texte # titles (idtex) and list of texts (texte)
#----------------------------------------------------------------------------
#---------- Opening text at "chemin" and replacing separators with spaces
def blanc (chemin):   # blanc returns idtex and text
	import re            # importing  "regular expression" module
	f=open(chemin,"r")   # opening text file
#----------------
	textebrut = f.read() # reading texts
#-------- selected separators become spaces
	textchaine = re.sub(r"[-.:' \";,?=!\n]+"," ",textebrut) # textchaine is a chain
	return textchaine
#-----------------------------------------
#
#----------------------------------------------------------------------------
def lexic( e):  # e = list of words
	motot={}    # motot is a dictionary "words : frequencies"
	for mot in e:
		motot[mot] = 0  
	for  mot in e:
		motot[mot] += 1  # computing motot
	return motot
#-----------------------------------------------------------------------------
#----------------------------------------------------------------------------
#  motex[mot][i] frequency of word "mot" text "i" (dictionary)
#  motot[mot] global frequency of mot (dict)
#-----------------------------------------------------------------------------
def write_tablex(output_results, motex, motot, idtex, seuil):
# ----- copy of table motex in "tablexfile.txt" (format table)
#----------------------------- in "tablexfile.csv" (format csv)
	ntex = len(idtex)  # ----- idtex = identifiers (titles) of texts
	s = sorted(motot)          # words (alphabetical order) 
#--------------------------------
#   tablexfile.txt is printed in DATA/Results (not read afterwards)
#   tablexfile.csv is also printed in DATA/Results (it will be read aftewards...)
	namefig = "tablexfile"
	dossier = Path(output_results)       
	ch = dossier / f"{namefig}.txt"
	ch_csv = dossier / f"{namefig}.csv"
#-------------------------------    
# (old) ch_csv = "tablexfile.csv"
	# (created files) 
	f = open(ch, "w+", encoding="utf-8")         # opening "ch"
	g = open(ch_csv, "w+", encoding="utf-8")     # opening "ch_csv"
#-----------------------------------------------------------------------------
	f.write(14*" ")              # 14 spaces above words ("txt" file)
	g.write ( "Names , ")       # first element of csv file     #new
	for j in range(ntex):        # printing of titles
		f.write(idtex[j].rjust(7)[:7]) # justification over 7 columns
		f.write(" ")                   # space between titles
		g.write(idtex[j])              # identifiers of texts
		if(j < ntex - 1):
#			g.write("; ")     # space between titles ( "; ")
			g.write(", ")     # space between titles  (", ")         # new
	f.write("\n\n")                    # skip a line (Windows)
	g.write("\n")                      # end of line (Windows)
#-----------------------------------------------------------------------------
	for i in range(len(s)):              # printing line i
		if(motot[s[i]] >= seuil): #  selected frequency threshold
			f.write(s[i].rjust(12)[:12]) # printing word i (justif.: 12)
			f.write(" ")                 # space 
			g.write(s[i])                # printing word i 
#			g.write("; ")                # separator 
			g.write(", ")                # separator                   # new
			for j in range(ntex):        # printing of frequency j of word i
				f.write(str(motex[s[i]][j]).rjust(7)[:7]) # printing
				f.write(" ")           # space between frequencies
				g.write(str(motex[s[i]][j])) # printing
				if(j < ntex - 1):
#					g.write("; ")      # separator between frequencies
					g.write(", ")      # separator between frequencies  # new
			f.write("\n")              # end of line
			g.write("\n")              # end of line
#-----------------------------------------------------------------------------
	print("tablex has been saved on files: tablexfile.txt and tablexfile.csv\n")
	print("note that tablexfile.csv uses commas as separators (US convention)\n")
#	f.seek(0)           # beginning of created file
#	tableau = f.read()  # loading file
#	print(tableau)      # printing on screen (control)
	f.close()           # closing file txt
	g.close()           # closing file csv
	return ch_csv
#-----------------------------------------------------------------------------
