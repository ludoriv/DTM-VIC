#Tracé simultané des mots et de l'arbre
#g = ig.load("graph_NJ.gml")
#Voir comment entrer "id_v" (non corrigé)  rappel: id_v = g.vs["name"]
#coord_v : coordonnées des vertices
#coorm : coordonnées des mots 
import numpy as np ; import matplotlib.pyplot as plt
from pathlib import Path
#-----------------------------------
def Tree_simult11 (ch_edge, output_results, F, fi, id_v, coord_v, coorm, nvt, num_vt, nvs):
#
#*****
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****

    ligne = "Words decorated tree started \n------------\n" ; print (ligne)
    
    nmot = len(fi)
    ax_h = 1 ; ax_v = 2
    n = F.shape[1]   # nombre des colonnes initales (présidents)
    lid_v = len(id_v)   # lid_v = nombre de vertices
    findex = F.index.tolist()  # ident des mots
#
    for i in range(n,lid_v):   # 
        id_v[i] = " "
    cv = np.asarray(coord_v)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
    exh= np.std(xh)  ; exv= np.std(xv)
#
    xh_mot = coorm[:,0] - np.mean( coorm[:,0] )  
    xv_mot = coorm[:,1] - np.mean( coorm[:,1] )
    exh_mot= np.std(xh_mot)  ; exv_mot= np.std(xv_mot)
#    
    coefh = exh/exh_mot ; coefv = exv/exv_mot
    xh_mot = xh_mot*coefh ; xv_mot = xv_mot*coefv
#
# fin des recadrages et dilatation des mots.
#**************************
    g1 = open(ch_edge, 'r')
    aa = g1.readlines()
    ledges = len(aa)
    so = np.zeros(ledges) # source
    ta = np.zeros(ledges)   # target
    for j in range (ledges):
        so[j] = aa[j].split()[0]
        ta[j] = int(aa[j].split()[1]) # noter le "int"
# en fait, so[j] = j
#--- a to widen the frame 
    lax = 8
    a = 0.01
    FS_vert = 16 # FS =Fontsize    
    FS_mot = 14
#------------------
    FS_var = 12
#-------
    lminh = min(min(xh), min(xh_mot)) - a
    lmaxh = max(max(xh), max(xh_mot)) + a
    lminv = min(min(xv), min(xv_mot)) - a
    lmaxv = max(max(xv), max(xv_mot)) + a
#---
#-------------
    fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#***** 
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
#*************************
    for j in range (ledges):
        ij = int(ta[j])
        i1h = xh[j]; i2h = xh[ij]; i1v = xv[j] ;i2v = xv[ij]
        plt.plot ( [i1h, i2h], [i1v,i2v], color = 'red', linewidth = 1.1)
#------------------------------- mocar----------------
#    nvt = nombre de valeurs tests gardées.
#    num_vt = vt.Test_Val7(nvt)  Appel inutile si appel séparé de Test_Val7
#  num_vt[ivt,jp] pour le texte jp, num_vt est l'indice du mot 
#  occupant la ivt-ième place dans le sens des valeurs-test décroissantes
# donc l'edge doit joindre le mot: im = num_vt[ivt,jp] au texte jp.
    keptwords = np.zeros(nmot) # = 1 if the word is a char-word. = 0 else 
    for jp in range(n):
        aa = int(nvs[jp])       # new
        if(aa > 0):      # new
            for ivt in range(nvt):
                im = num_vt[ivt, jp]
                imi = int(im)
                keptwords[imi] = 1
                i1h = xh[jp] 
                i2h = xh_mot[imi] 
                i1v = xv[jp] 
                i2v = xv_mot[imi]
                plt.plot ( [i1h, i2h], [i1v,i2v], color = 'green', linewidth = 0.5)
#------------------------------------------------------
    for i in range(lid_v):       # vertices
        plt.annotate (id_v[i],(xh[i], xv[i]), fontsize = FS_vert, fontweight='bold', color = 'green')
    for j in range (nmot):
        if(keptwords[j] == 1):
            plt.annotate (findex[j],(xh_mot[j], xv_mot[j]), fontsize = FS_mot, color ='b')
#    for j in range(nmot):
#        plt.annotate (findex[j],(xh_mot[j], xv_mot[j]), fontsize = FS_mot, color ='b')

#--- tracé des axes
#    plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 0.5)
#    plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 0.5)
    # titles and tags
    plt.title("Words + additive tree (NJ), saved as: AT_with_char_w.jpg ") 
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
    plt.show()
#--------------------------------------
    dossier = Path(output_results)
    namefig = "AT_with_char_words"
    fichier = dossier / f"{namefig}.jpg"
    fig.savefig(fichier)

#--------------------------------------
#    fig.savefig("AT_with_char_w.jpg")
#    plt.show()