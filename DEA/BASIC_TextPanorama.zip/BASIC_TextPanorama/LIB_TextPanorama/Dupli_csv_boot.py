import pandas as pd ; import numpy as np
from pathlib import Path
# 
def Dupli_csv2 (output_results, n_bootstraps,sentier):
# Loading the csv file
    df = pd.read_csv(sentier)  # 
    n = len(df)            # n_bootstraps = 30, e.g.
# List  to stock dataframes
    Duplic = []
    for i in range(n_bootstraps):
    # Drawing with replacement 
        sampled_indices = np.random.choice(n, size=n, replace=True)   
    # number of occurreces
        counts = np.bincount(sampled_indices, minlength=n)
    # Copy of original DataFrame with weights column
        weighted_df = df.copy()
        weighted_df['bootstrap_weights'] = counts
        weighted_df['bootstrap_id'] = i + 1  # ID of the duplication
        Duplic.append(weighted_df)
    # Concatenate replicates
    result_df = pd.concat(Duplic, ignore_index=True)
    # Save
    # creating the file 'sentier_boot.csv' in folder "Results" 
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/'sentier_boot.csv'

    result_df.to_csv(ch, index=False)
    print("File  sentier_boot.csv  generated.")
    df_boot = pd.read_csv(ch)  
    pboot = df_boot['bootstrap_weights']  # pboot = vec pandas
#    print ("pboot = ", pboot)
    pboot_n = pboot.values              # pboot_n = vec numpy
    print("pboot_n (numpy) = ", pboot_n)
    pboot_list =  pboot.tolist()
    return pboot, pboot_n, pboot_list

