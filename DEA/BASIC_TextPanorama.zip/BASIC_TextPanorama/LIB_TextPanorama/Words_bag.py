
#import os ;  os.chdir("C:/Comm2026/JADT_2026/Test_TGV_Paris2/English")
#chemin1 = "Sonnet_LowerCase_1_154_2.txt" ; chemin2 = "Sonnet_LowerCase_1_154_wb.txt" # 
#------------------------------------------------------------
#import Words_bag_m2 ; from Words_bag_m2  import *  
#     program file: Words_bag.py (same folder)
#     call of functions in Words_bag
#-------------------------------------
#wb(chemin1, chemin2) # executing function  wb included in the file Words_bag_m2.py
#       (note that :  seuil = 2 ... default value for the frequency threshold).
#----------------------------------------------------------------------------
#    wb calls:         pre_textes (preprocessing text)
#----------------------------------------------------------------------------
import os; import Lib ; from Lib import * ; import textwrap ; from textwrap import *
#chemin1 = "Brassens_star_140.txt"
#chemin2 = "Brassens_star_140_wb_test.txt"
def wb(chemin1, chemin2): # seuil = frequency threshold
	idtex, texte = pre_textes(chemin1)   # (preprocessing text)
	import re            # importing  "regular expression" module
	nt = len(idtex)      # nt: number of texts
#	d = ' '.join(texte)  # liste of texts --> chain "d"
#	e = d.split()        # chaine d --> list of words
	ch = chemin2
	# (created files) 
	f = open(ch, "w+", encoding="utf-8")         # opening "ch"	
	for i in range(nt):
		e = texte[i].split()
		motot={}    # motot is a dictionary "words : frequencies"
		for mot in e:
			motot[mot] = 0  
		bag = motot.keys()
#		print("****    " + idtex[i])
#		print (bag)
		f.write("****    " + idtex[i] + "\n")
		bag2 = re.sub(r"[',()\[\]]+","",str(list(bag))) # bag2 is a chain
		bag3 = bag2.lower()
		a = textwrap.wrap(str(bag3),80)
		for b in a:
			f.write(b + "\n")
	f.write("====")
	print("Results have been saved on file: " + str(ch) + "\n")
#	f.seek(0)           # beginning of created file
	f.close()
	
	return
#----------------------------------------------------------------------------

#----------------------------------------------------------------------------
def pre_textes (chemin):  # pre_textes returns idtex and texte
#-------- eliminating  separators, textechaine is a chain
	textechaine = blanc(chemin)
	textes = textechaine[4:].split("****") #  texts are split
	idtex = []    # list  of identifiers (titles) of texts
	texte = []    # texts without titles
#---------------- isolating et suppressing titles of texts
	for nt in range (len(textes)):    # for all texts...
		titre = textes[nt].split()[0] # title of text nt is isolated
		idtex.append(titre)           # list of text idtex
		long_titre = len(titre) + 1   # length of title 
		texte.append(textes[nt][long_titre:]) # texts without titles
#----------------
	print(idtex)        # printing titles (control)
	return  idtex,texte # titles (idtex) and list of texts (texte)
#----------------------------------------------------------------------------
#---------- Opening text at "chemin" and replacing separators with spaces
def blanc (chemin):   # blanc returns idtex and text
	import re            # importing  "regular expression" module
	f=open(chemin,"r", encoding="utf-8")   # opening text file
#----------------
	textebrut = f.read() # reading texts
#-------- selected separators become spaces
	textchaine = re.sub(r"[.:' ;,?=!\n]+"," ",textebrut) # textchaine is a chain
	return textchaine
#-----------------------------------------
#
#----------------------------------------------------------------------------
def lexic( e):  # e = list of words
	motot={}    # motot is a dictionary "words : frequencies"
	for mot in e:
		motot[mot] = 0  
	for  mot in e:
		motot[mot] += 1  # computing motot
	return motot
#-----------------------------------------------------------------------------
#----------------------------------------------------------------------------
#  motex[mot][i] frequency of word "mot" text "i" (dictionary)
#  motot[mot] global frequency of mot (dict)
#-----------------------------------------------------------------------------
def write_tablex(motex, motot, idtex, seuil = 2, csv = False):
# ----- copy of table motex in "tablexfile.txt" (format table)
#----------------------------- in "tablexfile.csv" (format csv)
	ntex = len(idtex)  # ----- idtex = identifiers (titles) of texts
	s = sorted(motot)          # words (alphabetical order) 
	ch =     "tablexfile.txt"
	ch_csv = "tablexfile.csv"
	# (created files) 
	f = open(ch, "w+")         # opening "ch"
	g = open(ch_csv, "w+")     # opening "ch_csv"
#-----------------------------------------------------------------------------
	f.write(14*" ")              # 14 spaces above words ("txt" file)
	g.write ( "Titles ; ")       # first element of csv file
	for j in range(ntex):        # printing of titles
		f.write(idtex[j].rjust(7)[:7]) # justification over 7 columns
		f.write(" ")                   # space between titles
		g.write(idtex[j])              # identifiers of texts
		if(j < ntex - 1):
			g.write("; ")              # space between titles
	f.write("\n\n")                    # skip a line (Windows)
	g.write("\n")                      # end of line (Windows)
#-----------------------------------------------------------------------------
	for i in range(len(s)):              # printing line i
		if(motot[s[i]] >= seuil):        #  selected frequency threshold
			f.write(s[i].rjust(12)[:12]) # printing word i (justif.: 12)
			f.write(" ")                 # space 
			g.write(s[i])                # printing word i 
			g.write("; ")                # separator 
			for j in range(ntex):        # printing of frequency j of word i
				f.write(str(motex[s[i]][j]).rjust(7)[:7]) # printing
				f.write(" ")           # space between frequencies
				g.write(str(motex[s[i]][j])) # printing
				if(j < ntex - 1):
					g.write("; ")      # separator between frequencies
			f.write("\n")              # end of line
			g.write("\n")              # end of line
#-----------------------------------------------------------------------------
	print("tablex has been saved on files: tablexfile.txt and tablexfile.csv\n")
#	f.seek(0)           # beginning of created file
#	tableau = f.read()  # loading file
#	print(tableau)      # printing on screen (control)
#	f.close()           # closing file txt
#	g.close()           # closing file csv
	return
#-----------------------------------------------------------------------------
#wb(chemin1, chemin2)



