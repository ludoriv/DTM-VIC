#Tracé de l'arbre avec albums (recueils)
# coord_album, nalbum, idalb genérés par coordalbums dans coord_alb.py
#coord_v : coordonnées des vertices
# APPEL:
#xh_album, xv_album = CAcatalboothulls (output_results, catv, nid, ident, coord_v, fsize, coord_album_replic, nalbum, nboot, idalboot, categ, nreplic)
# Attention : nboot au lieu de ntot dans les parametres
# Attention: nalbum doit être < 16 (colors...)
# Attention, nouveau parametre : nid (= 1 : identif par ident)
from pathlib import Path
def CAcatalboothulls (output_results, catv, nid, ident, coord_v, fsize, coord_album_replic, nalbum, nboot, idalboot, idalboot_num, categ, nreplic, colors):
    import numpy as np; import matplotlib.pyplot as plt;from sklearn.decomposition import PCA;from scipy.stats import chi2; import matplotlib.transforms as transforms ; from matplotlib.patches import Ellipse ;import ZoneEllipse as zone; from scipy.spatial import ConvexHull
#*****
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****
    ligne = "CA album boot new started \n------------\n" ; print (ligne)
    lident = len(ident)   # lident = nombre de vertices
#
    p = len(catv)
    cv = np.asarray(coord_v)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
#
    xh_album = coord_album_replic[:,0]
    xv_album = coord_album_replic[:,1]
#
#**************************
# recadrages et dilatation des vertices et albums.
    exh= np.std(xh)  ; exv= np.std(xv)
    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#
    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
    xh_album *= coefh_album ; xv_album *= coefv_album
# fin des recadrages et dilatation des mots et albums.
#**************************
#--- a to widen the frame  = 0.1 le 22 05 2024
    a = 0.1
#-------
    FS_vert = 8   # FS =Fontsize vertices   
    FS_alb = 12    # Font size_Albums
    FS_replic = 8  # FontSize replication boot.
#---------------------------------------------------------------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
#-------------
    fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#***** Caler la fenêtre en haut à gauche (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
#------------------------------------------------------
    for i in range(lident):       # vertices
        plt.annotate (ident[i],(xh[i], xv[i]), fontsize = FS_vert, color = 'black', weight = 'bold')
#---------- print albums
    for lc in range(nalbum):       # albums
#---------- outliers in the frame
        if(xh_album[lc] > lmaxh):
            xh_album[lc] = lmaxh - a
        if(xh_album[lc] < lminh):
            xh_album[lc] = lminh + a
        if(xv_album[lc] > lmaxv):
            xv_album[lc] = lmaxv -a
        if(xv_album[lc] < lminv):
            xv_album[lc] = lminv +a
#------------------------------------
        color1 = colors[lc]
        plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_alb, weight = 'bold', color = color1)
#
    ntot = nalbum*(nboot + 1)
    if(nreplic == 1):
        for lc in range(nalbum, ntot):
            color2 = colors[int(idalboot_num[lc])]  
            plt.annotate (idalboot[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_replic, color = color2)
#--------------------------------------------------------------
# Impression des enveloppes convexes
#--------------------------------------------------------------
    nax = 2
    list_replic, nreplic, icat = zone.list_boot(output_results, nalbum, nboot)
    for ialbum in range (nalbum):
        color = colors[ialbum]
        istart = (ialbum)*nboot
        points = np.zeros([nboot, nax])	# pour chaque album
        for i in range (nboot):
            for j in range (nax):
                points [i, j] = list_replic[i + istart,j]
#        print("\n  ialbum = " + str(ialbum +1) +" \n")
#        print(points)
# ***        np.savetxt("points.txt", points)
        color = colors[ialbum]
    # Enveloppe convexe
        hull = ConvexHull(points)
        for simplex in hull.simplices:
            plt.plot(points[simplex, 0], points[simplex, 1], color=color)
#
    axes.set_title("Convex Hulls " + str(nalbum) + " replicates swarms")
    axes.set_xlabel("X")
    axes.set_ylabel("Y")
#--- tracé des axes ***************************
    lax = 8
    plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
    plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
    # titles and tags
    ax_h = 1 ; ax_v = 2
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
#-------------------------------------------------
    Namefig = "CA_7_CA_albums_boot_convex_hulls " +categ
    plt.title("Fig. saved as:" + Namefig + ".jpg")
#  ------------------ Fin de l'impression des enveloppes convexes    
    plt.show()
#-------------------------------    
    dossier = Path(output_results)       
    fichier = dossier / f"{Namefig}.jpg"
    fig.savefig(fichier)
#-------------------------------
    return xh_album, xv_album
#
