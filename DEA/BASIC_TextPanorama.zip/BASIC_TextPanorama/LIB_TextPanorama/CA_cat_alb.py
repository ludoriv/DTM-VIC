#Tracé du plan avec en suppl. : albums (topics, categories, recueils)
# coord_album, nalbum, idalb genérés par coordalbums dans coord_alb.py
#phi : coordonnées des points
import numpy as np ; import matplotlib.pyplot as plt
from pathlib import Path
def CA_catalb (output_results, categ, catv, id_CA_topic, phi, fsize, coord_album, nalbum, idalb, ax_h, ax_v):
# La chaine categ sera intégrée dans le titre de la figure
#*****
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****
    ligne = "CA album new started \n------------\n" ; print (ligne)
    lid_CA_topic = len(id_CA_topic)   # 
#
    ax_h1 = ax_h - 1
    ax_v1 = ax_v - 1
#
    p = len(catv)
    cv = np.asarray(phi)
    xh = cv[:,ax_h1 ]  - np.mean (cv[:,ax_h1 ])
    xv = cv[:,ax_v1]  - np.mean (cv[:,ax_v1])
#
    xh_album = coord_album[:,ax_h1]
    xv_album = coord_album[:,ax_v1]
#
#**************************
# recadrages et dilatation des points et albums.
    exh= np.std(xh)  ; exv= np.std(xv)
#    exh_mot= np.std(xh_mot)  ; exv_mot= np.std(xv_mot)
    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#
    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
    xh_album *= coefh_album ; xv_album *= coefv_album
# fin des recadrages et dilatation des mots et albums.
    Print_coord_alb (output_results, xh_album, xv_album, idalb, ax_h1 )
#**************************
    
    FS_vert = 12 ; a = 0.1 # FS =Fontsize points    
    if (fsize == 1):
        FS_vert = 8  # FS =Fontsize points  
#-------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
    fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#***** Caler la fenêtre en haut à gauche (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
    for i in range(len(catv)):       # points
        plt.annotate (id_CA_topic[i],(xh[i], xv[i]), fontsize = FS_vert, weight = 'bold', color = 'black')
    FS_alb = 12 
#---------- print albums
    for lc in range(nalbum):       # albums
#---------- outliers in the frame
        if(xh_album[lc] > lmaxh):
            xh_album[lc] = lmaxh - a
        if(xh_album[lc] < lminh):
            xh_album[lc] = lminh + a
        if(xv_album[lc] > lmaxv):
            xv_album[lc] = lmaxv -a
        if(xv_album[lc] < lminv):
            xv_album[lc] = lminv +a
#------------------------------------
        plt.annotate (idalb[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_alb, weight = 'bold', color = 'green')
#-------------------------------    
#    Namefig = "CA_4_albums/categories_as suppl. elements" + categ
    namefig = "CA_4_Plane ("+ str(ax_h)+", "+str(ax_v) + ")_with_albums_categories_as suppl. elements" 
    #   plt.title("Active rows + columns, plane "+str(ax_h)+", "+str(ax_v)+" saved as: " +namefig +".jpg")
    plt.title("CA with new ident and albums: saved as:" + namefig + ".jpg")
#--- tracé des axes
    lax = 8
    plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
    plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
    # titles and tags
#    ax_h = 1 ; ax_v = 2
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
    plt.title("Active rows + albums, plane "+str(ax_h)+", "+str(ax_v)+" saved as: " + namefig)
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
#  ---    
    plt.show()
    dossier = Path(output_results)       
    fichier = dossier / f"{namefig}.jpg"
    fig.savefig(fichier)
#-------------------------------
    return 
#
def Print_coord_alb (output_results, xh_album, xv_album, idalb, ax_h1 ):
#    import numpy as np 

    input_dir_new = Path(output_results).resolve()
    title_f = "Coord_Albums_CA_" + str(ax_h1)+".txt"
    ch = input_dir_new/title_f
    g = open(ch, "w+")
    print ("\n The albums coordinates are in the created file: " + ch.name)
    g.write("\n Albums coordinates\n\n")
    p = len(xh_album.tolist())
    for i in range(p):
        ah = str(xh_album[i])
        av = str(xv_album[i])
        g.write( str(i+1)+" " + str(idalb[i]) + " " + ah[:6] + "   " + av[:6] + "\n" )
    g.close()
    return
