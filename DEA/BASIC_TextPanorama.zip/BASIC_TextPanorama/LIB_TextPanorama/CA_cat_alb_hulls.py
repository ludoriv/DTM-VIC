#Tracé du plan avec en suppl. : albums (recueils)
# coord_album, nalbum, idalb genérés par coordalbums dans coord_alb.py
#phi : coordonnées des points
import numpy as np ; import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull
from pathlib import Path
def CA_catalb_hulls (output_results, catv, id_CA_topic, phi, fsize, coord_album, nalbum, idalb, categ, colors):
# La chaine categ sera intégrée dans le titre de la figure
#*****
    import tkinter as tk
    root = tk.Tk()
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    root.destroy()
#*****
    ligne = "CA album new started \n------------\n" ; print (ligne)
    lid_CA_topic = len(id_CA_topic)   # 
#
    p = len(catv)
#    titre = "Albums_(supplementary)"
#    for i in range(p,lid_CA_topic):   # 
#        id_v_topic[i] = " "
    cv = np.asarray(phi)
    xh = cv[:,0]  - np.mean (cv[:,0])
    xv = cv[:,1]  - np.mean (cv[:,1])
#
    xh_album = coord_album[:,0]
    xv_album = coord_album[:,1]
#
#**************************
# recadrages et dilatation des points et albums.
    exh= np.std(xh)  ; exv= np.std(xv)
#    exh_mot= np.std(xh_mot)  ; exv_mot= np.std(xv_mot)
    exh_album =np.std(xh_album)  ; exv_album= np.std(xv_album) 
#    
#    coefh = exh/exh_mot ; coefv = exv/exv_mot
 #   xh_mot = xh_mot*coefh ; xv_mot = xv_mot*coefv
#
    coefh_album = exh/exh_album ; coefv_album = exv/exv_album
    xh_album *= coefh_album ; xv_album *= coefv_album
# fin des recadrages et dilatation des mots et albums.
    Print_coord_alb_hull (output_results, xh_album, xv_album, idalb )
#**************************
    
    FS_vert = 12 ; a = 0.1 # FS =Fontsize points    
    if (fsize == 1):
        FS_vert = 10  # FS =Fontsize points  
#-------
    lminh = min(xh) - a; lmaxh = max(xh) + a; lminv = min(xv) - a; lmaxv = max(xv) + a
#---
    lax_h = lmaxh - lminh
    lax_v = lmaxv - lminv
    fig, axes = plt.subplots(figsize=(screen_width / 100, screen_height / 100), dpi=100)  
#***** Caler la fenêtre en haut à gauche (x=0, y = 0)
    manager = plt.get_current_fig_manager()
    if hasattr(manager, 'window'):
        manager.window.wm_geometry("+0+0")
#*****
#    fig, axes = plt.subplots(figsize = (lax_h,lax_v))
#    plt.subplots_adjust(left= 0.0)
    plt.subplots_adjust()
    axes.set_xlim (lminh,lmaxh)
    axes.set_ylim(lminv,lmaxv)
    for i in range(len(catv)):       # points
        plt.annotate (id_CA_topic[i],(xh[i], xv[i]), fontsize = FS_vert, color = 'black')
    FS_alb = 14 
#---------- print albums
    for lc in range(nalbum):       # albums
#---------- outliers in the frame
        if(xh_album[lc] > lmaxh):
            xh_album[lc] = lmaxh - a
        if(xh_album[lc] < lminh):
            xh_album[lc] = lminh + a
        if(xv_album[lc] > lmaxv):
            xv_album[lc] = lmaxv -a
        if(xv_album[lc] < lminv):
            xv_album[lc] = lminv +a
#------------------------------------
        plt.annotate (idalb[lc],(xh_album[lc], xv_album[lc]), fontsize = FS_alb, weight = 'bold', color = 'green')
#        plt.annotate (idalb[lc],(coord_album[lc,0], coord_album[lc,1]), fontsize = FS_alb, color = 'b')
    Namefig = "CA_ident_cat_and_albums_Convex_Hulls, " + categ
    plt.title("CA with new ident and album: saved as:" + Namefig + ".jpg")
#
    nax = 2
#
    for ialbum in range (nalbum):
#        istart = (ialbum)*nboot
        eff = 0
        for nson in range(p):
            if(int(catv[nson])== ialbum + 1):
                eff+= 1
        points = np.zeros([eff, nax])	# for each album
        index = -1
        for nson in range(p):
            if(int(catv[nson])== ialbum + 1):
                index = index + 1
                points[index, 0] = xh[nson]
                points[index, 1] = xv[nson]
#        print("\n  ialbum = " + str(ialbum +1) +" \n")
#        print(points)
        input_dir_new = Path(output_results).resolve()
        ch = input_dir_new/"points.txt"
# ***        np.savetxt(ch, points)
        color = colors[ialbum]

    # Enveloppe convexe
        hull = ConvexHull(points)
        for simplex in hull.simplices:
            plt.plot(points[simplex, 0], points[simplex, 1], color=color)
#--- tracé des axes
    lax = 8
    plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
    plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
    # titles and tags
    ax_h = 1 ; ax_v = 2
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))
    plt.title("Active rows + albums, plane "+str(ax_h)+", "+str(ax_v)+" saved as: " + Namefig)
    plt.xlabel("axis " + str(ax_h))
    plt.ylabel("axis " + str(ax_v))

#  --- suggestion de chatGPT_marche trop bien: impossible de fermer
#    manager = plt.get_current_fig_manager()
#    manager.full_screen_toggle()
#  ---    
    plt.show()
#-------------------------------    
    dossier = Path(output_results)       
    fichier = dossier / f"{Namefig}.jpg"
    fig.savefig(fichier)
#-------------------------------
    return 
#
def Print_coord_alb_hull (output_results, xh_album, xv_album, idalb ):
#------------------
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/"Coord_Albums_CA_hull.txt"
    g = open(ch, "w+")
    print ("\n The albums coordinates are in the created file: " + g.name)
    g.write("\n Albums coordinates\n\n")
    p = len(xh_album.tolist())
    for i in range(p):
        ah = str(xh_album[i])
        av = str(xv_album[i])
        g.write( str(i+1)+" " + str(idalb[i]) + " " + ah[:6] + "   " + av[:6] + "\n" )
    g.close()
    return
