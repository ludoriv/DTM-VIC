import pandas as pd; import numpy as np
from pathlib import Path
#*************************************************
def coordalbums_boot(output_results, catv, coord_v, nboot):
# nboot = number of réplications.
# Reminder = id_v, coord_v = tbase.Treebase(p)
# Essai d'indexation of coord_album par le num nboot of bootstrap (1,2,...nbootstrap)
    nalbum = int(max(catv))
    ntot = nalbum * (nboot +1)
    p = len(catv)    #  p = number of basic texts (sonnets, poems, songs)
    naxb = 2
    nvert = len(coord_v)
#
    cv = np.asarray(coord_v)  # start from 0
    cv_cent = np.zeros((nvert,naxb))
#    idalb = np.empty(p, dtype = 'U20')
# First part : computation of coord classiques of albums.
    coord_album_replic = np.zeros((ntot, naxb)) # new  
    eff = np.zeros(ntot +1) 
#
    cv_cent[:,0] = cv[:,0]  - np.mean (cv[:,0])
    cv_cent[:,1] = cv[:,1]  - np.mean (cv[:,1])
#
    for i in range(p):
        lcat = int(catv[i])-1
        eff[lcat] += 1
        for k in range(naxb):
            coord_album_replic[lcat, k] += cv_cent[i,k]
#
    for lc in range(nalbum):
        for k in range(naxb):
            coord_album_replic[lc,k] /= eff[lc]
#
# ***  
# Second part : computation of coord of replicated albums 
#----------------------
# creating the file "sentier_boot.csv" in folder "Results" 
    laneboot = "sentier_boot.csv"
    input_dir_new = Path(output_results).resolve()
    ch_laneboot = input_dir_new/laneboot
#---------------------
    X = pd.read_csv(ch_laneboot)
    n,q = X.shape     # n = iboot*p
    pb = np.zeros(n + 1)   # pb = bootstrap weight 
    for i in range(n):
        pb[i] = (X.iloc[i,2] )  
        #  ***********  
    for iboot in range(nboot):
        ideb = (iboot)*p  
        ideb_alb = (iboot + 1)*nalbum
        for ii in range(nalbum):
            eff[ii] =0
        for i in range(p):
            lcat = int(catv[i])-1
            eff[lcat] += pb[ideb + i]
            for k in range(naxb):
                coord_album_replic[lcat + ideb_alb, k] += pb[ideb + i]*cv_cent[i,k]
#
        for lc in range(nalbum):
            for k in range(naxb):  
                if(eff[lc] > 0.1):
                    coord_album_replic[lc + ideb_alb,k] /= eff[lc]

    return coord_album_replic, nalbum,  ntot  

