# Synthesis:  Correspondence Analysis + Simultaneous Additive Tree + bootstrap.
#------------------------------------------------------------------------------
# The main function : CA_AT_synthesis() 
# (here : basic texts with categories (albums or topics) with visualizations and bootstrap validation of categories) 
# The main module (TextPanorama.py) must be in the same folder as both the library folder: 'LIB_TextPanorama', and the interface program 'Interface_TextPanorama.py' 
import os
import sys; sys.path.append('LIB_TextPanorama') # Making available the library of functions included in the folder: LIB_TextPanorama
#---------------------------------------------------------------
import numpy as np
import Words_bag as Wb        # Transforming texts into presence-absence of words
import table_lex as tex       # Building a lexical table
import agreg_tablex as agreg  # Aggregating columns of tablex
#
#---- CA ----
import ac_dtm_AT as act          # CA of "tablexfile.csv"
import f_testval12 as vt         # Computation of test-values
import CA_graf_complet5 as gr5   # CA display + test- values (words-texts)
import CA_cat_alb as CA_alb      # CA display + Categories (albums)          (axes 1, 2)
import Sup_cat_CA as sup_CA      # Coordinates of supplementary categories (CA)
#
#---- Bootstrap for CA
import CA_cat_alb_boot as catboot             #  CA with replicates of categ./albums/topics 
import CA_cat_alb_boot_ellipses as catbootell #  CA with confidence ellipses for categ./albums/topics
import CA_cat_alb_hulls as CA_hulls           #  CA with convex hulls of categ. clouds
import CA_cat_alb_boot_hulls as CA_boot_hulls #  CA with convex hulls of replicates 
#
#---- SAT (Simultaneous Additive Trees)
import Tree_cat_alb_hulls as TreeHulls  # Convex hulls of categories/albums/topics 
import AT_NJ_calc as njt        # Neighbours Joining tree basic computation
import Tree_base as tbase       # basic tree (Tree_base.jpg), creating coord_v and id_v
import Tree_cat as cat          # Drawing the same tree with categories/albums/topics numbers as identifiers. 
import Forest as fo             # Series of cat-ident trees (FOREST is an internal parameter)
import axis1_sign as ax1        # Possible change of axes directions
import w_coord_plot as wcp      # coordinates of words in NJ tree space
import tree_simult_n11 as ct    # Tree of aggregated texts + words ("ct" => "Christmas Tree")
import Tree_cat_alb as talb     # Tree with categories (alb = album) 
import coord_alb as calb        # Coordinates of categories (albums)  
import ident_alb as new_id      # Building extended identifiers
#
#---------  Bootstrap for SAT
import Tree_cat_alb_boot as talboot  # Tree with Bootstrap replicates of categories 
import coord_alb_boot as calboot     # Coordinates of categories and their replicates
import Dupli_csv_boot as Dup         # replicates of categories
import Tree_cat_alb_boot_ellipses as talboot_ellipses  # Tree with Boot. confid. ellipses
import Sup_cat_AT as sup_AT          # Coordinates of supplementary categories (AT)
import Tree_boot_hulls as TBH        # Tree with Convex Hulls of replicates of categories
#************************************************************
#
# CA_AT_synthesis (dossier_data, chemin, sentier, piste, wordbag, anagreg, freqmin, nax, nvt, Detail, seuil_vt):
#
#----------------------------------------- 
# dossier_data : path to the DATA folder
# chemin       : path to the basic text file (within DATA folder)
# sentier      : path to the categories file (within DATA folder)
# piste        : path to the identifiers of categories file (within DATA folder)
#----------------------------------------
#  Parameters =  (following the 4 paths: dossier_data, chemin, sentier, piste)
#     "wordbag": If wordbag = 1: Each raw text is replaced with a bag of words, 
#                If wordbag = 0: the analyses are performed on raw texts.
#     "anagreg": If anagreg = 1: Poems/texts are aggregated according to the categories described in category file.
#                If anagreg = 0: Direct analysis of all poems/texts.
#     "freqmin": Minimum frequency for kept words.
#     "nax":     Maximum number of axes to keep in the initial correspondence analysis.
#     "nvt":     Number of kept characteristic words (criterion: test values).
#     "Detail":  If Detail = 1: For anagreg = 0, detailed outputs (bootstrap replications, various visualizations). 
#                If Detail = 0: basic outputs (default value)
#     "seuil_vt": Significance threshold for the test-values (for selection of characteristic words).
#----------------------------------------------------------------
#
def CA_AT_synthesis (dossier_data, chemin, sentier, piste, wordbag, anagreg, freqmin, nax, nvt, Detail, seuil_vt):
    from pathlib import Path
    from datetime import datetime
#-------------
# A folder "Results" (with date and hours/min) is created within the folder DATA
#------------- 
    stamp = datetime.now().strftime('%Y-%m-%d_%H-%M')   
    input_dir = Path(dossier_data).resolve()
    output_dir = input_dir/("Results_" + stamp)
    Path(output_dir).mkdir(exist_ok = True)
#----------------------
    output_results = output_dir
#----------------------
# creating the file "Report.txt" in the created folder "Results"
#---------------------- 
    input_dir_new = Path(output_results).resolve()
    ch = input_dir_new/"Report.txt"
#----------------------
    g = open(ch, "w+")
    print  ("\n "   + "chemin =  " + chemin + "   \n" )
    print  ("\n "   + "sentier = " + sentier + "  \n" )
    print  ("\n "   + "piste =   " + piste + "  \n" )
    print   ("\n "   + "wordbag  =" + str(wordbag) + ",   anagreg = " + str(anagreg) + ",   freqmin = " +  str(freqmin) + "\n" )
    print   ("\n "   + "nax  =" + str(nax) + ",   nvt = " + str(nvt) + ",   Detail = " +  str(Detail) + "\n" )
    print   ("\n "   + "seuil_vt  =" + str(seuil_vt) + "\n" )
#
    g.write("\n\n " + "chemin = " + chemin + "  \n" )
    g.write("\n\n " + "sentier =" + sentier + "  \n" )
    g.write("\n\n " + "piste =  " + piste + "  \n" )
    g.write  ("\n\n "   + "wordbag  =" + str(wordbag) + ",   anagreg = " + str(anagreg) + ",   freqmin = " +  str(freqmin) + "\n" )
    g.write  ("\n\n "   + "nax  =" + str(nax) + ",   nvt = " + str(nvt) + ",   Detail = " +  str(Detail) + "\n" )
    g.write  ("\n\n "   + "seuil_vt  =" + str(seuil_vt) + "\n" )
    #
    #--------------**** First decision: Wordbag or not wordbag? (wordbag is a parameter)
    #
    if(wordbag == 1):
        input_dir_new2 = Path(output_results).resolve()
        nomfich = Path(chemin).stem
        cheminwb = input_dir_new2/(nomfich + "_wb" + ".txt")
    #   The new wordbag textfile will be in the folder "Results..." 
        Wb.wb(chemin, cheminwb)
        print ("\n\n " + "A wordbag file is created: Name = " + str(cheminwb)  + "\n" )
        g.write("\n\n " + "A wordbag file is created: Name = " + str(cheminwb)  + "\n" )
        chemin = cheminwb
    #----------------------------------- end if.
#    if(wordbag == 0):
#        chemin = input_dir_new
    ligne = "Step: tablex \n------------\n" ; print (ligne); g.write("\n" + ligne)
    #-------- Computation of the Global Lexical Table (Words x Texts) (function tablex)
    ch_csv = tex.tablex(output_results, chemin, freqmin)
    #------------------------------------
    #--------------**** Second decision aggregation or not (anagreg is a parameter)
    #
    if(anagreg == 1):
    #----------------- In this option: anagreg = 1, the categories are active. They are used a priori to aggregate the texts. 
        print ( " Aggregated lexical table   \n ")
        nvt = 7  # provisional (nvt is a parameter)
        text2tree_Topic(ch_csv, output_results, g, freqmin, chemin, sentier, piste, nax, nvt, seuil_vt)
#
    if(anagreg == 0):   
    #----------------- In this option: anagreg = 0, the categories are supplementary. Their location in the display of the tree are validated with bootstrap replications.
        print ( " Direct analysis of texts (poems, sonnets, etc.  \n ")
        text2panorama (ch_csv, output_results, g, chemin, sentier, piste, freqmin, Detail, nax, nvt, seuil_vt)
        return
#---------------------------------------------------------------------------------------- 
#----------------------------------------------------------------------------------------
def text2tree_Topic(ch_csv, output_results, g, freqmin, chemin, sentier, piste, nax, nvt, seuil_vt):
#
#  The categories are active. They are used a priori to aggregate the texts. 
# 
#****  Computation of the aggregated lexical table
#----------------------------------------------
    ligne = "Step: numpy_agreg_new_ok \n------------\n" ; print (ligne); g.write("\n" + ligne)
    ch_classic = agreg.agregtablex(ch_csv, output_results, sentier, piste)
    lane = ch_classic
#
#  Classical CA of the aggregated table
#---------------
    ligne = "Step: CA_base \n------------\n"; print (ligne); g.write("\n" + ligne)
    X, F, fi, fj, psi, psi_u, phi, phi_u, vp = act.AC_base_AT(output_results,lane)
    ligne = "Step: CA_plot: rows + columns \n------------\n" ; print (ligne); g.write("\n" + ligne)
    ax_h, ax_v = 1, 2
#
#  Simultaneous graph of aggregated texts and words
#---------------
    act.graf_simult (output_results, X, psi, phi, ax_h, ax_v)
    ligne = "Step: CA_plot: rows + columns + char. words\n------------\n" ; print (ligne); g.write("\n" + ligne)
#
#  Computation of "test-values" ( Selection of characteristic words of the categories of texts) 
#---------------
    num_vt, nvs = vt.Test_Val12(output_results, nvt, seuil_vt, lane)
    ligne = "Test-values computed \n------------\n" ; print (ligne); g.write("\n" + ligne)
#
#  Again: Simultaneous CA graph of aggregated texts and words, with "nvt" most characteristic words linked to their texts
#---------------
    gr5.grafACcomplet5 (output_results, X, psi, phi, ax_h, ax_v, nvt, num_vt, nvs)
#----------- computation of distances
    disMatrix = act.dist(phi, nax)
#-----------
#    ident = list(X.columns)
#    n = X.shape[1]
    ligne = "Step: NJ_tree \n------------\n" ; print (ligne); g.write("\n" + ligne)
    ident = list(X.columns)    
    p = X.shape[1]
#
#  Computation of the AT (Additive Tree) - Nearest Joining Neighbours method.
#----------- 
    ch_edge, ch_gml = njt.AT_NJ_calc(output_results, p, disMatrix, ident)
    ligne = "NJ_tree computed \n------------\n" ; print (ligne); g.write("\n" + ligne)
#
# First drawing of the AT
#----------- 
    id_v, coord_v = tbase.Treebase(ch_gml, output_results, p)
    ligne = "NJ_tree first plot \n------------\n" ; print (ligne); g.write("\n" + ligne)
#    (possible change of first axis orientation)
    aa = ax1.change(coord_v, phi)
    coord_v = aa
    ligne = "Horiz. orientation of NJ_Tree modified \n------------\n" ; print (ligne); g.write("\n" + ligne)
#   Coordinates of words around the AT
    coorm = wcp.coor_mots(F, fi, coord_v)
    ligne = "Words coordinates computed \n------------\n" ; print (ligne); g.write("\n" + ligne)
#  Again: Simultaneous AT graph of aggregated texts and words, with "nvt" most characteristic words linked to their texts
#---------------
    ct.Tree_simult11 (ch_edge, output_results, F, fi, id_v, coord_v, coorm, nvt, num_vt, nvs)
    ligne = "Words decorated tree computed and drawn \n------------\n" ; print (ligne); g.write("\n" + ligne)
    ligne = "End of the process \n------------\n" ; print (ligne); g.write("\n" + ligne)
    g.close()
    return
#
#----------------------------------------------------------------
#----------------------------------------------------------------
#
def text2panorama (ch_csv, output_results, g, chemin, sentier, piste, freqmin, Detail, nax, nvt, seuil_vt):
#
# In this option (anagreg = 0) the categories are supplementary. Their location in the display of the tree are validated with bootstrap replications.
# 
#*******************************
# Internal control parameter "nboot" (should be changed here, within the code)
# -------------------------
    nboot = 30    # The value of 30 (which may seem low) provides good results in this specific multidimensional context. The problem is not to estimate the value of a numerical variable. Evidently, larger values could be tested.
#*******************************
# Internal control parameter FOREST (should be changed here, within the code)
# -------------------------
    FOREST = 0   # Producing a forest of additive trees
# --------------
# FOREST = 0 :  Without tree visualizations for each category (or topic or album)
# FOREST = 1 : (advisable only if nc [number of categories/albums/topics], e.g. nc < 10 )
# If FOREST = 1: Sequence of *nc* ATs displays successively identified by each of the *nc* categories (or *nc* albums). Goal: better visualizing both the location and the dispersion of each category in the additive tree.
#*******************************
#    print  ("\n "   + "chemin =" + chemin.name + "  freqmin = " + str(freqmin) + "   nvt = " +  str(nvt) +  " nax = " + str(nax) + "\n" )
#    g.write("\n\n " + "chemin =" + chemin.name + "  freqmin = " + str(freqmin) + "   nvt = " +  str(nvt) +  " nax = " + str(nax) + "\n" )
    print  ("\n "   + "chemin =" + chemin + "  freqmin = " + str(freqmin) + "   nvt = " +  str(nvt) +  " nax = " + str(nax) + "\n" )
    g.write("\n\n " + "chemin =" + chemin + "  freqmin = " + str(freqmin) + "   nvt = " +  str(nvt) +  " nax = " + str(nax) + "\n" )
    ligne = "Step: tablex \n------------\n" ; print (ligne); g.write("\n" + ligne)
#
    lane = ch_csv   # address of global lexical table Basic_texts x Words computed in "CA_AT_synthesis"
#---------------------------------------------------------------
# for some displays : 16 different colours [ first 16] out of 48. 
# The maximum number of categories is then < 49, but the list can be extended if necessary
    colors = ['black','red','green','blue','orange','cyan','steelblue','pink','limegreen', 'khaki','yellow', 'crimson', 'coral', 'silver', 'olive', 'navy', 'black','red','green','blue','orange','cyan','steelblue','pink','limegreen', 'khaki','yellow', 'crimson', 'coral', 'silver', 'olive', 'navy', 'black','red','green','blue','orange','cyan','steelblue','pink','limegreen', 'khaki','yellow', 'crimson', 'coral', 'silver', 'olive', 'navy']
#---------------------------------------------------------------
#tablex has already been saved on files: tablexfile.txt and tablexfile.csv. Note that tablexfile.csv uses commas as separators (US convention; for some European countries, commas could be changed into semicolons, for an XL visualization of the table.
#
    ligne = "Step: CA_base \n------------\n" ; print (ligne); g.write("\n" + ligne)
# Basic CA : table words x Texts
#-------------------------------
# (Reminder: import ac_dtm_AT as act) 
    X, F, fi, fj, psi, psi_u, phi, phi_u, vp = act.AC_base_AT(output_results, lane)
#--> (Fig CA_1)
# The coordinates are in the created file: AC_file_tablexfile.csv
    ligne = "Step: CA_plot: rows + columns \n------------\n" ; print (ligne); g.write("\n" + ligne)
    ax_h, ax_v = 1, 2
# Simultaneous Visualization words x Texts with CA plane(1,2)"
#--------------------------------------------------
    act.graf_simult (output_results, X, psi, phi, ax_h, ax_v)
#--> (Fig CA_2.1)
#xxxxxxxxxxxxxxx
    ligne = "Step: CA_plot: rows + columns \n------------\n" ; print (ligne); g.write("\n" + ligne)
#
    ax_h, ax_v = 3, 4
# Simultaneous Visualization words x Texts with CA plane(3,4)"
#--------------------------------------------------
    act.graf_simult (output_results, X, psi, phi, ax_h, ax_v)
#--> (Fig CA_2.2)
#xxxxxxxxxxxxxx
    ligne = "Step: CA_plot: rows + columns + char. words\n------------\n" ; print (ligne); g.write("\n" + ligne)
    ligne = "Computation of Test-values \n------------\n" ; print (ligne); g.write("\n" + ligne)
#**************** fsize : size of font in some displays
    fsize = 1
#**************** below: nvt = number of test-values (characteristic words)
    if(nvt > 0):
        num_vt, nvs = vt.Test_Val12(output_results, nvt, seuil_vt, lane)
        ligne = "Test-values computed (file: Test_values.txt) \n------------\n" ; print (ligne); g.write("\n" + ligne)
#   Visualization in which characteristic words are linked to their Texts. 
#--------------------------------------------------------------------------
        ligne = "Visualization: texts x Characteristic words \n------------\n" ; print (ligne); g.write("\n" + ligne)
#  (Reminder: import graf_AC_complet5 as gr5)
        ax_h, ax_v = 1, 2
        gr5.grafACcomplet5 (output_results, X, psi, phi, ax_h, ax_v, nvt, num_vt, nvs)
#--> (Fig CA_3.a)
        ax_h, ax_v = 3, 4
        gr5.grafACcomplet5 (output_results, X, psi, phi, ax_h, ax_v, nvt, num_vt, nvs)
#--> (Fig CA_3.b)
#       Reminder:    n,p = X.shape : n words , p Texts
#*****************
#
    ident = list(X.columns)    
    p = X.shape[1]
    noident = [""]*len(ident)   # liste vide
# New identifiers ("albums")for texts (datafile csv: "sentier")
#--->   id_v_topic = ident of categories (albums/topics...).  catv = vector of albums/topics
    id_CA_topic, catv = sup_CA.SupCat_CA(sentier)
#
    ligne = "Table id_CA_topic \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#
    g.write( str(id_CA_topic))
#************************************
    ligne = "catv = vector of albums/topics numbers \n-----------\n" ; print (ligne); g.write("\n" + ligne)
#
    naxtot = 4 # coordinates up to axis 4
    coord_album_CA, nalbum = calb.coordalbums(catv, phi, naxtot)
#
    import ident_alb as new_id
    idalb = new_id.identif_alb(piste)
#
    categ = "_basic ident."
#  (Reminder: import CA_cat_alb as CA_alb)
    ax_h, ax_v = 1, 2
    CA_alb.CA_catalb (output_results, categ, catv, ident, phi, fsize, coord_album_CA, nalbum, idalb, ax_h, ax_v)
#-->(Fig CA_4.a) (axes (1,2)
    ax_h, ax_v = 3, 4
    CA_alb.CA_catalb (output_results, categ, catv, ident, phi, fsize, coord_album_CA, nalbum, idalb, ax_h, ax_v)
#-->(Fig CA_4.b) (axes (3,4)
#----------- Optional change within the code: -------------
# The convex hulls of supplementary categories (here: albums/topics) emphasize the fact that supplementary categories are DILATED centroids of the concerned texts (poems, sonnets...). They could be outside the convex hulls of the concerned texts.
#---- (if ok with option, remove the 2 next "#" below to execute)  
#    ligne = "Convex Hulls of albums (main CA plane) \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#    CA_hulls.CA_catalb_hulls (output_results, catv, id_CA_topic, phi, fsize, coord_album_CA, nalbum, idalb, categ, colors)
#------------------------------------------------------------
#
#************************ Replicates  ****
#*****************************************
    ligne = "Replicates of albums \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
    pboot, pboot_n, pboot_list = Dup.Dupli_csv2 (output_results, nboot, sentier)
#*****************************************
    ligne = "Coordinates of albums + replicates \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
    coord_album_replic, nalbum,  ntot = calboot.coordalbums_boot(output_results, catv, phi, nboot)
    ligne = "Identifiers including replicates \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
    idalboot, idalboot_num = talboot.create_idalboot2(nalbum, nboot, piste)
#
    ligne = "Graph with replicates of albums, and albums (texts) \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#  (Reminder: import CA_cat_alb_boot as catboot)  
    xh_album, xv_album = catboot.CAcatalboot (output_results, catv, ident, phi, fsize, coord_album_replic, nalbum, ntot, idalboot)
#--> (Fig CA_5)
    catboot.Print_coord_albS_CA(output_results, xh_album, xv_album, idalboot )
#--------------------
    nreplic = 1
    nid = 0
    categ = "(nreplic=1_nid =0_basic_ident)"
#  (Reminder: import CA_cat_alb_boot_ellipses as catbootell) 
# 
    list_all = [i for i in range(nalbum)] # Ellipses for all albums
    selec_list = list_all
    xh_album, xv_album = catbootell.CAcatalbootellipses (output_results, selec_list, catv, nid, ident, phi, fsize, coord_album_replic, nalbum, nboot, idalboot, categ, nreplic, colors)
#-->(Fig CA_6_1 - basic identifiers -ident)
#
    nreplic = 1 ; nid = 0
#    categ = " (nreplic = 1, nid = 0, basic_ident, select)"
#------------------
#
    categ = "(nreplic = 1, nid = 0, ident_topic)"
    xh_album, xv_album = catbootell.CAcatalbootellipses (output_results, selec_list, catv, nid, id_CA_topic, phi, fsize, coord_album_replic, nalbum, nboot, idalboot, categ, nreplic, colors)
#--> (Fig CA_6_2 - identifiers = category numbers- ident_topic)
    fsize = 1
#----------- Optional change within the code: -------------
#   xxxxxxxx Call selection of 2 ellipses   xxxxxxxxxxxxxxxxx *** Internal option.
#  Example of categories (topics, albums) 6 and 7.
#  Selection of 2 ellipses from a list: here: [5,6] = albums 6 and 7 (remember, origin = 0, instead of 1)
#-----------------------------------------------------------
    selec_list = [5,6]  #  (Albums 6 and 7)
    categ = "(_selection_of_2_ellipses_replicates)"
    xh_album, xv_album = catbootell.CAcatalbootellipses (output_results, selec_list, catv, nid, id_CA_topic, phi, fsize, coord_album_replic, nalbum, nboot, idalboot, categ, nreplic, colors)
    nreplic = 0
    categ = "(_selection_of_2_ellipses_no_replicates)"
    xh_album, xv_album = catbootell.CAcatalbootellipses (output_results, selec_list, catv, nid, id_CA_topic, phi, fsize, coord_album_replic, nalbum, nboot, idalboot, categ, nreplic, colors)
#-----------------------------------------------------------
    nreplic = 1 ; nid = 1
    categ = "(nreplic = 1, nid =0, basic_ident)"
#  (Reminder: import CA_cat_alb_boot_hulls as CA_boot_hulls)  
    xh_album, xv_album = CA_boot_hulls.CAcatalboothulls (output_results, catv, nid, ident, phi, fsize, coord_album_replic, nalbum, nboot, idalboot, idalboot_num, categ, nreplic, colors)
#--> (Fig CA_7)
#-------------------------------------
    ligne = "End of CA computations and visualizations \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#************************************
    ligne = "Simultaneous Additive Trees (AT), computations and visualizations \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#
#-----------------------------------------------
#  AT  AT  AT  AT  AT  AT  AT ------------------
#-----------------------------------------------
#
# Computation of the distances matrice (distances between texts)
    ligne = "Computation of distances matrix\n------------\n" ; print (ligne); g.write("\n" + ligne)
    disMatrix = act.dist(phi, nax)
    ident = list(X.columns)
    p = X.shape[1]
    ligne = "Step: Neighbours Joining_Tree \n------------\n" ; print (ligne); g.write("\n" + ligne)
#
#  Computation of the AT (Additive Tree) - Nearest Joining Neighbours method.
#----------- 
    ch_edge, ch_gml = njt.AT_NJ_calc(output_results, p, disMatrix, ident)
#
    ligne = "NJ_tree computed \n------------\n" ; print (ligne); g.write("\n" + ligne)
    ligne = "NJ_tree first plot (+ coord_v + id_v) \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#
# First drawing of the AT.  ( id_v = ident of vertices, coord_v = coordinates of vertices)
#----------- 
    id_v, coord_v = tbase.Treebase(ch_gml, output_results, p)
#--> (Fig Tree_1_Treebase)
#
    ligne = "New ident for vertices\n-----------------\n" ; print (ligne); g.write("\n" + ligne)
# New identifiers of categories ("albums") for texts (file csv: "sentier") 
#--->   id_AT_topic = ident of albums/topics.  catv = vector of albums/topics
    id_AT_topic, catv = sup_AT.SupCat_AT (sentier)
#
    ligne = "Table / id_AT_topic \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#    print(id_AT_topic)
    g.write( str(id_AT_topic))
#************************************
    ligne = "catv = vector of albums/topics \n-----------\n" ; print (ligne); g.write("\n" + ligne)
    g.write(str(catv))
    ligne = "Same tree with new idents \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#******************************
# Same AT with ident (topics/albums/categories) instead of ident basic texts [poetries/songs/sonnets])
    cat.Treecat (output_results, p, id_AT_topic, coord_v)
#--> (Fig Tree_2_Treebase_ident_cat)
#
    ligne = "Coordinates on AT of albums (texts) \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#
    naxtot = 2  # only 2 dimensions (AT is planar)
    coord_album_AT, nalbum = calb.coordalbums(catv, coord_v, naxtot)
#****************** xxxxxxxxxxxxxxxx internal option xxx
#    ligne = "Convex Hulls of albums (Additive Tree) \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
#    categ = "ident = id_AT_topic"
#    TreeHulls.SAT_catalb_hulls (output_results, catv, id_AT_topic, coord_v, fsize, coord_album_AT, nalbum, idalb, categ)
#*************** xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
# 
    import ident_alb as new_id
    idalb = new_id.identif_alb(piste)
# ***************
    ligne = "Basic identifiers for Additive Trees (ident complemented with blank spaces) \n-----------------\n" 
    print (ligne); g.write("\n" + ligne)
    ident_AT = ident + [""]*(len(id_AT_topic) - len(ident))
    g.write(str(ident_AT))
#
# Same AT with idents "albums" (file csv : piste_boot) + replicates 
    ligne = "Coordinates of albums + replicates \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
# (reminder: calboot ...for module: coord_alb_boot.py in the library)
    coord_album_replic_AT, nalbum,  ntot = calboot.coordalbums_boot(output_results, catv, coord_v, nboot)
#
    categ = "(basic_ident)" ; fsize = 1
    #-------------------------------------
    nreplic = 0
    ligne = "Tree with replicates of albums, and albums (texts) \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
# (reminder: talboot ... for module : Tree_cat_alb_boot.py in the library)   
    xh_album, xv_album = talboot.Treecatalboot (output_results, categ, catv, ident_AT, coord_v, fsize, coord_album_replic_AT, nalbum, ntot, idalboot, nreplic)
#--> (Fig Tree_3_1)_Treebase + categories_sup)
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    nreplic = 1
    xh_album, xv_album = talboot.Treecatalboot (output_results, categ, catv, ident_AT, coord_v, fsize, coord_album_replic_AT, nalbum, ntot, idalboot, nreplic)
#--> (Fig Tree_3_2)_Treebase + categ_sup + replicates)
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    talboot.Print_coord_albST(output_results, xh_album, xv_album, idalboot )
    #-------------------------------------
    nreplic = 1
    nid = 0
#---------------------------------
    if(Detail > 0):
        categ = "1_Boot_Conf_Ellipses_(nreplic_=_1,_nid_=_0,_ident_topic)"
#  Conf. ellipses, identifiers: categories
        list_all = [i for i in range(nalbum)]
        selec_list = list_all #(all categories are selected)
        xh_album, xv_album = talboot_ellipses.Treecatalbootellipses (output_results, selec_list, catv, nid, id_AT_topic, coord_v, fsize, coord_album_replic_AT, nalbum, nboot, idalboot, categ, nreplic, colors)
#--> (Fig Tree_4_1)
#-----------------
        nid = 0
        nreplic = 0
        categ = "2_Boot_Conf_Ellipses_(nreplic_=_0,_nid_=_0,_basic_ident)"
        fsize = 3
#  Conf. ellipses, identifiers: basic texts
        xh_album, xv_album = talboot_ellipses.Treecatalbootellipses (output_results, selec_list, catv, nid, ident_AT, coord_v, fsize, coord_album_replic_AT, nalbum, nboot, idalboot, categ, nreplic, colors) 
#---------------------------------
    nreplic = 0; nid = 0
#--> (Fig Tree_4_2)
#-------------------------------------
    categ = "3_Boot_Conf_Ellipses_(nreplic_=_0,_nid_=_0,_ident_topic)"
#  Conf. ellipses, identifiers: categories, no replicates
    xh_album, xv_album = talboot_ellipses.Treecatalbootellipses (output_results, selec_list, catv, nid, id_AT_topic, coord_v, fsize, coord_album_replic_AT, nalbum, nboot, idalboot, categ, nreplic, colors)
#--> (Fig Tree_4_3)
#-------------------------------------
#     Convex hulls of replicates.
    nreplic = 1
    categ = "_(basic_ident)"
    TBH.Treecatalboot_hulls (output_results, catv, nid, ident_AT, coord_v, fsize, coord_album_replic_AT, nalbum, nboot, idalboot, idalboot_num, categ, nreplic, colors)
#--> (Fig Tree_5) 
#-------------------------------------
#----------- Optional change within the code: -------------
#***********************************
#  Internal option (intervention within the code).
#  Selection of 2 ellipses from a list: As an example: [5,6] = confidence ellipses for albums (or topics) 6 and 7 (remember, origin = 0, instead of 1). This is just an example of selection of a pair of albums (to compare CA and AT ellipses)
#------------------------------------- 
    selec_list = [5,6]  #  (Albums 6 and 7)
    categ = "4_(ident_basic_Selection_of_2_ellipses)"
    xh_album, xv_album = talboot_ellipses.Treecatalbootellipses (output_results, selec_list, catv, nid, ident_AT, coord_v, fsize, coord_album_replic_AT, nalbum, nboot, idalboot, categ, nreplic, colors)
#----------------------
    categ = "5_(ident_basic_Select_2_ellipses_no_replicates)"
    nreplic = 0
    xh_album, xv_album = talboot_ellipses.Treecatalbootellipses (output_results, selec_list, catv, nid, ident_AT, coord_v, fsize, coord_album_replic_AT, nalbum, nboot, idalboot, categ, nreplic, colors)
#---------------------- 
    fsize = 3
#**************************
#  FOREST: internal parameter (see explanations in the comments at the beginning of function text2panorama)
    if(FOREST < 0.5):
        ligne = "End of the process \n------------\n" ; print (ligne); g.write("\n" + ligne)
        g.close()
        return 
#************************** 
# Reminder: If FOREST = 1 : Sequence of *nc* ATs successively identified by each of the *nc* categories (*nc* albums, topics). Goal: visualizing both the position and the dispersion of each category on the tree       
#**************************
    ligne = "Series of tree with new idents \n-----------------\n" ; print (ligne); g.write("\n" + ligne)
    fo.forest(output_results, catv, id_AT_topic, p, coord_v)
    ligne = "End of the process \n------------\n" ; print (ligne); g.write("\n" + ligne)
    g.close()
#
    return
#-----------------------------------------------

