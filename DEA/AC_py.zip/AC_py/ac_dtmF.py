#**************** ac_dtmF.py ******************
#*** ici le fichier source "ac_dtmF.py" et les donn�es 
#*** sont dans un dossier "mydirectory" directement dans 
#***la racine "c:/". A adapter pour chaque utilisateur qui 
#*** remplacera � mydirectory � 
#*** par le chemin menant � son dossier de travail.
#***----------------------------------------------------
#*** Copier une � une les 4 lignes suivantes (sans les "# ") 
#*** directement dans l'interface (IDLE�).
#***----------------------------------------------------
# import os
# os.chdir("c:/mydirectory")
# import ac_dtmF
# from ac_dtmF import *
#***----------------------------------------------------
#*** fonction d'importation: numpy, pandas, matplotlib
#*** Ex�cution automatique des 3 lignes ci-dessous au chargement du fichier acomp_dtmF.py
#*** Inutile de les �crire dans l'interface
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#***-------------------------------------------------------------
#*** Copier successivement les instructions qui suivent le symbole ��#��. 
#*** Les commentaires (#***  ) n�ont �videmment pas besoin d��tre copi�s.
#***-------------------------------------------------------------
#*** SELECTION DES CHEMINS (adresses des fichiers)
#*** Exemple "Mots_Educ" : 3 chemins pour l'exemple Mots_Educ
# lane, lane_sup, lane_var_sup = "Mots_Educ_act.txt", "Mots_Educ_isup.txt", "Mots_Educ_vsup.txt"
#***-------------------------------------------------------------
#*** SELECTION DES PARAMETRES
#*** Selection d�une paire d�axes pour les visualisations
# ax_h, ax_v = 1, 2 
#***-------------------------------------------------------------
#*** EXECUTION de l'AC ****
#***-------------------------------------------------------------
#*** 1) AC_base() : lecture donn�es et calculs de base
# X, psi, psi_u, phi, phi_u = AC_base(lane)
# 
#*** 2) graf_act() : plan factoriels �l�ments actifs (indiv. + variables)
# graf_act (X, psi, phi, ax_h, ax_v )
#
#***  3) Repr�entation simultan�e des lignes et colonnes
# graf_simult (X, psi, phi, ax_h, ax_v)
#
#*** 4) AC_isup() Individus suppl�mentaires
# AC_isup( X, psi,  phi, phi_u, lane_sup, ax_h, ax_v)
#
#*** 5) AC_vsup() Variables num�riques suppl�mentaires (de 1 -> vsup_lim)
# AC_vsup(X, psi, psi_u, phi, lane_var_sup, ax_h, ax_v)
#
#***----------------------------------------------------------
#*** Ces 5 appels peuvent �tre remplac�s par l'unique appel de la fonction AC()
#*** apr�s avoir d�fini les parametres de la parenth�se.
#
# AC (lane, lane_sup, lane_var_sup, ax_h, ax_v)
#
#*** Mais on peut vouloir repr�senter d'autres plans factoriels, 
#*** ou s�lectionner les variables num�riques suppl�mentaires...
#*** l'appel par fonctions s�par�es est plus souple.
#***------------------------------------------------------
#
#*** fin des lignes � copier dans l'interface
#
#***------------------------------------------------------
#***--------------- CODES DE TOUTES LES FONCTIONS APPELEES
#***------------------------------------------------------
#*** Rappel: pd, np, plt sont des variables globales pour toutes 
#*** les fonctions de ac_dtmF.py
#***------------------------------------------------------
#*** Fonction AC_base(): appel du calcul, �ditions
def AC_base(lane):
#---
	X, F, psi, psi_u, phi, phi_u, pcent, vs, vp = AC_calc(lane)
	n,p = X.shape
	grafac_vp(pcent, p)
#---
	ch ="AC_file_" + lane    # nom du fichier cr�� 
	g = open(ch, "w+")       # ouverture de "ch" (chemin)
	print ("\n The coordinates are in the created file; " + ch)
	print("\n Eigenvalues\n")
	print(vp)
	print("\n") 
#---	
	g.write("\n Dataset\n")
	g.write(lane)
	g.write("\n")  
	g.write("\n Eigenvalues\n")
	g.write(str(vp))
	g.write("\n\n") 
	pd.set_option('display.max_rows', 10)
#---
	ligne = "Coordinates of variables"  
	print(ligne)
	print("\n")  
	print(pd.DataFrame({'ident':X.columns, 'c_var_1': phi[:,0], 'c_var_2': phi[:,1],'c_var_3': phi[:,2],  }))
	g.write(ligne)
	g.write("\n\n") 
	info = "\n complete coord. and coord. of indiv. are in the created file: " + ch + "\n\n"
	print(info)
	pd.set_option('display.max_rows', n)
#---
	a = pd.DataFrame({'ident':X.columns, 'c_var_1': phi[:,0], 'c_var_2': phi[:,1],'c_var_3': phi[:,2],  })
	sa = str(a)
	g.write(sa)
	g.write("\n\n")
	ligne = "Coordinates of individuals or observations" 
	g.write(ligne)
	g.write("\n\n")
#---
	aa = pd.DataFrame({'ident':X.index, 'c_ind_1': psi[:,0], 'c_ind_2': psi[:,1],'c_ind_3': psi[:,2],  })
	saa = str(aa)
	g.write(saa)
	g.close()
	pd.reset_option('display.max_rows')
	return X, psi, psi_u, phi, phi_u 
#----------------------------------------------------
#
#*** Fonction AC_calc() : calculs de base 
def AC_calc(lane):
	X = pd.read_csv(lane)
	n,p = X.shape
	ki = np.sum(X, axis = 1)
	kj = np.sum(X, axis = 0)
	k = np.sum(kj)
	fi, fj = ki/k, kj/k
	F = X/k
#---	
	S = np.zeros((n,p))
	for i in range(n):
		for j in range(p):
			S[i,j] = (F.iloc[i,j] -fi[i]*fj[j])/np.sqrt(fi[i]*fj[j])
#--- 	np.linalg.svd = singular values decomposition with numpy		
	u, vs, tvh = np.linalg.svd(S, full_matrices=False)
	rang = min(n,p) -1   # cas de l'AC
	vp = vs*vs
#
	psi=np.zeros((n,rang))
	psi_u=np.zeros((n,rang))
# coordonn�es psi des lignes (psi_u unitaire)
	for j in range(rang):
		for i in range(n):
			psi_u [i,j] = u[i,j]/np.sqrt(fi[i])
			psi [i,j] = u[i,j]*vs[j]/np.sqrt(fi[i])
#			
	tphi = np.zeros((rang,p)) # coordonn�es des colonnes
	tphi_u = np.zeros((rang,p)) # vect. unitaires des colonnes
	for jj in range(rang):
		for j in range(p):
			tphi_u[jj,j] = tvh[jj,j]/np.sqrt(fj[j])
			tphi[jj,j] = tvh[jj,j]*vs[jj]/np.sqrt(fj[j])
#			
	trace = np.sum(vp)
	pcent = vp/trace
# tphi et tphi_u sont tranpos�s en phi	et phi_u
	phi = tphi.T
	phi_u = tphi_u.T
	return X, F, psi, psi_u, phi, phi_u, pcent, vs, vp
#----------------------------------------------------
#*** Fonction grafac_vp() :Graphique des valeurs propres
def grafac_vp(pcent, p):
	plt.plot(np.arange(1, p+1), pcent)
	plt.title("Eigenvalues")
	plt.xlabel("Axes")
	plt.ylabel("Eigenvalues (as percentages of trace)")
	plt.show()
#----------------------------------------------------
#*** Fonction graf_act(): Graphiques (plan (ax_h, ax_v) des �l�ments actifs)
def graf_act ( X, psi, phi, ax_h, ax_v ):
	xx = ax_h
	yy = ax_v
	n,p = X.shape
#---
	graf_col (X, phi, p, xx, yy)
	graf_rows (X, psi,  n, xx, yy)
	return
#----------------------------------------------------
#*** Fonction graf_col(): Graphiques (plan (ax_h, ax_v) ) des variables
def graf_col ( X, phi, p, ax_h, ax_v):
	lax = 8
	xh = phi[:,ax_h - 1]
	xv = phi[:,ax_v - 1]
	fig, axes = plt.subplots(figsize = (lax,lax))
	mi_x, ma_x = min(xh), max(xh)
	axes.set_xlim (mi_x,ma_x)
	mi_y, ma_y = min(xv), max(xv)
	axes.set_ylim (mi_y,ma_y)
	FS = 10    # FS = fontsize
	for j in range(p):
		plt.annotate (X.columns[j],(phi[j,ax_h - 1], phi[j,ax_v - 1]), fontsize = FS)
	plt.plot([mi_x,ma_x],[0,0],color = 'blue',linestyle = "-", linewidth = 1)
	plt.plot([0,0],[mi_y,ma_y],color = 'blue',linestyle = "-", linewidth = 1)
	plt.title("Variables(columns) plane "+ str(ax_h)+ ", "+ str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Fonction  graf_rows() : Graphiques (plan (ax_h, ax_v) ) des lignes
def graf_rows ( X, psi, n, ax_h, ax_v):
#--- cadrage 
	xh = psi[:,ax_h - 1]
	xv = psi[:,ax_v - 1]
	lax = 8
	fig, axes = plt.subplots(figsize = (lax,lax))
	FS = 8   # FS = fontsize
	mi_x, ma_x = min(xh), max(xh)
	axes.set_xlim (mi_x,ma_x)
	mi_y, ma_y = min(xv), max(xv)
	axes.set_ylim (mi_y,ma_y)
	for i in range(n):
		plt.annotate (X.index[i],(psi[i,ax_h - 1], psi[i,ax_v - 1]), fontsize = FS, color = 'red')
	plt.plot([mi_x, ma_x],[0,0], color = 'blue', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[mi_y, ma_y ], color = 'blue', linestyle = "-",linewidth = 1)
	plt.title("Individuals (rows) plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Fonction graf_simult() : Graphiques simultan�s(plan (ax_h, ax_v) ) des lignes et colonnes
def graf_simult (X, psi, phi, ax_h, ax_v):
	n,p = X.shape
#--- cadrage (m�mes unit�s)
	xh = psi[:,ax_h - 1]
	xv = psi[:,ax_v - 1]
	xh_var = phi[:,ax_h - 1]
	xv_var = phi[:,ax_v - 1]
#--- a pour �largir le cadre 
	lax = 8
	a = 0.1
	FS_ind = 8  # FS = fontsize	
	FS_var = 10
	lmin = min(min(xv), min(xh),min(xv_var), min(xh_var)) - a
	lmax = max(max(xv), max(xh), max(xv_var), max(xh_var)) + a
#---
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin,lmax)
	for i in range(n):       # ind actifs
		plt.annotate (X.index[i],(psi[i,ax_h - 1], psi[i,ax_v - 1]), fontsize = FS_ind, color = 'b')
	for j in range(p):
		plt.annotate (X.columns[j],(phi[j,ax_h - 1], phi[j,ax_v - 1]), fontsize = FS_var, color ='r')
#--- trac� des axes
	plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
	# titres et �tiquettes
	plt.title("Active rows + columns, plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------

#*** Fonction AC_isup() : appels des coordonn�es et graphiques des lignes suppl�mentaires
def AC_isup( X, psi,  phi, phi_u, lane_sup, ax_h, ax_v):
#--- Donn�es lignes (individus) suppl�mentaires
	X_isup, psi_isup = rowsup(lane_sup, phi_u)
#--- Graphiques lignes (individus) suppl�mentaires
	graf_rows_sup (X, psi, psi_isup,  X_isup, ax_h, ax_v)
	return
#----------------------------------------------------
#*** Fonction rowsup(): Coordonn�es des lignes (individus) suppl�mentaires: 
def rowsup(lane_sup, phi_u):
	X_isup = pd.read_csv(lane_sup)
	q,p = X_isup.shape
	X_isup_norm = np.zeros((q,p))
	for i in range(q):
		for j in range(p):
			X_isup_norm [i,j] = X_isup.iloc[i,j] /sum(X_isup.iloc[i,:])
	psi_isup = np.dot(X_isup_norm, phi_u)
	print("\n")
	print(psi_isup)
	return X_isup, psi_isup
#----------------------------------------------------

#*** Fonction graf_rows_sup() : Graphiques (plan (ax_h, ax_v) ) des individus suppl�mentaires
def graf_rows_sup (X, psi, psi_isup, X_isup, ax_h, ax_v):
#
	xh = psi[:,ax_h - 1]
	xv = psi[:,ax_v - 1]
	xh_sup = psi_isup[:,ax_h - 1]
	xv_sup = psi_isup[:,ax_v - 1]
#--- cadrage (m�mes unit�s), "a" pour �largir le cadre 
	a = 0.1
	FS = 8  # FS = fontsize	
	lmin = min(min(xv), min(xh),min(xv_sup), min(xh_sup)) - a
	lmax = max(max(xv), max(xh), max(xv_sup), max(xh_sup)) + a
	lax = 8   # largeur du graphique
#---
	n = X.shape[0]           # nombre d'indiv. actifs
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin,lmax)
	for i in range(n):       # ind actifs
		plt.annotate (X.index[i],(psi[i,ax_h - 1], psi[i,ax_v - 1]), fontsize = FS)
	nsup = X_isup.shape[0]  # nombre d'indiv. suppl. 
	for i in range(nsup):  
		plt.annotate (X_isup.index[i],(psi_isup[i,ax_h - 1], psi_isup[i,ax_v - 1]), color = 'g')
#--- trac� des axes
	plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
	# titres et �tiquettes
	plt.title("Active and supplementary rows (individuals). Plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Fonction AC_vsup(): Colonnes (variables) suppl�mentaires
def AC_vsup(X, psi, psi_u, phi, lane_var_sup, ax_h, ax_v):
#--- Appel donn�es/calcul variables suppl�mentaires
	X_vsup, phi_vsup, q = colsup(X, psi_u, lane_var_sup)
	if (colsup == 0):
		return
#--- Appel Graphiques variables suppl�mentaires
	graf_col_sup (X, phi, X_vsup, phi_vsup, ax_h, ax_v)
#----------------------------------------------------
#*** Fonction colsup() : Donn�es variables suppl�mentaires: 
def colsup(X, psi_u, lane_var_sup):
	n, r = psi_u.shape
	X_vsup = pd.read_csv(lane_var_sup)
	n,q = X_vsup.shape #  q = nombre total de v. sup
	X_vsup_norm = np.zeros((n,q))
	for j in range(q):
		for m in range(n):
			X_vsup_norm [m,j] = X_vsup.iloc[m,j] /sum(X_vsup.iloc[:,j])
	phi_vsup = np.dot(X_vsup_norm.T, psi_u)
	print("\n")
	print(phi_vsup)
	return X_vsup, phi_vsup, q
#----------------------------------------------------
#*** Fonction graf_col_sup() : Graphiques (plan (ax_h, ax_v) ) des variables suppl�mentaires
def graf_col_sup (X, phi, X_vsup, phi_vsup,  ax_h, ax_v):
	lax = 8
	q = X_vsup .shape[1]  # nombre de var. sup.
	p = X.shape[1]  # nombre de var. act.
	fig, axes = plt.subplots(figsize = (lax,lax))
	
#--- cadrage (m�mes unit�s)
	xh = phi[:,ax_h - 1]
	xv = phi[:,ax_v - 1]
	xh_sup = phi_vsup[:,ax_h - 1]
	xv_sup = phi_vsup[:,ax_v - 1]
#
	a = 0.05
	FS = 8  # FS = fontsize	
	lmin = min(min(xv), min(xh),min(xv_sup), min(xh_sup)) - a
	lmax = max(max(xv), max(xh), max(xv_sup), max(xh_sup)) + a
	lax = 8
#---
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin,lmax)
#--- variables actives
	for j in range(p):
		plt.annotate (X.columns[j],(phi[j,ax_h - 1], phi[j,ax_v - 1]), fontsize = FS, color = 'b')
#--- variables suppl�mentaires	
	for j in range(q):
		plt.annotate (X_vsup.columns[j],(phi_vsup[j,ax_h - 1], phi_vsup[j,ax_v - 1]), color = 'g')
#---
	plt.plot([-1,1],[0,0], color = 'blue', linestyle = "-", linewidth = 1)
	plt.plot([0,0],[-1,1], color = 'blue', linestyle = "-", linewidth = 1)
	plt.title("Active and supplementary columns "+ str(ax_h)+ ", "+ str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#------------------------------------------------------------------------
#------------------------------------------------------------------------
#*** Fonction AC() Cette fonction r�unit les 5 appels des 5 fonctions     
#*** principales : AC_base, graf_act, graf_simult, AC_isup, AC_vsup.
#-------------------------------------------------------------------------
def AC (lane, lane_sup, lane_var_sup, ax_h, ax_v):
	X, psi, psi_u, phi, phi_u = AC_base(lane)
	graf_act (X, psi, phi, ax_h, ax_v )
	graf_simult (X, psi, phi, ax_h, ax_v)
	AC_isup( X, psi,  phi, phi_u, lane_sup, ax_h, ax_v)
	AC_vsup(X, psi, psi_u, phi, lane_var_sup, ax_h, ax_v)
	return
#-------------------------------------------------------------------------