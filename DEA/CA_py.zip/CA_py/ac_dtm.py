#***------ ac_dtm.py  -------------------
#***  Here the source file: "acomp_dtm.py" and the data are in a "mydirectory" folder
#***  directly in the root "c: /".
#***  To be adapted for each user, which will replace "mydirectory"
#***  by the path to his working folder.

#***----------------------------------------------------
#***  In the interface (IDLE ...),
#***  copy the following 4 lines one by one (without the "#")
#***----------------------------------------------------
# import os
# os.chdir("c:/mydirectory")
# import ac_dtm
# from ac_dtm import *
#***----------------------------------------------------
#*** Import statements for: numpy, pandas, matplotlib
#*** There is no need to copy these three lines: Automatic execution 
#*** through the previous importation of: ac_dtm.py file
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#***-------------------------------------------------------------
#***  Successively copy the instructions following the �#� symbol.
#***  Comments (# ***) obviously do not need to be copied.
#***-------------------------------------------------------------
#***  SELECTION OF PATHS (for the 3 data files)

#*** Example "Words_Educ" : 3 paths for example: Words_Educ
#*** (lane : active elements, lane_sup: suppl. rows, lane_var_sup: suppl. columns)
# lane, lane_sup, lane_var_sup = "Words_Educ_act.txt", "Words_Educ_isup.txt", "Words_Educ_vsup.txt"
#***-------------------------------------------------------------
#*** CHOICE OF PARAMETERS
#***-------------------------------------------------------------
#*** SELECTION of a pair of axes for visualizations
#*** (ax_h: horisontal, ax_v: vertical)
#***-------------------------------------------------------------
# ax_h, ax_v = 1, 2 
#
#*** CA EXECUTION
#***-------------------------------------------------------------
#*** 1) AC_base() : read basic data, computations
# X, psi, psi_u, phi, phi_u = AC_base(lane)
# 
#*** 2) graf_act() : factorial plane of active elements
# graf_act (X, psi, phi, ax_h, ax_v )
#
#*** 3) Simultaneous visualization of rows and columns
# graf_simult (X, psi, phi, ax_h, ax_v)
#
#*** 4) AC_isup() Supplementary rows
# AC_isup( X, psi,  phi, phi_u, lane_sup, ax_h, ax_v)
#
#*** 5) AC_vsup() Supplementary columns
# AC_vsup(X, psi, psi_u, phi, lane_var_sup, ax_h, ax_v)
#
#***----------------------------------------------------------
#*** These 5 calls can be replaced by the single call of the function AC():
# AC (lane, lane_sup, lane_var_sup, ax_h, ax_v)
#*** --------
#***  However we may want to represent other visualization planes,
#***  to adapt some outputs, to add other supplementary rows or columns ...
#***  the call by separate functions is more transparent and flexible.
#***------------------------------------------------------
#***  End of lines to copy in the interface
#***------------------------------------------------------
#***--------------- CODES FOR ALL CALLED FUNCTIONS
#***------------------------------------------------------
#*** Reminder: pd, np, plt are global variables for all 
#***  the functions of acomp_dtm.py
#***------------------------------------------------------
#*** Terminology: 
#***  supplementary <=> additional <=> illustrative
#***  rows <=> individuals, observations
#***  columns <=> variables
#***------------------------------------------------------

#*** Function AC_base(): computations, eigenvalues, eigenvectors...
def AC_base(lane):
#---
	X, F, psi, psi_u, phi, phi_u, pcent, vs, vp = AC_calc(lane)
	n,p = X.shape
	grafac_vp(pcent, p)
#---
	ch ="AC_file_" + lane    # name for the created result file 
	g = open(ch, "w+")       
	print ("\n The coordinates are in the created file; " + ch)
	print("\n Eigenvalues\n")
	print(vp)
	print("\n") 
#---	
	g.write("\n Dataset\n")
	g.write(lane)
	g.write("\n")  
	g.write("\n Eigenvalues\n")
	g.write(str(vp))
	g.write("\n\n") 
	pd.set_option('display.max_rows', 10)
#---
	ligne = "Coordinates of columns"  
	print(ligne)
	print("\n")  
	print(pd.DataFrame({'ident':X.columns, 'c_var_1': phi[:,0], 'c_var_2': phi[:,1],'c_var_3': phi[:,2],  }))
	g.write(ligne)
	g.write("\n\n") 
	info = "\n complete coord. and coord. of rows. are in the created file: " + ch + "\n\n"
	print(info)
	pd.set_option('display.max_rows', n)
#---
	a = pd.DataFrame({'ident':X.columns, 'c_var_1': phi[:,0], 'c_var_2': phi[:,1],'c_var_3': phi[:,2],  })
	sa = str(a)
	g.write(sa)
	g.write("\n\n")
	ligne = "Coordinates of rows" 
	g.write(ligne)
	g.write("\n\n")
#---
	aa = pd.DataFrame({'ident':X.index, 'c_ind_1': psi[:,0], 'c_ind_2': psi[:,1],'c_ind_3': psi[:,2],  })
	saa = str(aa)
	g.write(saa)
	g.close()
	pd.reset_option('display.max_rows')
	return X, psi, psi_u, phi, phi_u 
#----------------------------------------------------
#
#*** Function AC_calc() : basic computations 
def AC_calc(lane):
	X = pd.read_csv(lane)
	n,p = X.shape
	ki = np.sum(X, axis = 1)
	kj = np.sum(X, axis = 0)
	k = np.sum(kj)
	fi, fj = ki/k, kj/k
	F = X/k
#---	
	S = np.zeros((n,p))
	for i in range(n):
		for j in range(p):
			S[i,j] = (F.iloc[i,j] -fi[i]*fj[j])/np.sqrt(fi[i]*fj[j])
#--- 	np.linalg.svd = singular values decomposition with numpy		
	u, vs, tvh = np.linalg.svd(S, full_matrices=False)
	rang = min(n,p) -1   # CA entails at least a zero eigenvalue
	vp = vs*vs
#
	psi=np.zeros((n,rang))
	psi_u=np.zeros((n,rang))
#  psi: coordinates of rows (psi_u: vector of norm 1)
	for j in range(rang):
		for i in range(n):
			psi_u [i,j] = u[i,j]/np.sqrt(fi[i])
			psi [i,j] = u[i,j]*vs[j]/np.sqrt(fi[i])
#			
	tphi = np.zeros((rang,p))   # tphi: coordinates of columns
	tphi_u = np.zeros((rang,p)) # tphi_u unitary vestor
	for jj in range(rang):
		for j in range(p):
			tphi_u[jj,j] = tvh[jj,j]/np.sqrt(fj[j])
			tphi[jj,j] = tvh[jj,j]*vs[jj]/np.sqrt(fj[j])
#			
	trace = np.sum(vp)
	pcent = vp/trace
# tphi and tphi_u are transposed into phi and phi_u
	phi = tphi.T
	phi_u = tphi_u.T
	return X, F, psi, psi_u, phi, phi_u, pcent, vs, vp
#----------------------------------------------------
#*** Function grafac_vp() : Eigenvalues graph
def grafac_vp(pcent, p):
	plt.plot(np.arange(1, p+1), pcent)
	plt.title("Eigenvalues")
	plt.xlabel("Axes")
	plt.ylabel("Eigenvalues (as percentages of trace)")
	plt.show()
#----------------------------------------------------
#*** Function graf_act(): Graphics (plane (ax_h, ax_v) of active elements
def graf_act ( X, psi, phi, ax_h, ax_v ):
	xx = ax_h
	yy = ax_v
	n,p = X.shape
#---
	graf_col (X, phi, p, xx, yy)
	graf_rows (X, psi,  n, xx, yy)
	return
#----------------------------------------------------
#*** Function  graf_col() : Plot (plane (ax_h, ax_v)) of columns
def graf_col ( X, phi, p, ax_h, ax_v):
	lax = 8
	xh = phi[:,ax_h - 1]
	xv = phi[:,ax_v - 1]
	fig, axes = plt.subplots(figsize = (lax,lax))
	mi_x, ma_x = min(xh), max(xh)
	axes.set_xlim (mi_x,ma_x)
	mi_y, ma_y = min(xv), max(xv)
	axes.set_ylim (mi_y,ma_y)
	FS = 10    # FS = fontsize
	for j in range(p):
		plt.annotate (X.columns[j],(phi[j,ax_h - 1], phi[j,ax_v - 1]), fontsize = FS)
	plt.plot([mi_x,ma_x],[0,0],color = 'blue',linestyle = "-", linewidth = 1)
	plt.plot([0,0],[mi_y,ma_y],color = 'blue',linestyle = "-", linewidth = 1)
	plt.title("Variables(columns) plane "+ str(ax_h)+ ", "+ str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Function  graf_rows() : Plots (plane (ax_h, ax_v)) of rows
def graf_rows ( X, psi, n, ax_h, ax_v):
#--- Frame 
	xh = psi[:,ax_h - 1]
	xv = psi[:,ax_v - 1]
	lax = 8
	fig, axes = plt.subplots(figsize = (lax,lax))
	FS = 10   # FS = fontsize
	mi_x, ma_x = min(xh), max(xh)
	axes.set_xlim (mi_x,ma_x)
	mi_y, ma_y = min(xv), max(xv)
	axes.set_ylim (mi_y,ma_y)
	for i in range(n):
		plt.annotate (X.index[i],(psi[i,ax_h - 1], psi[i,ax_v - 1]), fontsize = FS, color = 'red')
	plt.plot([mi_x, ma_x],[0,0], color = 'blue', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[mi_y, ma_y ], color = 'blue', linestyle = "-",linewidth = 1)
	plt.title("Individuals (rows) plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Function graf_simult() : simultaneous plot of rows and columns(plane (ax_h, ax_v) ) des lignes et colonnes
def graf_simult (X, psi, phi, ax_h, ax_v):
	n,p = X.shape
#--- Frame (same units)
	xh = psi[:,ax_h - 1]
	xv = psi[:,ax_v - 1]
	xh_var = phi[:,ax_h - 1]
	xv_var = phi[:,ax_v - 1]
#--- a to widen the frame 
	lax = 8
	a = 0.1
	FS_ind = 10  # FS = fontsize	
	FS_var = 10
	lmin = min(min(xv), min(xh),min(xv_var), min(xh_var)) - a
	lmax = max(max(xv), max(xh), max(xv_var), max(xh_var)) + a
#---
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin,lmax)
	for i in range(n):       # active rows
		plt.annotate (X.index[i],(psi[i,ax_h - 1], psi[i,ax_v - 1]), fontsize = FS_ind, color = 'b')
	for j in range(p):
		plt.annotate (X.columns[j],(phi[j,ax_h - 1], phi[j,ax_v - 1]), fontsize = FS_var, color ='r')
#--- trac� des axes
	plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
	# titles and tags
	plt.title("Active rows + columns, plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------

#*** Function AC_isup() : coordinates and plot of supplementary rows
def AC_isup( X, psi,  phi, phi_u, lane_sup, ax_h, ax_v):
#--- Data and coord. of supplementary rows
	X_isup, psi_isup = rowsup(lane_sup, phi_u)
#--- Graphical display for suppl. rows (together with active rows)
	graf_rows_sup (X, psi, psi_isup,  X_isup, ax_h, ax_v)
	return
#----------------------------------------------------
#*** Function rowsup(): Data and coord. of supplementary rows: 
def rowsup(lane_sup, phi_u):
	X_isup = pd.read_csv(lane_sup)
	q,p = X_isup.shape
	X_isup_norm = np.zeros((q,p))
	for i in range(q):
		for j in range(p):
			X_isup_norm [i,j] = X_isup.iloc[i,j] /sum(X_isup.iloc[i,:])
	psi_isup = np.dot(X_isup_norm, phi_u)
	print("\n")
	print(psi_isup)
	return X_isup, psi_isup
#----------------------------------------------------

#*** Function graf_rows_sup() : plot of both suppl. rows and active rows
def graf_rows_sup (X, psi, psi_isup, X_isup, ax_h, ax_v):
#
	xh = psi[:,ax_h - 1]
	xv = psi[:,ax_v - 1]
	xh_sup = psi_isup[:,ax_h - 1]
	xv_sup = psi_isup[:,ax_v - 1]
#--- Frame (same units) ,"a" to widen the frame 
	a = 0.1
	FS = 10  # FS = fontsize	
	lmin = min(min(xv), min(xh),min(xv_sup), min(xh_sup)) - a
	lmax = max(max(xv), max(xh), max(xv_sup), max(xh_sup)) + a
	lax = 8   # size of the display
#---
	n = X.shape[0]           # number of active rows
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin,lmax)
	for i in range(n):       # active rows
		plt.annotate (X.index[i],(psi[i,ax_h - 1], psi[i,ax_v - 1]), fontsize = FS)
	nsup = X_isup.shape[0]  # number of suppl. rows. 
	for i in range(nsup):  
		plt.annotate (X_isup.index[i],(psi_isup[i,ax_h - 1], psi_isup[i,ax_v - 1]), color = 'g')
#--- drawing axes
	plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
#--- titles and tags
	plt.title("Active and supplementary rows (individuals). Plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Function AC_vsup(): Supplementary columns
def AC_vsup(X, psi, psi_u, phi, lane_var_sup, ax_h, ax_v):
#--- Data and computation
	X_vsup, phi_vsup, q = colsup(X, psi_u, lane_var_sup)
	if (colsup == 0):
		return
#--- Supplementary columns (variables) graphics
	graf_col_sup (X, phi, X_vsup, phi_vsup, ax_h, ax_v)
#----------------------------------------------------
#*** Function colsup(): Supplementary columns, data and computation
def colsup(X, psi_u, lane_var_sup):
	n, r = psi_u.shape
	X_vsup = pd.read_csv(lane_var_sup)
	n,q = X_vsup.shape #  q = number of suppl.
	X_vsup_norm = np.zeros((n,q))
	for j in range(q):
		for m in range(n):
			X_vsup_norm [m,j] = X_vsup.iloc[m,j] /sum(X_vsup.iloc[:,j])
	phi_vsup = np.dot(X_vsup_norm.T, psi_u)
	print("\n")
	print(phi_vsup)
	return X_vsup, phi_vsup, q
#----------------------------------------------------
#*** Function graf_col_sup() : Graphics (plane (ax_h, ax_v) ) for suppl. columns
def graf_col_sup (X, phi, X_vsup, phi_vsup,  ax_h, ax_v):
	lax = 8
	q = X_vsup .shape[1]  # number of suppl. columns
	p = X.shape[1]  # number of active columns
	fig, axes = plt.subplots(figsize = (lax,lax))
	
#--- Frame
	xh = phi[:,ax_h - 1]
	xv = phi[:,ax_v - 1]
	xh_sup = phi_vsup[:,ax_h - 1]
	xv_sup = phi_vsup[:,ax_v - 1]
#
	a = 0.05
	FS = 10  # FS = fontsize	
	lmin = min(min(xv), min(xh),min(xv_sup), min(xh_sup)) - a
	lmax = max(max(xv), max(xh), max(xv_sup), max(xh_sup)) + a
	lax = 8
#---
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin,lmax)
#---  active columns
	for j in range(p):
		plt.annotate (X.columns[j],(phi[j,ax_h - 1], phi[j,ax_v - 1]), fontsize = FS, color = 'b')
#--- supplementary (or illustrative) columns	
	for j in range(q):
		plt.annotate (X_vsup.columns[j],(phi_vsup[j,ax_h - 1], phi_vsup[j,ax_v - 1]), color = 'g')
#---
	plt.plot([-1,1],[0,0], color = 'blue', linestyle = "-", linewidth = 1)
	plt.plot([0,0],[-1,1], color = 'blue', linestyle = "-", linewidth = 1)
	plt.title("Active and supplementary columns "+ str(ax_h)+ ", "+ str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#------------------------------------------------------------------------
#------------------------------------------------------------------------
#*** Function AC() This function combines the 5 main function calls:    
#***  AC_base, graf_act, graf_simult, AC_isup, AC_vsup.
#-------------------------------------------------------------------------
def AC (lane, lane_sup, lane_var_sup, ax_h, ax_v):
	X, psi, psi_u, phi, phi_u = AC_base(lane)
	graf_act (X, psi, phi, ax_h, ax_v )
	graf_simult (X, psi, phi, ax_h, ax_v)
	AC_isup( X, psi,  phi, phi_u, lane_sup, ax_h, ax_v)
	AC_vsup(X, psi, psi_u, phi, lane_var_sup, ax_h, ax_v)
	return
#-------------------------------------------------------------------------
