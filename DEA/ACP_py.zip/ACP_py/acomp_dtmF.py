#****************
#*** ici le fichier source "acomp_dtmF.py" et les donn�es 
#*** sont dans un dossier "mydirectory" directement dans 
#***la racine "c:/". A adapter pour chaque utilisateur qui 
#*** remplacera � mydirectory � 
#*** par le chemin menant � son dossier de travail.
#***----------------------------------------------------
#*** Copier une � une les 4 lignes suivantes (sans les "# ") 
#*** directement dans l'interface (IDLE�).
#***----------------------------------------------------
# import os
# os.chdir("c:/mydirectory")
# import acomp_dtmF
# from acomp_dtmF import *
#***----------------------------------------------------
#*** fonction d'importation: numpy, pandas, matplotlib
#*** Ex�cution automatique des 3 lignes ci-dessous au chargement du fichier acomp_dtmF.py
#*** Inutile de les �crire dans l'interface
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#***-------------------------------------------------------------
#*** Copier successivement les instructions qui suivent le symbole ��#��. 
#*** Les commentaires (#***  ) n�ont �videmment pas besoin d��tre copi�s.
#***-------------------------------------------------------------
#*** SELECTION DES CHEMINS (adresses des fichiers)
#*** Exemple "Mini_Sem" : 3 chemins pour l'exemple Mini_Sem (mini-s�miom�trie)
# lane, lane_sup, lane_var_sup = 'Mini_Sem.txt', 'Mini_Sem_isup.txt', 'Mini_Sem_vsup.txt'
#***
#*** Exemple "Sem_300" : 3 chemins pour l'exemple Sem_300
# lane, lane_sup, lane_var_sup  = 'Sem300.txt', 'Sem300_isup.txt', 'Sem300_vsup.txt'
#***-------------------------------------------------------------
#*** SELECTION DES PARAMETRES
#*** Selection d�une paire d�axes pour les visualisations
#*** pour la s�miom�trie, l'axe 1 (facteur de taille) n'est pas pris en compte
# ax_h, ax_v = 2, 3 
#*** VARIABLES NUMERIQUES SUPPLEMENTAIRES
# vsup_lim = 3 #(Mini_Sem) ou vsup_lim = 7 (Sem300)  
#*** vsup_lim premi�res variables suppl�mentaires num�riques prises en compte
#*** VARIABLE NOMINALE SUPPLEMENTAIRE
# vsup_nom = 4 #(Mini_Sem) ou vsup_nom = 12 (Sem300) 
#*** la var nominale suppl�mentaire vsup_nom est s�lectionn�e
#***-------------------------------------------------------------
#*** EXECUTION de l'ACP
#***-------------------------------------------------------------
#*** 1) ACP_base() : lecture donn�es et calculs de base
# X, c_indiv, c_var, vecp, moy, ecinv = ACP_base(lane)
# 
#*** 2) grafact() : plan factoriels �l�ments actifs (indiv. + variables)
# grafact (X, c_indiv, c_var, ax_h, ax_v )
#
#*** 3) ACP_isup() Individus suppl�mentaires
# ACP_isup(X, c_indiv, lane_sup,moy, ecinv, vecp, ax_h, ax_v)
#
#*** 4) ACP_vsup() Variables num�riques suppl�mentaires (de 1 -> vsup_lim)
# ACP_vsup(X, c_indiv, c_var, lane_var_sup,ax_h, ax_v, vsup_lim )
#
#*** 5) ACP_nom() Variable nominale suppl�mentaire (vsup_nom)
# ACP_nom(X, c_indiv, ax_h, ax_v, vsup_nom, lane_var_sup )
#***----------------------------------------------------------
#*** Ces 5 appels peuvent �tre remplac�s par l'unique appel de la fonction ACP()
#
# ACP (lane, lane_sup, lane_var_sup, ax_h, ax_v, vsup_lim, vsup_nom)
#
#*** Mais on peut vouloir repr�senter d'autres plans factoriels, 
#*** d'autres variables nominales suppl�mentaires, 
#*** ou s�lectionner les variables num�riques suppl�mentaires...
#*** l'appel par fonctions s�par�es est plus souple.
#***------------------------------------------------------
#
#*** fin des lignes � copier dans l'interface
#
#***--------------- CODES DE TOUTES LES FONCTIONS APPELEES
#***------------------------------------------------------
#*** Rappel: pd, np, plt sont des variables globales pour toutes 
#*** les fonctions de acomp_dtmF.py
#***------------------------------------------------------
#*** Fonction ACP_base(): appel du calcul, �ditions
def ACP_base(lane):
#---
	X, c_indiv, c_var, pourcent, vecp, vp, moy, ecinv = ACP_calc(lane)
	n,p = X.shape
	grafacp_vp(pourcent, p)
#---
	ch ="ACP_file_" + lane    # nom du fichier cr�� 
	g = open(ch, "w+")       # ouverture de "ch" (chemin)
	print ("\n The coordinates are in the created file; " + ch)
	print("\n Eigenvalues\n")
	print(vp)
	print("\n") 
#---	
	g.write("\n Dataset\n")
	g.write(lane)
	g.write("\n")  
	g.write("\n Eigenvalues\n")
	g.write(str(vp))
	g.write("\n\n") 
	pd.set_option('display.max_rows', 10)
#---
	ligne = "Coordinates of variables"  
	print(ligne)
	print("\n")  
	print(pd.DataFrame({'ident':X.columns, 'c_var_1': c_var[:,0], 'c_var_2': c_var[:,1],'c_var_3': c_var[:,2],  }))
	g.write(ligne)
	g.write("\n\n") 
	info = "\n complete coord. and coord. of indiv. are in the created file: " + ch + "\n\n"
	print(info)
	pd.set_option('display.max_rows', n)
#---
	a = pd.DataFrame({'ident':X.columns, 'c_var_1': c_var[:,0], 'c_var_2': c_var[:,1],'c_var_3': c_var[:,2],  })
	sa = str(a)
	g.write(sa)
	g.write("\n\n")
	ligne = "Coordinates of individuals or observations" 
	g.write(ligne)
	g.write("\n\n")
#---
	aa = pd.DataFrame({'ident':X.index, 'c_indiv_1': c_indiv[:,0], 'c_indiv_2': c_indiv[:,1],'c_indiv_3': c_indiv[:,2],  })
	saa = str(aa)
	g.write(saa)
	g.close()
	pd.reset_option('display.max_rows')		
	return X, c_indiv, c_var, vecp, moy, ecinv
#----------------------------------------------------
#*** Fonction ACP_calc() : calculs de base 
def ACP_calc(lane):
	X = pd.read_csv(lane)
	n,p = X.shape
	moy = np.mean(X)
	ec= np.std(X)
	ecinv = 1./ec
#--- Donn�e standardis�es StanX
	StanX = np.zeros((n,p))
	for i in range(n):
		for j in range(p):
			StanX[i,j] = (X.iloc[i,j] -moy[j])*ecinv[j]
	C = np.dot(StanX.T, StanX)/n
	vp1, vecp1 = np.linalg.eigh(C)
	c_var = np.zeros((p,p))
	vecp  = np.zeros((p,p))
	vp    = np.zeros(p)
#---inversion de l'ordre des val et vec propres -----
	for j in range(p):
		jj = p-j-1
		vp[j] = vp1[jj]
		vecp[:,j] = vecp1[:,jj]
		c_var[:,j]= vecp[:,j]*np.sqrt(vp[j])
#---Fin de l'inversion
	c_indiv = np.dot(StanX, vecp)
	trace = np.sum(vp)
	pourcent = vp/trace
	return X, c_indiv, c_var, pourcent, vecp, vp, moy, ecinv
#----------------------------------------------------
#*** Fonction grafacp_vp() :Graphique des valeurs propres
def grafacp_vp(pourcent, p):
	plt.plot(np.arange(1, p+1), pourcent)
	plt.title("Eigenvalues")
	plt.xlabel("Axes")
	plt.ylabel("Eigenvalues (as percentages of trace)")
	plt.show()
#----------------------------------------------------
#*** Fonction gracfact(): Graphiques (plan (ax_h, ax_v) des �l�ments actifs)
def grafact ( X, c_indiv, c_var, ax_h, ax_v ):
	xx = ax_h
	yy = ax_v
	n,p = X.shape
#---
	graf_var (X, c_var, p, xx, yy)
	graf_ind (X, c_indiv,  n, xx, yy)
	return
#----------------------------------------------------
#*** Fonction graf_var(): Graphiques (plan (ax_h, ax_v) ) des variables
def graf_var ( X, c_var, p, ax_h, ax_v):
	lax = 8
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (-1,1)
	axes.set_ylim(-1,1)
	FS = 8    # FS = fontsize
	for j in range(p):
		plt.annotate (X.columns[j],(c_var[j,ax_h - 1], c_var[j,ax_v - 1]), fontsize = FS)
	plt.plot([-1,1],[0,0], color = 'blue', linestyle = "-", linewidth = 1)
	plt.plot([0,0],[-1,1], color = 'blue', linestyle = "-", linewidth = 1)
	plt.title("Variables(correlations) Plane "+ str(ax_h)+ ", "+ str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	discor = plt.Circle( (0,0),1, color = 'green', fill = False)
	axes.add_artist(discor)
	plt.show()
#----------------------------------------------------
#*** Fonction  graf_ind() : Graphiques (plan (ax_h, ax_v) ) des individus
def graf_ind ( X, c_indiv, n, ax_h, ax_v):
#--- cadrage (m�mes unit�s)
	xh = c_indiv[:,ax_h - 1]
	xv = c_indiv[:,ax_v - 1]
#--- a :  pour �largir le cadre 
	a = 1
	FS = 8   # FS = fontsize
	lmin = min(min(xv), min(xh)) - a
	lmax = max(max(xv), max(xh)) + a
	lax = lmax - lmin
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin, lmax)
	for i in range(n):
		plt.annotate (X.index[i],(c_indiv[i,ax_h - 1], c_indiv[i,ax_v - 1]), fontsize = FS)
	plt.plot([lmin,lmax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[lmin,lmax], color = 'red', linestyle = "-",linewidth = 1)
	plt.title("Individuals (observations) Plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Fonction ACP_isup() : appels des coordonn�es et graphiques des individus suppl�mentaires
def ACP_isup( X, c_indiv, lane_sup,moy, ecinv, vecp, ax_h, ax_v):
#--- Donn�es individus suppl�mentaires
	df_isup, df_isup_norm, c_isup = isup(lane_sup, moy, ecinv, vecp)
#--- Graphiques individus suppl�mentaires
	graf_ind_sup (X, c_indiv, c_isup,  df_isup, ax_h, ax_v)
	return
#----------------------------------------------------
#*** Fonction isup(): Coordonn�es des individus suppl�mentaires: 
def isup(lane_sup, moy, ecinv, vecp):
	df_isup = pd.read_csv(lane_sup)
	q,p = df_isup.shape
	df_isup_norm = np.zeros((q,p))
	for i in range(q):
		for j in range(p):
			df_isup_norm [i,j] = (df_isup.iloc[i,j] -moy[j])*ecinv[j]
	c_isup = np.dot(df_isup_norm, vecp)
	return df_isup, df_isup_norm, c_isup
#----------------------------------------------------
#*** Fonction graf_ind_sup() : Graphiques (plan (ax_h, ax_v) ) des individus suppl�mentaires
def graf_ind_sup (X, c_indiv, c_isup, df_isup, ax_h, ax_v):
#--- cadrage (m�mes unit�s)
	xh = c_indiv[:,ax_h - 1]
	xv = c_indiv[:,ax_v - 1]
	xh_sup = c_isup[:,ax_h - 1]
	xv_sup = c_isup[:,ax_v - 1]
#--- a pour �largir le cadre 
	a = 1
	FS = 8  # FS = fontsize	
	lmin = min(min(xv), min(xh),min(xv_sup), min(xh_sup)) - a
	lmax = max(max(xv), max(xh), max(xv_sup), max(xh_sup)) + a
	lax = lmax - lmin
#---
	n = X.shape[0]           # nombre d'indiv. actifs
	fig, axes = plt.subplots(figsize = (2*lax,2*lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin,lmax)
	for i in range(n):       # ind actifs
		plt.annotate (X.index[i],(c_indiv[i,ax_h - 1], c_indiv[i,ax_v - 1]), fontsize = FS)
	nsup = df_isup.shape[0]  # nombre d'indiv. suppl. 
	for i in range(nsup):    # ind suppl.
		plt.annotate (df_isup.index[i],(c_isup[i,ax_h - 1], c_isup[i,ax_v - 1]), color = 'b')
#--- trac� des axes
	plt.plot([-lax,lax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[-lax,lax], color = 'red', linestyle = "-",linewidth = 1)
	# titres et �tiquettes
	plt.title("Active individuals + suppl. Plane " + str(ax_h)+ ", "+  str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
#----------------------------------------------------
#*** Fonction ACP_vsup(): Variables num�riques suppl�mentaires
def ACP_vsup(X, c_indiv, c_var,  lane_var_sup,ax_h, ax_v, vsup_lim ):
#--- Appel Donn�es variables suppl�mentaires
	df_vsup, df_vs_num, c_vsup = vsup(X, c_indiv, lane_var_sup, vsup_lim)
	if (vsup == 0):
		return
#--- Appel Graphiques variables suppl�mentaires
	graf_var_sup (X, c_var, df_vsup, df_vs_num, c_vsup, ax_h, ax_v)
#----------------------------------------------------
#*** Fonction vsup() : Donn�es variables suppl�mentaires: 
def vsup(X, c_indiv, lane_var_sup, vsup_lim):
	n, p = X.shape
	df_vsup = pd.read_csv(lane_var_sup)
	qtot = df_vsup.shape[1] #  qtot = nombre total de v. sup
	if (vsup_lim > qtot):
		raise ValueError(" Error, vsup_lim too large !")
#---vsup_lim = les vsup_lim premi�res vsup (num�riques) sont projet�es
	df_vs_num = df_vsup.iloc[:,:vsup_lim].values  
	q = df_vs_num.shape[1]  # nombre de vsup num
	c_vsup = np.zeros((q,p))
	for j in range(p):
		for m in range(q):
			c_vsup[m,j] = np.corrcoef(df_vs_num[:,m], c_indiv[:,j])[0,1]
	print(c_vsup)
	return df_vsup, df_vs_num, c_vsup
#----------------------------------------------------
#*** Fonction graf_var_sup() : Graphiques (plan (ax_h, ax_v) ) des variables suppl�mentaires
def graf_var_sup (X, c_var, df_vsup, df_vs_num, c_vsup,  ax_h, ax_v):
	lax = 8
	q = df_vs_num.shape[1]  # nombre de var. sup.
	p = X.shape[1]  # nombre d'axes (donc de var. act.)
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (-1,1)
	axes.set_ylim(-1,1)
	FS = 8  # FS = fontsize	
#--- variables actives
	for j in range(p):
		plt.annotate (X.columns[j],(c_var[j,ax_h - 1], c_var[j,ax_v - 1]), fontsize = FS)
#--- variables num�riques suppl�mentaires	
	for j in range(q):
		plt.annotate (df_vsup.columns[j],(c_vsup[j,ax_h - 1], c_vsup[j,ax_v - 1]), color = 'g')
#---
	plt.plot([-1,1],[0,0], color = 'blue', linestyle = "-", linewidth = 1)
	plt.plot([0,0],[-1,1], color = 'blue', linestyle = "-", linewidth = 1)
	plt.title("Variables(correlations) Plane "+ str(ax_h)+ ", "+ str(ax_v))
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	discor = plt.Circle( (0,0),1, color = 'green', fill = False)
	axes.add_artist(discor)
	plt.show()
#----------------------------------------------------
#*** Fonction ACP_nom() : Donn�es variables nominales suppl�mentaires
def ACP_nom(X, c_indiv, ax_h, ax_v, vsup_nom, lane_var_sup ): 
#--- choix de la variable nominale suppl�mentaire
	df_vsup = pd.read_csv(lane_var_sup)
	df_vs_nom = df_vsup.iloc[:,vsup_nom - 1]
#---la variable nominale occupe la colonne vsup_nom de df_vsup.
#---
	col,b, nmod, dicmod = couleur (df_vs_nom)
# Graphiques individus/variables nominales suppl�mentaires
	graf_ind_mod ( X, c_indiv, df_vs_nom, vsup_nom, ax_h, ax_v, col, b, nmod, dicmod)
	return 
#----------------------------------------------------
#*** Fonction graf_ind_mod() : Graphiques (plan (ax_h, ax_v) ) des variables nominales suppl�mentaires
def graf_ind_mod (X, c_indiv, df_vs_nom, vsup_nom, ax_h, ax_v, col, b, nmod, dicmod):
#--- cadrage (m�mes unit�s)
	h,  v = ax_h - 1,  ax_v - 1
	xh = c_indiv[:,h]
	xv = c_indiv[:,v]
#---	a   pour �largir le cadre
	FS = 8  # FS = fontsize
	a = 1
	lmin = min(min(xv), min(xh)) - a
	lmax = max(max(xv), max(xh)) + a
	lax = lmax - lmin
	fig, axes = plt.subplots(figsize = (lax,lax))
	axes.set_xlim (lmin,lmax)
	axes.set_ylim(lmin, lmax)
	n = X.shape[0]  # nombre d'indiv. actifs
#---
	a = list(df_vs_nom)
	for i in range(n):
		plt.annotate (a[i],(xh[i], xv[i]), color = col[i], fontsize = FS)
#---		
	xhnom = coord_nom(xh, b, nmod,n)
	xvnom = coord_nom(xv, b, nmod,n)
	for j in range(nmod):
		plt.annotate (dicmod[j],(xhnom[j], xvnom[j]), color = 'k', weight='bold', fontsize = FS +3)
#---
	plt.plot([lmin,lmax],[0,0], color = 'red', linestyle = "-",linewidth = 1)
	plt.plot([0,0],[lmin,lmax], color = 'red', linestyle = "-",linewidth = 1)
	plt.title("Individuals + Categorical var. " + str(vsup_nom) + ", Plane (" + str(ax_h)+ ", "+  str(ax_v) + ")")
	plt.xlabel("axis " + str(ax_h))
	plt.ylabel("axis " + str(ax_v))
	plt.show()
	return
#----------------------------------------------------
#*** Fonction numer() : codage num�rique (entiers cons�cutifs) des modalit�s
#*** (en vue d'une coloration des points-individus sur les graphiques)
def numer (df_vs_nom): 
	categ = np.unique(df_vs_nom) # liste des modalit�s distinctes
	nmod = len(categ)
	a = list(df_vs_nom)
	dic_mod = {}  # dictionnaire clef = categorie (string), valeur = num�ro
	for i in range (nmod):
		dic_mod[categ[i]] = i
	b = []
	for i in range(len(a)):
		b.append(dic_mod[a[i]]) # modalit� en codage num�rique r�duit
	dicmod = {}
	for cle, val in list(dic_mod.items()):
		dicmod[val] = cle
	return b, nmod, dicmod
#----------------------------------------------------
#***  Fonction couleur(): Conversion des 6 premi�res modalit�s en couleurs	
def couleur (df_vs_nom):
	b, nmod, dicmod = numer(df_vs_nom)
	color7 = ['r','g','b','c','m','y','k']  #  k = black...
	col = []
	for i in range(len(b)):
		a = b[i]
		if(a > 6):
			a = 6 # les modalit�s au del� de 7 sont en noir
		col.append(color7[a])
	return col,b, nmod, dicmod
#------------------------------------------------------------------------
#*** Fonction coord_nom() : coord. des modalit�s d'une nominale suppl�mentaire
#*** (comme points moyens des individus concern�s)
def coord_nom(d,b, nmod,n):
#--- d = numerical vector, length = n (indiv. coordinates)
#--- nmod = nombre de modalit�s
#--- b = codage num�rique (1,2,...) de la variable nominale
	moy = np.zeros(nmod) # somme par cat�gorie
	eff = np.zeros(nmod) # effectif par cat�gorie
	for i in range(n):
		eff[b[i]] +=  1
		moy[b[i]] += d[i]
	return moy/eff
#------------------------------------------------------------------------
#*** Fonction ACP() Cette fonction r�unit les 5 appels des 5 fonctions     
#*** principales : ACP_base, grafact, ACP_isup, ACP_vsup, ACP_nom.
#***
#-------------------------------------------------------------------------
def ACP (lane, lane_sup, lane_var_sup, ax_h, ax_v, vsup_lim, vsup_nom):
	X, c_indiv, c_var, vecp, moy, ecinv = ACP_base(lane)
	grafact (X, c_indiv, c_var, ax_h, ax_v )
	ACP_isup(X, c_indiv, lane_sup,moy, ecinv, vecp, ax_h, ax_v)
	ACP_vsup(X, c_indiv, c_var, lane_var_sup,ax_h, ax_v, vsup_lim )
	ACP_nom(X, c_indiv, ax_h, ax_v, vsup_nom, lane_var_sup )
	return
#-------------------------------------------------------------------------
