# Commands to be typed in the R interface.
#source("c:/ADT_R/ACPS_E.r")             # location of source code
#path= "c:/ADT_R/Mini_Semio.txt"         # location of data
#X=read.table(path, header=TRUE, row.names=1, sep = ",") # X = data table
#Y =ACP(X)                               # main function
#plot_ind (Y, X, hor=2, ver=3, font = 1) # graph of individuals (lines)
                                         # (plane (2, 3) )
#plot_var (Y, X, hor=2, ver=3, font = 1) # graph of variables (columns)
                                         # (plane (2, 3) )
#--------------------------------------------------
ACP <-   function (X)   # main function 
{
C = correl(X);     # correlation matrix C (see R code below)
pca = eigen(C);   # diagonalization of C
percent = 100.*pca$values /sum(pca$values);
cv = pca$vectors;  # coordinates of individuals
ci <-  as.matrix( standard(X))%*%pca$vectors; # coord. of variables
ACP <- list(eval= pca$values, percent= percent, cvar= cv, cind = ci) 
}

#-------- correlation matrix of X
correl <-function (X)    
{
 stX = standard(X);   #  (see R code below)
 stXm <- as.matrix(stX);
 correl = (1./(nrow(X)-1 ))*t(stXm)%*%stXm
}

#-------- standardization of X 
 standard <- function(X)  # function called from “correl”
{
 meanX <- apply(X, 2, mean); 
 sdX <- apply (X, 2, sd);
 Xcent <- sweep(X, 2, meanX, FUN = "-");
 sweep(Xcent, 2, sdX, FUN = "/")
}
#-------------------------------

#-------------- graphical display - individuals 
# font = 1 usual, 2 = bold, 5= greek, 8 = italic, 9 = ital bold
plot_ind <-  function (Y, X, hor=NA, ver=NA, font = NA)
{
if(is.na (hor)){ hor <- 1};  if(is.na (ver)) {ver <- 2};
xlab = paste("Axis ", hor, sep = "");
ylab = paste("Axis ",  ver, sep = "");
plot(Y$cind[,hor],Y$cind[,ver], xlab=xlab, ylab=ylab , type = "n");
abline(h=0, v=0, col="red"); 
text(Y$cind[,hor],Y$cind[,ver], rownames(X), font = font );
}

#--------- graphical display - variables 
plot_var <-  function (Y, X, hor=NA, ver=NA, font = NA)
{
 if(is.na (hor)){ hor  <-  1};  if(is.na (ver)) {ver  <-  2};
xlab = paste("Axis ", hor, sep = "");
ylab = paste("Axis ",  ver, sep = "");

plot(Y$cvar[,hor],Y$cvar[,ver], xlab= xlab, ylab= ylab, type = "n");
abline(h=0, v=0, col="red");
text(Y$cvar[,hor],Y$cvar[,ver], colnames(X), font = font );
}
