# Command lines:
# source("c:\\ADT_R\\svd_image_E.r")  # source code
# path= "c:\\ADT_R\\Cheetah.txt"    # data
# X=read.table(path, header=FALSE, row.names=1, sep = "")
# nd = 8    # number of axes for the reconstitution (e.g.)
# Y = recons(X, nd)
# visu_image(Y)

#-------------------------------- Reconstruction of S with nd dimensions (svd)
 recons <- function(S, nd)
 {
 svdS = svd(S); # svd: singular values decomposition
 final = svdS$u[,1:nd]%*% diag(svdS$d[1:nd])%*%t(svdS$v[,1:nd]);
 final
 }

#--------------------------------------------
# visu_image(X) = visualization of X (simple txt file)
# identifiers for the rows, no header for the columns
visu_image <- function(Y) 
{
X=t(Y)
x = rep(1:nrow(X), ncol(X));
y = rep(1:ncol(X), each=nrow(X));
plot(x,y, type="n");
colx=ncol(X) +1;
for(i in 1:nrow(X)) 
  {
    for (j in 1:ncol(X)) 
     { 
       a=abs(X[i,colx-j]/255);
       if(a>1){a=1};
       points(i,j, type="p", col=rgb(a,a,a)  ) 
      } 
  }
}
#----------------------------------------------------------
