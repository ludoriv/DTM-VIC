#----- This function "afcor_armin_plot" call successively:
# afcor (correspondence analysis) 
# armin (minimum spanning tree) 
# and: plot_armin (the mst is plotted [by default] on correspondence 
#     analysis principal space: plane spanned by axes 1 and 2)
#------
afcor_armin_plot <- function(path)
{
# The three next statements (as comments)should be typed beforehand.
#  path = "c:/ADT_R/tab.csv"  
#  source("c:/ADT_R/afcor_E.r")
#  source("c:/ADT_R/armin_E.r")
 X=read.csv(path, row.names = 1, sep = ";")
 Y = afcor(X)  # CA of table X  
 Z = Y$phi     #  Z = matrix of coordinates of rows 
 ALM = armin(Z)# Minimum spanning tree (Arbre de Longueur Minimale in French)
 dd = noquote(printarmin(ALM, Y)) # printing the vertices
 plot_armin(ALM,Y) # plot on  CA principal plane
return(dd)
}
#-------------------------------------------------------
#-------- Euclidean distance between i and ip (rows of matrix Z)
 diip <- function(Z,i,ip){
 T<- Z[i,] - Z[ip,]
 return(sum(T^2))
}
#-------------------------------------------------------
# Minimum spanning tree 
# ourput  (deb(i),fin(i)) for i=1,...,ni-1   definition of the ni-1 vertices
# by their extremities.  tt(ni), kt(ni)  working vectors
# Reference:   R.C.Prim (1957)/Bell syst.tech.j./vol. 36,1389-1401.
# Distances between i and ip are computed "on the fly" (never 
# saved)(function diip)
#--------------------------------------------------------
armin<-function(F) {
#
 ni  <- dim(F)[1] ; nj  <- dim(F)[2]
dmax = 1e+20 
tt<- rep(dmax, ni)
kt <- rep(1, ni); ia <- rep(1, ni-1); ib <-ia;
for (i in 2:ni ){ tt[i] <- diip(F, 1, i)}
#--- tt[i] : distance de l'élément 1 à i
 j <- 0   
while(j <= ni)
   {
    dinf <- min(tt)         # smallest distance
	inf <- which.min(tt)    # index of the smallest distance
#	   
      j     <- j + 1 ;
      ia[j] <- kt[inf] ;
      ib[j] <- inf ;
        if (j == ni-1)   break;
      tt[inf]<- dmax;
#
      for(i in 2 : ni){
        if (tt[i] >= dmax)        next;
		di <- diip(F,i, inf)
        if (tt[i] <=  di)         next;
      kt[i] <- inf ;
      tt[i]  <- di ;
       }
	}   
armin.output<-list(deb =ia, fin = ib )
return(armin.output)  
 }
#-----------------------------------------------------
printarmin <- function(ALM,X)  # printing vertices
{
ident = X$id_lig   # identifiers of rows (taken from X)
NumDeb = ALM$deb  ;  NumFin = ALM$fin
NomDeb = rep(" ", length(NumDeb))
NomFin = rep(" ", length(NumDeb))
arete = rep("----- ", length(NumDeb))
#
for (i in 1:length(NumDeb)){NomDeb[i] <- ident[NumDeb[i]]}
for (i in 1:length(NumDeb)){NomFin[i] <- ident[NumFin[i]]}
dd = cbind(NumDeb,arete,NumFin,NomDeb,arete,NomFin)
return (dd)
}
#--------------------------------------------------------
plot_armin <-  function (ALM,Y, hor=NA, ver=NA,  sx = NA, sy = NA)
{
if(is.na (hor)){ hor <- 1};if(is.na (ver)) {ver <- 2};
if(is.na (sx)){ sx <- 1};if(is.na (sy)) {sy <- 1};
# sx and sy allow for a change of the arbitrary signs of the axes
# Default value = 1. (else, notify, e.g. sx = -1)
XX = sx*Y$phi[,hor]   ;   YY = sy* Y$phi[,ver]
npoint = length(XX)
xlab = paste("Axis ", hor, sep = "");
ylab = paste("Axis ",  ver, sep = "");
#
 plot(XX,YY, xlab=xlab , ylab=ylab , type = "n");
 abline(h = 0,v = 0, col = "red") # axes in red
 text(XX,YY,Y$id_lig, font = 2, col = "blue")
 NumDeb = ALM$deb  ;  NumFin = ALM$fin    
for (i in 1:npoint-1)  # tree will be green.
	{
	xa = XX[NumDeb[i]]   ;   	ya = YY[NumDeb[i]]
	xb = XX[NumFin[i]]   ;      yb = YY[NumFin[i]]
	lines(x=c(xa,xb), y = c(ya,yb) , col = "green", lwd = 2)
	}
}

