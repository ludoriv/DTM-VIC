#---------------------------------------------------------------------- 
# function Y = afcor(X) : Correspondence Analysis of matrix X
#----------------------------------------------------------------------
# Example for a contingency table "tab.csv" in the folder ADT_R
# (the source code:  - afcor_E.r -  being in the same folder)
# source("c:/ADT_R/afcor_E.r")
# path = "c:/ADT_R/tab.csv"
# path leads to an Excel(c) file [format csv]
# X = read.csv(path, row.names = 1, sep = ";")
# Y = afcor(X)
# plot_simult(Y) # simultaneous plot of rows and columns of the data table
#----------------------------------------------------------------------
afcor <- function(X) 
{
 #----- 
  n  <- dim(X)[1]  
  p <- dim(X)[2]
  id_lig <- dimnames(X)[[1]]   #identifier of rows
  id_col <- dimnames(X)[[2]]   #identifier of columns
  K  <- matrix(as.matrix(X), nrow = n, ncol = p)
 
#----- rank: max number of non-zero eigenvalues
  dimK <- dim(K)
  rang <- min(dimK) -1 
  som <- sum(K) ; F <- K/som
  fi <- apply(F, 1, sum) 
  fj <- apply(F, 2, sum)

#----- Matrix to be decomposed
  fifj     <- fi %*% t(fj)
  S      <- (F - fifj) / sqrt(fifj)
#----- Singular Values Decomposition
  decomp    <- svd(S)  
  vs     <- decomp$d[1:rang]    # singular values
  u      <- decomp$u     # u eigenvectors (n, rank)
  v      <- decomp$v     # v eigenvectors (n, rank)
  vp     <- vs^2         # vp eigenvalues
  chi_2  <- som*sum(vp)
 
#----- Unitary coordinates (norm 1)
  phinorm1 <- as.matrix(u[,1:rang]) / sqrt(fi)
  psinorm1 <- as.matrix(v[,1:rang]) / sqrt(fj)

#-----  Coordinates (variance vp)
  phi = t(vs*t(phinorm1))
  psi = t(vs*t(psinorm1))

#----- Output list:
afcor.output <-  list(   
     vp         = vp, 
     id_lig   = id_lig, 
     id_col   = id_col, 
     fi    = fi, 
     fj    = fj, 
     phi   = phi, 
     psi   = psi,
     chi_2 = chi_2)	 
return(afcor.output)  
}
#------------------------------------------------------
plot_simult <-  function (Y, hor=NA, ver=NA, font = NA)
#--------------------------------
# Simultaneous display of rows and columns 
# font = 1 usual, 2 = bold, 5= greek, 8 = italic, 9 = ital bold
#--------------------------------
{
if(is.na (hor)){ hor <- 1};if(is.na (ver)) {ver <- 2};
XX = c(Y$phi[,hor], Y$psi[,hor])
YY = c(Y$phi[,ver], Y$psi[,ver])

xlab = paste("Axis ", hor, sep = "");
ylab = paste("Axis ",  ver, sep = "");

 plot(XX,YY, xlab=xlab , ylab=ylab , type = "n");
 abline(h = 0,v = 0, col = "red")
 text(Y$phi[,hor],Y$phi[,ver],Y$id_lig, font = 2, col = "blue")
 text(Y$psi[,hor],Y$psi[,ver],Y$id_col, font = 2, col = "red")
}
#----------------------------------------
