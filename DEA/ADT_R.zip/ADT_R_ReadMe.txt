ADT_R_ ReadMe
-------------
The folder ADT_R comprises the following files:

svd_image_E.r # source code for image compression through SVD
ACPS_E.r  # source code for PCA.
afcor_E.r # source code for Correspondence Analysis
armin_E.r # source code for Minimum spanning Tree

-----
Cheetah.txt # Data (Mark Nelson) for svd_image_E.r
Mini_Semio.txt # Data for ACPS_E.r
tab.csv # Data for afcor_E.r (and for armin_E.r )
-----
The command lines to be typed in the R interface
 are "as comments" in the source codes.
They are reproduced below.
In these command lines, the folder ADT_R is supposed
 to be directly in the root: "c:/"
----------------------------------
# Command lines for "Image compression through SVD"
#----------------------------------
# source("c:/ADT_R/svd_image_E.r")  # source code
# path= "c:/ADT_R/Cheetah.txt"    # data
# X=read.table(path, header=FALSE, row.names=1, sep = "")
# nd = 8    # number of axes for the reconstitution (e.g.)
# Y = recons(X, nd)
# visu_image(Y)
#----------------------------------
# Command lines for Principal Components Analysis
#----------------------------------
#source("c:/ADT_R/ACPS_E.r")             # location of source code
#path= "c:/ADT_R/Mini_Semio.txt"         # location of data
#X=read.table(path, header=TRUE, row.names=1, sep = ",") # X = data table
#Y =ACP(X)                               # main function
#plot_ind (Y, X, hor=2, ver=3, font = 1) # graph of individuals (lines)
#                                         # (plane (2, 3) )
#plot_var (Y, X, hor=2, ver=3, font = 1) # graph of variables (columns)
                                         # (plane (2, 3) )
#------------------------------------
# Command lines for Correspondence Analysis
#------------------------------------
#       #Example for a contingency table "tab.csv" in the folder ADT_R
#       #(the source code:  - afcor_E.r -  being in the same folder)
# source("c:/ADT_R/afcor_E.r")
# path = "c:/ADT_R/tab.csv" 
#       # path leads to an Excel(c) file [format csv]
# X = read.csv(path, row.names = 1, sep = ";")
# Y = afcor(X)
# plot_simult(Y) # simultaneous plot of rows and columns of the data table
#-------------------------------------
#  Command lines for Minimum Spanning Tree (MST)
#------------------------------------
#     # The four next statements should be typed in the R interface.
#  path = "c:/ADT_R/tab.csv"         # location of data
#  source("c:/ADT_R/afcor_E.r")      # location of source code 1
#  source("c:/ADT_R/armin_E.r")      # location of source code 2
#  afcor_armin_plot(path)       # chain: CA + MST + plot on CA plane(1, 2)
#------------------------------------

