These data are the same as those of the directory: Sup_EX_09_LIFE_UK
included in the directory:  DtmVic_Examples_E_Suppl
*********************
Example Sup_Ex_09_LIFE_UK:  Responses in English
---------------------------------------------------------------
Data Format: DtmVic type 2 (survey data).
Description of data format: Button "DataFormat" in the toolbar of the START_MENU of DtmVic.

This is a common survey situation.
Open questions :
1 - " What is the single most important thing to you in life?"
2 - " Anything else ?"
3 - " What means to you the culture of your country?"

References:
_ Hayashi C., Suzuki T. et Sasaki M. (1992). Data Analysis for Social Comparative research : International Perspective. North-Holland, Amsterdam.
- Lebart L., Pincemin B., Poudat C. (2019). Analyse des données textuelles. PUQ, Québec, Canada.
- Lebart L., Salem A., Berry L. (1998). Exploring Textual Data, Kluwer, Dordrecht. 