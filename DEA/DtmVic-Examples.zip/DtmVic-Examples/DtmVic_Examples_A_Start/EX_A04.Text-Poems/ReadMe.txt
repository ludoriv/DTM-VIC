The dataset "Sonnet_LowerCase.txt" contains 
the first 20 Sonnets from Shakespeare.
For a larger set of sonnets and for comments, see, e.g., 
http://www.shakespeare-online.com/sonnets/
The conversion to Lower Case characters is meant to
avoid typifying the first word of each verse.