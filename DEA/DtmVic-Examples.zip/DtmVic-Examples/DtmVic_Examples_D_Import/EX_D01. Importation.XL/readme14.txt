Example of importation from an Excel file (r)
of the numerical data of examples A5, A6.