Example D05: Importation and exportation Dtm-Vic Lexico
--------------------------------------------------------


To test the "Lexico to Dtm" importation, please use the file "LEXICO_TDA.txt" as an input,
 and you will get as output the 3 DtmVic files:
 
 LEXICO2DTM_DAT.txt
 LEXICO2DTM_DIC.txt
 LEXICO2DTM_TXT.txt
 -----------------
 To test the "Dtm to Lexico" exportation, please use as an input the 3 files:
 TDA_dat.txt
 TDA_dic_new.txt
 TDA_tex.txt,
 and you will get as output the unique Lexico file:
 
 DTM2LEXICO.txt
-----------------
