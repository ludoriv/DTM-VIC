Update: July, 31, 2019
-----
The four first directories: DtmVic_Examples_A_Start, DtmVic_Examples_B_Texts, DtmVic_Examples_C_NumData, DtmVic_Examples_D_Import, contain the examples used in the tutorials and in the manual "Exploring Numerical and Textual Data in Practice with DtmVic".
-----
The last directory "DtmVic_Examples_E_Suppl" contains the examples used in the book: "Analyse des Données Textuelles"  (in French), Presses de l'Université du Québec (2019), by L. Lebart, B. Pincemin, C. Poudat.
https://www.puq.ca/catalogue/livres/analyse-des-donnees-textuelles-3651.html


