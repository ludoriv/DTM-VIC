We are dealing here with the image format: "pgm, text format".
If you start from a binary pgm file, you can convert it in "pgm, text format" using, for example, Open Office.
------
You can also use the following commands in R to obtain the simple text format,
from your pgm file : "MyImage.pgm", located in the directory (for example): "c:/MyDirectory".
You obtain the new file in simple txt format: MyImage.txt.
--------------
install.packages("pixmap")
library(pixmap)
setwd("c:/MyDirectory")
path= "MyImage.pgm"
imag = read.pnm(path)
X = 255* imag@grey
#X=read.table(path, header=FALSE, row.names=1, sep = "")
write.table(X, file = "MyImage.txt", sep = " ")