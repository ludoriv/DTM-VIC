Two snapshots of a scene of sweeping/cleaning.
1) In colour (format: ppm, without comment line starting with #)
2) In grayscale (format: pgm, without comment line starting with #)

For the colour photograph, the maximum size is reached
 here: 300 columns, that entails a numerical table with 
900 columns, taking into account the colours.

 