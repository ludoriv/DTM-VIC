These data are the same as those of the folder: "Sup_EX_11_SEMIO_close", 
included in the folder: "DtmVic_Examples_E_Suppl"
--------------------------------------------------------------------
Subset of 70 questions (words) from the semiometric questionnaire (210 words). Sample of 300 respondents.
Format "txt" DtmVic type 2 : "Survey" (here, Survey without open questions).
Data Format: DtmVic type 2 (survey data).
Description of data format: Button "DataFormat" in the toolbar of the START_MENU of DtmVic.
Description of the questionnaire: Chapter 1 in: Lebart L., Steiner J.-F., Wisdom J. et Piron M. (2014) (see below).

References:
Lebart L., Pincemin B., Poudat C. (2019). Analyse des données textuelles. PUQ, Québec, Canada.
Lebart L., Piron M. et Steiner J.-F. (2003). La sémiométrie. Dunod, Paris. Téléchargement : http://www.dtmvic.com/Semiometrie.html. Lebart L., Steiner J.-F., Wisdom J. et Piron M. (2014). The Semiometric Challenge: Words, Lifestyle and Values. L2C, Rivesaltes. http://www.dtmvic.com/doc/Semio_2014_format_169x244.pdf.
