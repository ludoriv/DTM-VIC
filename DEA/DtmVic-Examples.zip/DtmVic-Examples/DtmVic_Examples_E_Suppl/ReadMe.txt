Update:
July 31, 2019.
-------------
Sup : Some of these examples are not commented in the tutorials.
-------------
Examples from Sup_EX_01 to Sup_EX_10 are the examples used in the book: "Analyse des Données Textuelles"  (in French), Presses de l'Université du Québec (2019), by L. Lebart, B. Pincemin, C. Poudat.
https://www.puq.ca/catalogue/livres/analyse-des-donnees-textuelles-3651.html

-------------
Examples commented in the tutorials (or in the book: Exploring Numerical and Textual Data in Practice with Dtm-Vic): 

The example: "Sup.EX_07_LIFE_UK" involves the same data sets as the examples EX_A05.Text-Responses_1 and EX_A05.Text-Responses_2 located in the folder: DtmVic_Examples_A_Start.
Parts of the same data set are also used in both examples EX_B01.Text-Responses_Corda and EX_B02.Text-Responses_MCA, included in the folder: DtmVic_Examples_B_Texts. 
---------------------
The example: "Sup.EX_09_SEMIO_close" involves the same data sets as the example EX_C01.PCA_Semio included in the folder: DtmVic_Examples_C_NumData.  
-------------
