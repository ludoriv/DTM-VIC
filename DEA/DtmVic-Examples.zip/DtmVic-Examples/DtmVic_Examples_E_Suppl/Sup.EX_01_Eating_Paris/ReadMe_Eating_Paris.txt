Example Sup.EX_02_Eating_Paris:  Responses in French
-----------------------------------
Open question about dietary habits and preferences.

A sample of responses to open ended questions read  on the file NTEXZ = 'Eating_Paris_text.txt', the respondents being described by
 a set of closed questions - files Eating_Paris_dict.txt (dictionary for numerical data) and Eating_Paris_data.txt). 
Description of data format: Button "DataFormat" in the toolbar of the START_MENU of DtmVic.
This is a common survey situation.
Open questions :
1 - " What food do you prefer ?"
2 - " What is the ideal meal ?"

References:
- Akuto H. (Ed.) (1992). International Comparison of Dietary Cultures, Nihon Keizai Shimbun, Tokyo.
- Akuto H., Lebart L. (1992). Le repas idéal. Analyse de réponses libres en Anglais, Français, Japonais(in French). Les Cahiers de l'Analyse des Données, vol XVII, n°3, Dunod, Paris : 327-352.
- Lebart L., Pincemin B., Poudat C. (2019). Analyse des données textuelles (in French). PUQ, Québec, Canada.
- Lebart L., Salem A., Berry L. (1998). Exploring Textual Data, Kluwer, Dordrecht.
 