Example Sup_Ex_07_LIFE_France:  Responses in French
-----------------------------------
A sample of responses to open ended questions read 
 on the file 'LIFE_UK_text.txt', the respondents being described by
 a set of closed questions : files LIFE_UK_dict.txt and LIFE_UK_data.txt). 
This is a common survey situation.
Open questions :
1 - " What is the single most important thing to you in life?"
2 - " Anything else ?"
3 - " What means to you the culture of your country?"

References:
_ Hayashi C., Suzuki T. et Sasaki M. (1992). Data Analysis for Social Comparative research : International Perspective. North-Holland, Amsterdam.
- Lebart L., Pincemin B., Poudat C. (2019). Analyse des données textuelles. PUQ, Québec, Canada.
- Lebart L., Salem A., Berry L. (1998). Exploring Textual Data, Kluwer, Dordrecht.- Lebart L., Pincemin B., Poudat C. (2019). Analyse des données textuelles (in French). PUQ, Québec, Canada.
