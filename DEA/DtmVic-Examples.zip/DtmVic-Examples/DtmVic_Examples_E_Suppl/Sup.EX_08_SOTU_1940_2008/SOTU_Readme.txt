Discourses of the State of THe Union (USA) from 1940 to 2008.
Format Dtm-Vic type 1 (simple texts).
Description of data format: Button "DataFormat" in the toolbar of the START_MENU of DtmVic.
