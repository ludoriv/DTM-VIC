Example Sup.EX_05_Salud:   Texts in Spanish
------------------------------
Four parameter files are provided...


(CA and clustering of a set of responses to open ended questions read 
 on the file NTEXZ = 'Sa_open.txt', the respondents being described by
 a set of closed questions - files Sa_dic.txt and Sa_dat.txt). 
Open question " What good health means to you ?"

These files correspond to a common survey situation.
 Please, look at the parameter files (Sa_par.txt and Sa_par2.txt) to see
 the sequence of operations.... (comment lines beginning by #, or title 
 lines following immediately the commands "step").

