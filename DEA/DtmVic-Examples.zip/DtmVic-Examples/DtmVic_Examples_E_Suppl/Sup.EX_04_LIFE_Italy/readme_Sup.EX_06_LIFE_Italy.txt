Example Ex_Sup.EX_06_LIFE_Italy:  Responses in Italian
-----------------------------------
(CA and clustering of a set of responses to open ended questions read 
 on the file NTEXZ = 'itatext.txt', the respondents being described by
 a set of closed questions - files Itadic.txt and Itadat.txt). 
This is a common survey situation.
OPen questions :
1 - " What is the single most important thing to you in life?"
2 - " Anything else ?"
3 - " What means to you the culture of your country?"

