Example Sup_Ex_08_Japan_Japan:  Responses in romanised Japanese
---------------------------------------------------------------

(CA and clustering of a set of responses to open ended questions read 
 on the file NTEXZ = 'Jap96tex.txt', the respondents being described by
 a set of closed questions - files Jap96dic.txt and Jap96dat.txt). 
This is a common survey situation.
OPen questions :
1 - " What is the single most important thing to you in life?"
2 - " Anything else ?"
3 - " What means to you the culture of your country?"

 