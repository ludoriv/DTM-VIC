# import os
# os.chdir("c:/ADT_py")
# chemin = "SOTU_40_08.txt" # State of The Union 1940-2008
# import concord_E
# from concord_E import *
# conco(chemin, "dream")  # concordance of word: "dream"
# Concordance will be saved in the file: concord_re.txt
#------------------------------------------------------------
def conco (chemin, cible):  # "cible" = target
#  concordance with re (regular expressions)
	import re                # importation of "regular expression" module
	f=open(chemin,"r")       # opening text file
	ch = "concordance.txt"   # name of the created file 
	g = open(ch, "w+")       # opening "ch"
	i = 0
#----------------
	ciblenew = "[ ',]" + cible          # before "cible": blank or apostrophe or comma
	ciblenew = ciblenew + "[s ,.;:!?]"  # possible characters after "cible"
	while(1):
		i = i+1
		tbrut = f.readline()                     # reading a line
		tt = tbrut[0:len(tbrut)-1].rstrip(" ")   # cleaning the end of the line
		if(tt[0:4] == "===="):                   # end of text file (DtmVic format)
			break
		if(i>900000):                            #  safety (e.g.)
			break
		if(tt[0:4] == "****"):                   # Identifier of new text (DtmVic format)
			g.write(tbrut)
		m = re.search(ciblenew, tt)              # looking for "cible"
		if(m is not None ):                      #  if "cible" is found:
			g.write(str(i).rjust(5)[:5])
			g.write("  ")
			deb = m.start()
			fin = m.end()
			ligne = write_concor(tt, deb, fin)   # see function below
			g.write(ligne)
			g.write("\n")                        # End of line (Windows)
	print("Concordance saved in the file: concordance.txt\n")
#	g.seek(0)                 # back to the beginning of he created file   (optional)
#	tableau = g.read()        # loading the file  (opt)
#	print(tableau)            # control printing on the screen   (opt)
	g.close()                 
	f.close()                 
	return
#---------------  

def write_concor (tt, deb, fin):   # auxiliary function for printing the lines
	long = 40
	ltt = len(tt)
	if (deb <= long):
		ligne = " "*(long - deb)   #  ligne = line
		ligne += tt[:deb]
	else:
		ligne = ""
		ligne += tt[deb - long:deb]
	ligne += "  "
	ligne += (tt[deb:min(ltt, long + fin)])
	return ligne
#-----------------------------------------------------------------