The folder ADT_py comprises, after being unzipped, two code files:

concord_E.py
table_lex_E.py

... and three data files:

Poem.txt  (a mini corpus of excerpts of French poems to test the function tablex.py)
sonnets_Shakespeare.txt (the 154 sonnets of Shakespeare)
SOTU_40_08.txt (addresses of the State Of The Union, from 1940 to 2008 )

In the given examples of commands, the folder ADT_py should be placed directly in the root ("c:/").
Of course, it can be placed elsewhere, provided that the new address is specified in the command statements.

#------------------------------------
# Commands for executing tablex()
#------------------------------------
# import os                     #  os module
# os.chdir("c:/ADT_py")         # designating the folder containing program and data
# chemin = "poem.txt"           # name of text file (same folder)
# import table_lex_E            # program file: table_lex_E.py (same folder)
# from table_lex_E  import *    # call of functions in table_lex_E.py
# tablex(chemin, 2)         # executing function  tablex included in the file table_lex_E.py
							# (with: seuil = 2 ... default value for the frequency threshold).
#------------------------------------
# Commands for executing conco()
#------------------------------------
# import os
# os.chdir("c:/ADT_py")
# chemin = "SOTU_40_08.txt" # State of The Union 1940-2008
# import concord_E
# from concord_E import *
# conco(chemin, "dream")  # concordance of word: "dream"
# Concordance will be saved in the file: concord_re.txt
#------------------------------------
